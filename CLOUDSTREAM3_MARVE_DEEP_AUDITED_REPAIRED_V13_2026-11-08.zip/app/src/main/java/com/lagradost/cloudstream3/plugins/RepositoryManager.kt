package com.lagradost.cloudstream3.plugins

import android.content.Context
import com.lagradost.cloudstream3.USER_AGENT
import com.lagradost.cloudstream3.amap
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.mvvm.logError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** A repository the user added (the url of its repo.json). */
data class RepositoryData(
    val name: String,
    val url: String,
    val iconUrl: String? = null,
)

/** The content of a repo.json file. */
data class Repository(
    val name: String,
    val description: String?,
    val iconUrl: String?,
    val manifestVersion: Int,
    val pluginLists: List<String>,
)

/**
 * One entry of a repository's plugin list.
 *
 * status: 0 = Down, 1 = Ok, 2 = Slow, 3 = Beta only
 */
data class SitePlugin(
    val url: String,
    val status: Int,
    val version: Int,
    val name: String,
    val internalName: String,
    val authors: List<String>,
    val description: String?,
    val language: String?,
    val tvTypes: List<String>?,
    val iconUrl: String?,
    val fileSize: Long?,
    val fileHash: String?,
)

/** A plugin that was downloaded to this device. */
data class InstalledPlugin(
    val internalName: String,
    val name: String,
    val repoUrl: String,
    val downloadUrl: String,
    val version: Int,
    val filePath: String,
    val iconUrl: String?,
)

private fun JSONObject.str(key: String): String? {
    if (!has(key) || isNull(key)) return null
    return optString(key).takeIf { it.isNotBlank() }
}

private fun JSONObject.strList(key: String): List<String>? {
    if (!has(key) || isNull(key)) return null
    val arr = optJSONArray(key) ?: return null
    return (0 until arr.length()).mapNotNull { i -> arr.optString(i).takeIf { it.isNotBlank() } }
}

/**
 * Talks to extension repositories: parsing repo urls, reading repo.json and
 * plugins.json, and downloading .cs3 files. Same formats as CloudStream, so any
 * existing CloudStream repository works unchanged.
 */
object RepositoryManager {
    const val ONLINE_PLUGINS_FOLDER = "Extensions"

    /**
     * Awaits OkHttp without occupying a coroutine IO thread and, importantly,
     * connects coroutine cancellation to Call.cancel(). This prevents stale
     * repository requests from continuing after the user changes repositories.
     */
    private suspend fun <T> Call.awaitTransform(transform: (Response) -> T): T =
        suspendCancellableCoroutine { continuation ->
            continuation.invokeOnCancellation { cancel() }
            enqueue(object : Callback {
                override fun onFailure(call: Call, error: java.io.IOException) {
                    continuation.resumeWith(Result.failure(error))
                }

                override fun onResponse(call: Call, response: Response) {
                    if (!continuation.isActive) {
                        response.close()
                        return
                    }
                    val result = runCatching { response.use(transform) }
                    continuation.resumeWith(result)
                }
            })
        }

    internal suspend fun httpGetString(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
        return app.baseClient.newCall(request).awaitTransform { response ->
            if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code} for $url")
            response.body?.string() ?: throw java.io.IOException("Empty body for $url")
        }
    }

    /** Returns a SHA-256 string of the file content, like "sha256-b70462...". */
    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            var read = input.read(buffer)
            while (read != -1) {
                digest.update(buffer, 0, read)
                read = input.read(buffer)
            }
        }
        return "sha256-" + digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Resolves a short link (like https://t.ly/xxxx, or a short code) to the final url without downloading it. */
    private suspend fun resolveRedirect(url: String): String? {
        return try {
            val client = app.baseClient.newBuilder().followRedirects(false).followSslRedirects(false).build()
            val request = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            client.newCall(request).awaitTransform { response -> response.header("Location") }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            logError(t)
            null
        }
    }

    /**
     * Accepts what people actually paste: a direct https url, a
     * `cloudstreamrepo://` link, or a short code (cutt.ly, or py.md with a "!" prefix).
     */
    suspend fun parseRepoUrl(url: String): String? {
        val fixedUrl = url.trim()
        val schemeRegex = "^(cloudstreamrepo://)|(https://cs\\.repo/\\??)".toRegex()
        return when {
            fixedUrl.contains("^https?://".toRegex()) -> fixedUrl
            fixedUrl.contains(schemeRegex) -> {
                val stripped = fixedUrl.replace(schemeRegex, "")
                if (stripped.contains("^https?://".toRegex())) stripped else "https://$stripped"
            }
            fixedUrl.matches("^[a-zA-Z0-9!_-]+$".toRegex()) -> {
                if (fixedUrl.startsWith("!")) {
                    val location = resolveRedirect("https://py.md/${fixedUrl.removePrefix("!")}") ?: return null
                    if (location.startsWith("https://py.md/404") || location.removeSuffix("/") == "https://py.md") null else location
                } else {
                    val location = resolveRedirect("https://cutt.ly/$fixedUrl") ?: return null
                    if (location.startsWith("https://cutt.ly/404") || location.removeSuffix("/") == "https://cutt.ly") null else location
                }
            }
            else -> null
        }
    }

    suspend fun parseRepository(url: String): Repository? {
        return try {
            val json = JSONObject(httpGetString(url))
            val lists = json.optJSONArray("pluginLists") ?: JSONArray()
            Repository(
                name = json.str("name") ?: return null,
                description = json.str("description"),
                iconUrl = json.str("iconUrl"),
                manifestVersion = json.optInt("manifestVersion", 1),
                pluginLists = (0 until lists.length()).mapNotNull { i -> lists.optString(i).takeIf { it.isNotBlank() } },
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            logError(t)
            null
        }
    }

    private suspend fun parsePlugins(pluginsUrl: String): List<SitePlugin> {
        return try {
            val array = JSONArray(httpGetString(pluginsUrl))
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                SitePlugin(
                    url = obj.str("url") ?: return@mapNotNull null,
                    status = obj.optInt("status", 1),
                    version = obj.optInt("version", 1),
                    name = obj.str("name") ?: obj.str("internalName") ?: return@mapNotNull null,
                    internalName = obj.str("internalName") ?: obj.str("name") ?: return@mapNotNull null,
                    authors = obj.strList("authors") ?: emptyList(),
                    description = obj.str("description"),
                    language = obj.str("language"),
                    tvTypes = obj.strList("tvTypes"),
                    iconUrl = obj.str("iconUrl"),
                    fileSize = if (obj.has("fileSize") && !obj.isNull("fileSize")) obj.optLong("fileSize") else null,
                    fileHash = obj.str("fileHash"),
                )
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            logError(t)
            emptyList()
        }
    }

    /** All plugins offered by a repository, or null when the repo.json cannot be read. */
    suspend fun getRepoPlugins(repo: RepositoryData): List<SitePlugin>? {
        val parsed = parseRepository(repo.url) ?: return null
        return parsed.pluginLists.amap { listUrl -> parsePlugins(listUrl) }.flatten()
    }

    /** Downloads a .cs3 to [file]. Verifies the hash when the repository provides one. Returns an error message or null. */
    suspend fun downloadPluginToFile(
        context: Context,
        pluginUrl: String,
        file: File,
        expectedFileHash: String?,
        beforeCommit: (() -> Unit)? = null,
        afterCommit: (() -> Unit)? = null,
    ): String? {
        var tempFile: File? = null
        return try {
            val parentDir = file.parentFile ?: return "No parent folder"
            val directoryReady = withContext(Dispatchers.IO) {
                parentDir.isDirectory || parentDir.mkdirs() || parentDir.isDirectory
            }
            if (!directoryReady) throw java.io.IOException("Cannot create plugin folder")

            // Download to a temp file in the target directory so the final move
            // can be atomic and a failed/cancelled transfer never corrupts the
            // plugin currently installed at [file]. The OkHttp call
            // is cancellable and its socket is closed when the coroutine stops.
            val temp = withContext(Dispatchers.IO) {
                File.createTempFile("plugin", ".tmp", parentDir)
            }
            tempFile = temp
            val request = Request.Builder().url(pluginUrl).header("User-Agent", USER_AGENT).build()
            app.baseClient.newCall(request).awaitTransform { response ->
                if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
                val body = response.body ?: throw java.io.IOException("Empty download")
                body.byteStream().use { input ->
                    temp.outputStream().use { output -> input.copyTo(output) }
                }
            }

            if (expectedFileHash != null) {
                val actual = withContext(Dispatchers.IO) { sha256(temp) }
                if (actual != expectedFileHash) {
                    throw java.io.IOException("Hash mismatch (expected $expectedFileHash, got $actual)")
                }
            }

            // Only unload the current plugin after the replacement has been fully
            // downloaded and hash-verified. A failed transfer therefore leaves the
            // working version loaded and registered.
            beforeCommit?.invoke()
            val moved = withContext(Dispatchers.IO) {
                val committed = replacePluginArtifact(temp, file)
                // Keep the marker in the same non-suspending block as the move:
                // cancellation may be delivered when withContext dispatches back.
                if (committed) afterCommit?.invoke()
                committed
            }
            if (!moved) throw java.io.IOException("Cannot replace installed extension file")
            null
        } catch (cancelled: CancellationException) {
            tempFile?.delete()
            throw cancelled
        } catch (t: Throwable) {
            tempFile?.delete()
            logError(t)
            t.message ?: t.javaClass.simpleName
        }
    }
}
