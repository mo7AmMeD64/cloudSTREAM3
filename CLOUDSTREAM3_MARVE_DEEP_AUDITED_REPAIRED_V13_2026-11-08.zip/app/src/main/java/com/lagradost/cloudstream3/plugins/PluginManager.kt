package com.lagradost.cloudstream3.plugins

import android.content.Context
import android.content.res.AssetManager
import android.content.res.Resources
import android.util.Log
import com.lagradost.cloudstream3.APIHolder
import com.lagradost.cloudstream3.APIHolder.removePluginMapping
import com.lagradost.cloudstream3.mvvm.logError
import com.lagradost.cloudstream3.plugins.RepositoryManager.ONLINE_PLUGINS_FOLDER
import com.lagradost.cloudstream3.utils.extractorApis
import dalvik.system.PathClassLoader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStreamReader

/**
 * Downloads, loads and unloads extensions (.cs3 files).
 *
 * A .cs3 is a DEX file with a manifest.json. It is loaded with a PathClassLoader
 * whose parent is this app's class loader, so the extension finds the engine
 * classes (MainAPI, ExtractorLink, ...) that live in the :library module.
 * That is the whole trick that makes CloudStream extensions work here.
 */
object PluginManager {
    const val TAG = "PluginManager"

    // One writer at a time: installs, updates and removals touch files and the stored list.
    private val lock = Mutex()

    /** filePath -> loaded plugin instance */
    private val plugins = HashMap<String, BasePlugin>()

    private val _revision = MutableStateFlow(0)

    /** Increments whenever the set of loaded providers or installed plugins changes. */
    val revision: StateFlow<Int> = _revision.asStateFlow()

    private val _startupDone = MutableStateFlow(false)

    /** True once the plugins that were already installed have been loaded at startup. */
    val startupDone: StateFlow<Boolean> = _startupDone.asStateFlow()

    private fun bump() {
        _revision.value = _revision.value + 1
    }

    fun getInstalled(context: Context): List<InstalledPlugin> = ExtensionStore.installed(context)

    fun getRepositories(context: Context): List<RepositoryData> = ExtensionStore.repositories(context)

    fun isLoaded(filePath: String): Boolean = synchronized(plugins) { plugins.containsKey(filePath) }

    fun getPlugin(filePath: String): BasePlugin? = synchronized(plugins) { plugins[filePath] }

    /** Spits out a unique and safe file name based on [name]. */
    fun getPluginSanitizedFileName(name: String): String {
        return name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60) + "." + name.hashCode()
    }

    fun getPluginPath(context: Context, internalName: String, repositoryUrl: String): File {
        val folderName = getPluginSanitizedFileName(repositoryUrl)
        val fileName = getPluginSanitizedFileName(internalName)
        return File("${context.filesDir}/$ONLINE_PLUGINS_FOLDER/$folderName/$fileName.cs3")
    }

    // ---------------------------------------------------------------- repositories

    suspend fun addRepository(context: Context, repo: RepositoryData) {
        lock.withLock {
            val current = ExtensionStore.repositories(context)
            ExtensionStore.saveRepositories(context, (current + repo).distinctBy { it.url })
        }
        bump()
    }

    /** Removes the repository and its plugins without forgetting undeleted files. */
    suspend fun removeRepository(context: Context, repo: RepositoryData) {
        lock.withLock {
            // Deletion and metadata persistence form one short critical operation.
            // A ViewModel cancellation must not delete a file and then skip the
            // matching stored-record update on the way back to the caller.
            withContext(NonCancellable) {
                val installed = ExtensionStore.installed(context)
                val (fromRepo, others) = installed.partition { it.repoUrl == repo.url }
                val retained = mutableListOf<InstalledPlugin>()

                for (plugin in fromRepo) {
                    unloadPlugin(plugin.filePath)
                    val deleted = withContext(Dispatchers.IO) {
                        deleteFile(File(plugin.filePath))
                    }
                    if (!deleted) {
                        retained += plugin
                        val reloadError = loadPlugin(context, File(plugin.filePath))
                        if (reloadError != null) {
                            Log.e(TAG, "Could not reload ${plugin.internalName} after failed deletion: $reloadError")
                        }
                    }
                }

                // Persist the actual outcome. If any file could not be removed,
                // keep its record and the repository so the user can retry.
                ExtensionStore.saveInstalled(context, others + retained)
                if (retained.isEmpty()) {
                    ExtensionStore.saveRepositories(
                        context,
                        ExtensionStore.repositories(context).filter { it.url != repo.url },
                    )
                }
                APIHolder.initAll()
                // Successful and partial removals both change the observable set.
                bump()
                if (retained.isNotEmpty()) {
                    throw IOException("Could not remove ${retained.size} extension file(s); repository was kept")
                }
            }
        }
    }

    // ---------------------------------------------------------------- install / update / remove

    /** Downloads [site] from [repo] and loads it. Returns an error message, or null on success. */
    suspend fun install(context: Context, repo: RepositoryData, site: SitePlugin): String? {
        return lock.withLock {
            val file = getPluginPath(context, site.internalName, repo.url)
            val installedBefore = ExtensionStore.installed(context)
            val previousRecord = installedBefore.firstOrNull { it.filePath == file.absolutePath }
            val wasInstalled = previousRecord != null
            val wasLoaded = isLoaded(file.absolutePath)

            // Keep a recoverable copy of the previous artifact until the new DEX
            // has actually loaded. A correct SHA-256 alone does not prove that its
            // manifest, class, constructor, or plugin initialization is valid.
            val backup = try {
                withContext(NonCancellable) {
                    if (file.isFile) withContext(Dispatchers.IO) {
                        File.createTempFile("plugin-backup", ".tmp", file.parentFile).also { copy ->
                            try {
                                file.copyTo(copy, overwrite = true)
                            } catch (t: Throwable) {
                                copy.delete()
                                throw t
                            }
                        }
                    } else null
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                logError(t)
                return@withLock "Could not protect the currently installed extension: ${t.message ?: t.javaClass.simpleName}"
            }

            var unloadedForSwap = false
            var committed = false
            val downloadError = try {
                RepositoryManager.downloadPluginToFile(
                    context,
                    site.url,
                    file,
                    site.fileHash,
                    beforeCommit = {
                        unloadedForSwap = true
                        unloadPlugin(file.absolutePath)
                    },
                    afterCommit = { committed = true },
                )
            } catch (cancelled: CancellationException) {
                withContext(NonCancellable) {
                    var rollbackSucceeded = true
                    if (committed) {
                        rollbackSucceeded = withContext(Dispatchers.IO) {
                            if (backup != null) replacePluginArtifact(backup, file)
                            else deletePluginArtifact(file)
                        }
                        if (!rollbackSucceeded) {
                            Log.e(TAG, "Could not roll back cancelled extension commit for ${file.absolutePath}; backup=${backup?.absolutePath}")
                        }
                    }
                    if ((unloadedForSwap || committed) && rollbackSucceeded && (wasInstalled || wasLoaded) && file.exists()) {
                        val restoreError = loadPlugin(context, file)
                        if (restoreError != null) Log.e(TAG, "Could not reload previous extension: $restoreError")
                    }
                    if (committed && backup == null && wasInstalled) {
                        ExtensionStore.saveInstalled(
                            context,
                            ExtensionStore.installed(context).filterNot { it.filePath == file.absolutePath },
                        )
                    }
                    if (unloadedForSwap || committed) {
                        APIHolder.initAll()
                        bump()
                    }
                    // Retain a failed rollback copy for recovery; otherwise remove
                    // the temporary backup once the old artifact is safe again.
                    if (rollbackSucceeded) backup?.delete()
                }
                throw cancelled
            }

            if (downloadError != null) {
                val restoreError = if (unloadedForSwap) withContext(NonCancellable) {
                    // A failed move must leave the old file intact; restore from
                    // the backup anyway to cover filesystems with weaker move semantics.
                    val restored = if (backup == null) {
                        !file.exists() || withContext(Dispatchers.IO) { deletePluginArtifact(file) }
                    } else withContext(Dispatchers.IO) { replacePluginArtifact(backup, file) }
                    val error = when {
                        !restored -> "Previous extension file could not be restored"
                        (wasInstalled || wasLoaded) && file.exists() -> loadPlugin(context, file)
                        else -> null
                    }
                    if (restored && backup == null && wasInstalled) {
                        ExtensionStore.saveInstalled(
                            context,
                            ExtensionStore.installed(context).filterNot { it.filePath == file.absolutePath },
                        )
                    }
                    APIHolder.initAll()
                    bump()
                    error
                } else null
                if (restoreError.isNullOrBlank()) backup?.delete()
                else Log.e(TAG, "Preserving extension recovery backup at ${backup?.absolutePath}")
                return@withLock if (restoreError.isNullOrBlank()) downloadError
                else "$downloadError; previous extension recovery failed: $restoreError"
            }

            val loadError = loadPlugin(context, file)
            if (loadError != null) {
                // Do not persist an extension as installed merely because its file
                // downloaded. Roll back to the previous known-good artifact when
                // this candidate cannot be initialized by the app.
                val (restored, recoveryError) = withContext(NonCancellable) {
                    unloadPlugin(file.absolutePath)
                    val didRestore = if (backup != null) {
                        withContext(Dispatchers.IO) { replacePluginArtifact(backup, file) }
                    } else {
                        withContext(Dispatchers.IO) { deletePluginArtifact(file) }
                    }
                    var error: String? = null
                    if (didRestore && backup != null && (wasInstalled || wasLoaded) && file.exists()) {
                        error = loadPlugin(context, file)
                    }
                    if (didRestore && backup == null && wasInstalled) {
                        // The stored record pointed at a missing file before this
                        // attempted repair; remove that stale record rather than
                        // leave the UI claiming a non-existent install is present.
                        ExtensionStore.saveInstalled(
                            context,
                            ExtensionStore.installed(context).filterNot { it.filePath == file.absolutePath },
                        )
                    }
                    APIHolder.initAll()
                    bump()
                    didRestore to error
                }
                if (restored) backup?.delete()
                else Log.e(TAG, "Preserving extension recovery backup at ${backup?.absolutePath}")
                val recoveryDetail = recoveryError ?: if (!restored) "previous extension file could not be restored; backup=${backup?.absolutePath}" else null
                return@withLock if (recoveryDetail.isNullOrBlank()) loadError
                else "$loadError; previous extension recovery failed: $recoveryDetail"
            }

            val record = InstalledPlugin(
                internalName = site.internalName,
                name = site.name,
                repoUrl = repo.url,
                downloadUrl = site.url,
                version = site.version,
                filePath = file.absolutePath,
                iconUrl = site.iconUrl,
            )
            val others = ExtensionStore.installed(context).filter { it.filePath != record.filePath }
            ExtensionStore.saveInstalled(context, others + record)

            APIHolder.initAll()
            bump()
            backup?.delete()
            null
        }
    }

    suspend fun uninstall(context: Context, plugin: InstalledPlugin) {
        lock.withLock {
            // Keep the filesystem operation and persisted metadata in one
            // non-cancellable section so screen teardown cannot split the change.
            withContext(NonCancellable) {
                unloadPlugin(plugin.filePath)
                val file = File(plugin.filePath)
                val deleted = withContext(Dispatchers.IO) { deleteFile(file) }
                if (!deleted) {
                    val reloadError = if (file.exists()) loadPlugin(context, file) else "file disappeared"
                    APIHolder.initAll()
                    bump()
                    val detail = reloadError?.let { ": $it" }.orEmpty()
                    throw IOException("Could not delete extension file ${file.name}$detail")
                }
                ExtensionStore.saveInstalled(
                    context,
                    ExtensionStore.installed(context).filter { it.filePath != plugin.filePath },
                )
                APIHolder.initAll()
                bump()
            }
        }
    }

    /** Loads everything that is already installed. Called once at startup. */
    suspend fun loadAllInstalled(context: Context) {
        // Do not report startup as complete while waiting for the writer lock:
        // a cancelled caller that never entered the critical section must not
        // make the UI believe that extension discovery has finished.
        var startupAttempted = false
        try {
            lock.withLock {
                startupAttempted = true
                val installed = ExtensionStore.installed(context)
                val missing = mutableListOf<InstalledPlugin>()
                for (record in installed) {
                    val file = File(record.filePath)
                    if (!file.exists()) {
                        missing.add(record)
                        continue
                    }
                    val loadError = loadPlugin(context, file)
                    if (loadError != null) {
                        // Keep the installed record and artifact for recovery, but
                        // make the failure visible in logs instead of silently
                        // treating a broken extension as a successful startup.
                        Log.e(TAG, "Installed extension ${record.internalName} was not loaded: $loadError")
                    }
                }
                if (missing.isNotEmpty()) {
                    ExtensionStore.saveInstalled(context, installed - missing.toSet())
                }
                APIHolder.initAll()
            }
        } finally {
            // Home/source screens wait on startupDone before deciding that no
            // providers are available. Even if a store or engine initialization
            // throws, release that wait and let the app show its actual state.
            if (startupAttempted) {
                _startupDone.value = true
                bump()
            }
        }
    }

    /**
     * Checks every repository for a newer version of each installed plugin and
     * updates it. Returns how many plugins were updated.
     */
    suspend fun updateAll(context: Context): Int {
        var updated = 0
        val repos = ExtensionStore.repositories(context)
        for (repo in repos) {
            val available = try {
                RepositoryManager.getRepoPlugins(repo)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                logError(t)
                null
            } ?: continue
            val installedFromRepo = ExtensionStore.installed(context).filter { it.repoUrl == repo.url }
            for (record in installedFromRepo) {
                val site = available.firstOrNull { it.internalName == record.internalName } ?: continue
                if (site.version > record.version) {
                    if (install(context, repo, site) == null) updated++
                }
            }
        }
        return updated
    }

    // ---------------------------------------------------------------- loading

    private fun deleteFile(file: File): Boolean = deletePluginArtifact(file).also { deleted ->
        if (!deleted) Log.e(TAG, "Could not delete extension artifact: ${file.absolutePath}")
    }

    /** Loads one .cs3 file. Returns an error message, or null on success. */
    private fun loadPlugin(context: Context, file: File): String? {
        val filePath = file.absolutePath
        val fileName = file.nameWithoutExtension
        if (isLoaded(filePath)) return null

        return try {
            // Android 14+ refuses to load writable dex files.
            try {
                if (!file.setReadOnly()) Log.e(TAG, "Failed to set read-only on ${file.name}")
            } catch (t: Throwable) {
                logError(t)
            }

            val loader = PathClassLoader(filePath, context.classLoader)
            val manifestText = loader.getResourceAsStream("manifest.json")?.use { stream ->
                InputStreamReader(stream).use { reader -> reader.readText() }
            } ?: return "No manifest.json in $fileName"

            val manifest = JSONObject(manifestText)
            val pluginClassName = manifest.optString("pluginClassName", "")
            if (pluginClassName.isBlank()) return "manifest.json of $fileName has no pluginClassName"
            val requiresResources = manifest.optBoolean("requiresResources", false)

            val pluginClass: Class<*> = loader.loadClass(pluginClassName)
            val pluginInstance = pluginClass.getDeclaredConstructor().newInstance() as BasePlugin
            pluginInstance.filename = filePath

            if (requiresResources) {
                // Based on https://stackoverflow.com/questions/7483568/dynamic-resource-loading-from-other-apk
                val assets = AssetManager::class.java.getDeclaredConstructor().newInstance()
                val addAssetPath = AssetManager::class.java.getMethod("addAssetPath", String::class.java)
                addAssetPath.invoke(assets, filePath)
                @Suppress("DEPRECATION")
                (pluginInstance as? Plugin)?.resources = Resources(
                    assets,
                    context.resources.displayMetrics,
                    context.resources.configuration,
                )
            }

            synchronized(plugins) { plugins[filePath] = pluginInstance }

            if (pluginInstance is Plugin) {
                pluginInstance.load(context)
            } else {
                pluginInstance.load()
            }
            Log.i(TAG, "Loaded plugin $fileName")
            null
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to load $file: ${Log.getStackTraceString(t)}")
            // Do not keep a half loaded plugin around.
            unloadPlugin(filePath)
            "Failed to load $fileName: ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    private fun unloadPlugin(absolutePath: String) {
        val plugin = synchronized(plugins) { plugins[absolutePath] }
        if (plugin == null) {
            // Even when the instance never finished loading, drop anything it registered.
            removeRegistered(absolutePath)
            return
        }
        try {
            plugin.beforeUnload()
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to run beforeUnload $absolutePath: ${Log.getStackTraceString(t)}")
        }
        removeRegistered(plugin.filename ?: absolutePath)
        synchronized(plugins) { plugins.remove(absolutePath) }
    }

    private fun removeRegistered(sourcePlugin: String) {
        APIHolder.apis.filter { api -> api.sourcePlugin == sourcePlugin }.forEach {
            removePluginMapping(it)
        }
        APIHolder.allProviders.withLock {
            APIHolder.allProviders.removeAll { provider -> provider.sourcePlugin == sourcePlugin }
        }
        extractorApis.withLock {
            extractorApis.removeAll { extractor -> extractor.sourcePlugin == sourcePlugin }
        }
    }
}
