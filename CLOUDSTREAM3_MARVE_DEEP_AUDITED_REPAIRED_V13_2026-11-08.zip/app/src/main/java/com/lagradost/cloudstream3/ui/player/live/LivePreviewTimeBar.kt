package com.lagradost.cloudstream3.ui.player.live

import android.content.Context
import android.util.AttributeSet
import android.view.ContextThemeWrapper
import androidx.annotation.OptIn
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerControlView
import androidx.media3.ui.PlayerView
import androidx.media3.ui.R
import com.github.rubensousa.previewseekbar.media3.PreviewTimeBar
import com.kodastream.app.R as AppR
import com.kodastream.app.data.AppPrefs
import java.lang.ref.WeakReference


/**
 * Media3 reads bar_height as an XML dimension when the view is constructed.
 * Resolve the selected value through a theme overlay instead of mutating
 * DefaultTimeBar's private final field after construction.
 */
private fun Context.withPlayerProgressStyle(): Context {
    val overlay = when (AppPrefs.playerProgressStyle(this)) {
        "slim" -> AppR.style.PlayerProgressSlimOverlay
        "bold" -> AppR.style.PlayerProgressBoldOverlay
        else -> AppR.style.PlayerProgressStandardOverlay
    }
    return ContextThemeWrapper(this, overlay)
}

@OptIn(UnstableApi::class)
class LivePreviewTimeBar(context: Context, attrs: AttributeSet) :
    PreviewTimeBar(context.withPlayerProgressStyle(), attrs) {

    private var _currentPlayerView: WeakReference<PlayerView>? = null
    val currentPlayer: Player? get() = _currentPlayerView?.get()?.player

    fun registerPlayerView(player: PlayerView?) {
        _currentPlayerView = WeakReference(player)
        val controller =
            _currentPlayerView?.get()?.findViewById<PlayerControlView>(R.id.exo_controller)

        controller?.setProgressUpdateListener { position, bufferedPosition ->
            currentPlayer?.let { player ->
                if (isAtLiveEdge()) {
                    setPosition(player.duration)
                }
            }
        }
    }

    fun isAtLiveEdge(): Boolean {
        return LiveHelper.getLiveManager(currentPlayer)?.isAtLiveEdge() == true
    }
}