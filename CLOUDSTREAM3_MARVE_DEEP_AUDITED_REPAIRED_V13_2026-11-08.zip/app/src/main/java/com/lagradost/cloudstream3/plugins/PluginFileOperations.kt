package com.lagradost.cloudstream3.plugins

import java.io.File
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.FileAlreadyExistsException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Deletes an installed extension artifact and reports the real filesystem result.
 * Missing files are already deleted; callers must not erase persisted metadata
 * when this function returns false.
 */
internal fun deletePluginArtifact(file: File): Boolean = try {
    if (!file.exists()) true
    else {
        // Loaded DEX files are marked read-only. Clearing the flag is best-effort;
        // the actual delete result below remains authoritative.
        file.setWritable(true)
        file.delete() || !file.exists()
    }
} catch (_: SecurityException) {
    false
}

/** Replaces [target] with [source], preferring a same-filesystem atomic move. */
internal fun replacePluginArtifact(source: File, target: File): Boolean {
    if (!source.isFile) return false
    return try {
        try {
            Files.move(
                source.toPath(),
                target.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING,
            )
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } catch (_: FileAlreadyExistsException) {
            // Some providers ignore REPLACE_EXISTING when ATOMIC_MOVE is set.
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        true
    } catch (_: IOException) {
        false
    }
}
