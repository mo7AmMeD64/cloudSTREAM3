package com.kodastream.app.ui.home

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kodastream.app.engine.Engine
import com.lagradost.cloudstream3.SearchResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

fun sectionKey(provider: String, rowKey: String): String = "$provider|$rowKey"

@Immutable
data class ExpandedSection(
    val key: String,
    val providerName: String,
    val title: String,
    val pageIndex: Int,
    val page: Int,
    val hasNext: Boolean,
    val horizontal: Boolean,
    val items: List<SearchResponse>,
    val loading: Boolean = false,
    /** The last page failed; offers a retry row instead of "No more items". */
    val failed: Boolean = false,
)

/**
 * Paged copies of Home sections, kept in memory and shared by Home and the
 * expanded section screen. An activity-scoped instance survives rotation and
 * returning to Home; it is dropped on a provider change or a Home refresh.
 */
class ExpandedHomeViewModel : ViewModel() {
    private val _sections = MutableStateFlow<Map<String, ExpandedSection>>(emptyMap())
    val sections: StateFlow<Map<String, ExpandedSection>> = _sections.asStateFlow()

    private val _selected = MutableStateFlow<String?>(null)
    val selected: StateFlow<String?> = _selected.asStateFlow()

    private var provider: String? = null
    private var generation: Long = 0L
    private val pageJobs = mutableMapOf<String, Job>()

    /** A Home refresh replaces the source lists, so every page and request is stale. */
    fun reset() {
        generation++
        pageJobs.values.forEach { it.cancel() }
        pageJobs.clear()
        _sections.value = emptyMap()
        _selected.value = null
    }

    fun setProvider(name: String?) {
        if (name == provider) return
        provider = name
        reset()
    }

    fun open(providerName: String, row: HomeRow) {
        val key = sectionKey(providerName, row.key)
        _sections.update { sections ->
            if (sections.containsKey(key)) {
                sections
            } else {
                sections + (key to ExpandedSection(
                    key = key,
                    providerName = providerName,
                    title = row.title,
                    pageIndex = row.pageIndex,
                    page = row.page,
                    hasNext = row.hasNext,
                    horizontal = row.horizontal,
                    items = row.items.distinctBy { it.apiName to it.url },
                ))
            }
        }
        _selected.value = key
    }

    /**
     * Fetches the next page. One request at a time; [retry] is the only way
     * past a failed page, because a failure also turns [ExpandedSection.hasNext] off.
     */
    fun loadNext(retry: Boolean = false) {
        val key = _selected.value ?: return
        val current = _sections.value[key] ?: return
        if (current.loading) return
        if (!current.hasNext && !(retry && current.failed)) return
        val api = Engine.provider(current.providerName) ?: return finish(key)
        val page = api.mainPage.getOrNull(current.pageIndex) ?: return finish(key)

        update(key) { it.copy(loading = true, failed = false) }
        val requestGeneration = generation
        val requestedPage = current.page
        val requestedPageIndex = current.pageIndex
        val job = viewModelScope.launch(start = CoroutineStart.LAZY) {
            try {
                val result = Engine.mainPage(api, page, requestedPage + 1)
                // A provider change or Home refresh invalidates this response even
                // when a newly opened section happens to reuse the same key.
                if (requestGeneration != generation) return@launch
                val latest = _sections.value[key] ?: return@launch
                if (!latest.loading || latest.page != requestedPage ||
                    latest.pageIndex != requestedPageIndex
                ) return@launch

                val response = result.getOrNull()
                val merged = mergeSectionPage(
                    current = latest.items,
                    lists = response?.lists,
                    responseHasNext = response?.hasNext == true,
                    sectionName = latest.title,
                )
                update(key) {
                    it.copy(
                        items = merged.items,
                        page = if (response == null) it.page else it.page + 1,
                        hasNext = merged.hasNext,
                        loading = false,
                        failed = response == null,
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                if (requestGeneration == generation) {
                    update(key) { latest ->
                        if (latest.loading && latest.page == requestedPage) {
                            latest.copy(hasNext = false, loading = false, failed = true)
                        } else latest
                    }
                }
            } finally {
                if (requestGeneration == generation) pageJobs.remove(key)
            }
        }
        pageJobs[key] = job
        job.start()
    }

    private fun finish(key: String) {
        update(key) { it.copy(hasNext = false, loading = false) }
    }

    private fun update(key: String, block: (ExpandedSection) -> ExpandedSection) {
        _sections.update { sections ->
            sections[key]?.let { sections + (key to block(it)) } ?: sections
        }
    }
}
