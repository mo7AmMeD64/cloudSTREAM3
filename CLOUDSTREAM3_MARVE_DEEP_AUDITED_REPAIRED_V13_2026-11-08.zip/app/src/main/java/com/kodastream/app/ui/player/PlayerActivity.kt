package com.kodastream.app.ui.player

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.kodastream.app.data.AppPrefs
import com.kodastream.app.data.DownloadStore
import com.kodastream.app.data.HistoryStore
import com.kodastream.app.data.episodeNumberForWatchHistory
import com.kodastream.app.data.findPlaybackQueueIndex
import com.kodastream.app.data.canMarkPlaybackAsWatched
import com.kodastream.app.data.hasEpisodeWatchIdentity
import com.kodastream.app.data.isCountableWatchStatsType
import com.kodastream.app.data.LibraryStore
import com.kodastream.app.data.NavArgs
import com.kodastream.app.data.playbackEpisodeId
import com.kodastream.app.data.PlayerArgs
import com.kodastream.app.data.WatchedStore
import com.kodastream.app.data.WatchStatsStore
import com.kodastream.app.engine.AppBootstrap
import com.lagradost.cloudstream3.CommonActivity
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.ui.player.GeneratorPlayer
import com.lagradost.cloudstream3.ui.player.CS3IPlayer
import com.lagradost.cloudstream3.ui.player.PlayerSubtitleHelper
import com.lagradost.cloudstream3.ui.player.SubtitleOrigin
import com.lagradost.cloudstream3.ui.result.ResultEpisode
import com.lagradost.cloudstream3.ui.result.VideoWatchState
import com.lagradost.cloudstream3.utils.DataStoreHelper
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * Hosts the original CloudStream player fragment. Playback arguments come in
 * through [NavArgs] under [EXTRA_ID], because provider `data` strings are too
 * long and too fragile for an Intent extra.
 */
class PlayerActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA_ID = "player_id"

        fun newIntent(context: Context, id: Int): Intent =
            Intent(context, PlayerActivity::class.java).putExtra(EXTRA_ID, id)
    }

    private lateinit var args: PlayerArgs

    /** Favorite metadata for the optional heart control in the internal player. */
    fun currentFavoriteState(): Boolean? {
        if (!::args.isInitialized) return null
        val entry = args.history ?: return null
        return LibraryStore.isFavorite(this, entry.apiName, entry.url)
    }

    /** Toggle the whole title (not an individual episode) from the player. */
    fun toggleCurrentFavorite(): Boolean? {
        if (!::args.isInitialized) return null
        val entry = args.history ?: return null
        return LibraryStore.toggleFavorite(
            this,
            LibraryStore.LibraryItem(
                apiName = entry.apiName,
                url = entry.url,
                name = entry.title,
                posterUrl = entry.posterUrl,
                posterHeaders = entry.posterHeaders,
                addedAt = System.currentTimeMillis(),
            ),
        )
    }

    private var watchedKey: String? = null
    private var watchStatsPlayer: CS3IPlayer? = null

    private val handler = Handler(Looper.getMainLooper())
    private val progressTicker = object : Runnable {
        override fun run() {
            recordProgress()
            handler.postDelayed(this, 5_000L)
        }
    }
    private val hideBars = Runnable { hideSystemBars() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        applyCutoutMode()
        hideSystemBars()
        installInsetsListener()
        CommonActivity.setActivityInstance(this)
        AppBootstrap.start(this)

        args = NavArgs.player(intent.getIntExtra(EXTRA_ID, -1)) ?: run {
            finish()
            return
        }

        // Seed and observe the live preference. Disabling statistics immediately
        // detaches the ExoPlayer observer and closes the active interval, including in PiP.
        AppPrefs.watchStatisticsEnabled(this)
        lifecycleScope.launch {
            AppPrefs.watchStatisticsEnabledFlow.collect { enabled ->
                if (enabled == false) {
                    watchStatsPlayer?.setPlaybackStateObserver(null)
                    watchStatsPlayer = null
                    WatchStatsStore.updatePlaybackState(this@PlayerActivity, false)
                } else if (enabled == true) {
                    val fragment = supportFragmentManager
                        .findFragmentById(android.R.id.content) as? GeneratorPlayer
                    if (fragment != null) syncWatchStatistics(fragment)
                }
            }
        }

        if (savedInstanceState == null) {
            val (episodes, index) = episodesFor(this)
            @Suppress("DEPRECATION")
            val offlineSubs = args.offlineSubtitleUri?.let { uri ->
                listOf(
                    PlayerSubtitleHelper.getSubtitleData(
                        SubtitleFile(args.subtitle ?: "Subtitle", uri)
                    ).copy(origin = SubtitleOrigin.DOWNLOADED_FILE)
                )
            } ?: emptyList()
            supportFragmentManager.beginTransaction()
                .replace(
                    android.R.id.content,
                    GeneratorPlayer().apply {
                        arguments = GeneratorPlayer.newInstance(
                            KodaPlayerGenerator(episodes, offlineSubs),
                            index,
                        )
                    },
                )
                .commit()
        }
    }

    override fun onResume() {
        super.onResume()
        CommonActivity.setActivityInstance(this)
        hideSystemBars()
        // Attach immediately after the fragment is resumed. Waiting for the
        // 5-second progress ticker can otherwise omit the first playback seconds.
        (supportFragmentManager.findFragmentById(android.R.id.content) as? GeneratorPlayer)
            ?.let(::syncWatchStatistics)
        handler.removeCallbacks(progressTicker)
        handler.post(progressTicker)
    }

    override fun onPause() {
        handler.removeCallbacks(progressTicker)
        handler.removeCallbacks(hideBars)
        recordProgress()
        // A hold that never got its ACTION_UP (focus loss, rotation) must not
        // stick at 2x; the gesture helper only restores on touch end.
        restorePlaybackSpeed()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyCutoutMode()
            hideSystemBars()
        } else {
            restorePlaybackSpeed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyCutoutMode()
        hideSystemBars()
        restorePlaybackSpeed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        handler.removeCallbacks(hideBars)
        // Keep the hand-off alive across rotation, but release it when playback really ends.
        if (isFinishing && !isChangingConfigurations) {
            WatchStatsStore.updatePlaybackState(this, false)
            if (intent.hasExtra(EXTRA_ID)) NavArgs.removePlayer(intent.getIntExtra(EXTRA_ID, -1))
        } else {
            WatchStatsStore.flushActive(this)
        }
        watchStatsPlayer?.setPlaybackStateObserver(null)
        watchStatsPlayer = null
        super.onDestroy()
    }

    /** Keeps the player fully immersive; the system bars only peek transiently on a swipe. */
    private fun hideSystemBars() {
        WindowCompat.getInsetsController(window, window.decorView).apply {
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    /** Re-applies shortEdges after the ported player resets the cutout mode on its own exits. */
    private fun applyCutoutMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val params = window.attributes
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = params
        }
    }

    /**
     * The ported player shows the system bars on some transitions. Hide them
     * again after a short delay, which still leaves the system's transient
     * swipe-to-peek behavior usable.
     */
    private fun installInsetsListener() {
        val content = findViewById<android.view.View>(android.R.id.content) ?: return
        ViewCompat.setOnApplyWindowInsetsListener(content) { _, insets ->
            if (insets.isVisible(WindowInsetsCompat.Type.systemBars())) {
                handler.removeCallbacks(hideBars)
                handler.postDelayed(hideBars, 2_000L)
            } else {
                handler.removeCallbacks(hideBars)
            }
            insets
        }
    }

    /** Puts back the user's speed after a hold was interrupted before ACTION_UP. */
    private fun restorePlaybackSpeed() {
        val fragment = supportFragmentManager
            .findFragmentById(android.R.id.content) as? GeneratorPlayer ?: return
        val player = fragment.player
        val stored = DataStoreHelper.playBackSpeed
        if (player.getPlaybackSpeed() != stored) player.setPlaybackSpeed(stored)
    }

    /** Mirrors the fragment's position into Koda's history and per-episode prefs. */
    private fun recordProgress() {
        if (!::args.isInitialized) return
        val fragment = supportFragmentManager
            .findFragmentById(android.R.id.content) as? GeneratorPlayer ?: return
        syncWatchStatistics(fragment)
        val episode = fragment.currentEpisode ?: return
        val position = fragment.player.getPosition() ?: return
        val duration = fragment.player.getDuration()?.takeIf { it > 0 } ?: 0L
        val base = args.history ?: return

        val resumeKey = episode.resumeKey ?: base.resumeKey
        // Use the queue's classified media type when available, falling back to the
        // persisted history type for standalone/offline playback without a queue.
        val mediaType = args.queue?.type ?: base.type
        if (position < 5_000L) return
        // The internal player uses synthetic 0/0 coordinates for movies. Normalize
        // the coordinates before persisting History or watched markers so movies
        // remain -1/-1, while series episodes never collide with that movie key.
        val isMoviePlayback = mediaType == "movie"
        val queueEpisode = args.queue?.episodes?.firstOrNull { it.index == episode.index }
            ?: args.queue?.episodes?.getOrNull(episode.index.coerceAtLeast(0))
        val hasEpisodeIdentity = hasEpisodeWatchIdentity(
            hasQueueEpisode = queueEpisode?.number?.let { it >= 0 } == true,
            historyEpisodeNumber = base.episode,
        )
        // Keep null for seasonless series (One Piece, Conan...). The details page keys
        // watched marks as season=null -> -1; forcing 0 here made the two disagree.
        val watchedSeason = if (isMoviePlayback) null else {
            episode.season ?: queueEpisode?.season ?: base.season
        }
        val displaySeason = if (isMoviePlayback) null else {
            episode.seasonIndex?.takeIf { it > 0 }
                ?: queueEpisode?.seasonIndex?.takeIf { it > 0 }
                ?: base.seasonDisplayNumber?.takeIf { it > 0 }
        }
        val watchedEpisode = if (isMoviePlayback || !hasEpisodeIdentity) null else {
            episodeNumberForWatchHistory(
                currentEpisode = episode.episode.takeIf { it >= 0 },
                queuedEpisode = queueEpisode?.number,
                historyEpisode = base.episode,
                fallback = episode.index.coerceAtLeast(0) + 1,
            )
        }
        // Viewing time is tracked from the player's isPlaying state transitions,
        // independently from position/history writes and before the short-position guard.
        val entry = base.copy(
            season = watchedSeason,
            seasonDisplayNumber = displaySeason,
            episode = watchedEpisode,
            episodeTitle = episode.name,
            data = episode.data,
            resumeKey = resumeKey,
            positionMs = position,
            durationMs = duration,
        )
        if (!AppPrefs.pauseHistory(this)) {
            val changedEpisode = HistoryStore.current(this)
                .firstOrNull { it.key == entry.key }?.resumeKey != resumeKey
            if (changedEpisode) HistoryStore.upsert(this, entry)
            else HistoryStore.updateProgress(this, entry.key, position, duration)
            AppPrefs.setPosition(this, resumeKey, position)
            if (duration > 0) AppPrefs.setDuration(this, resumeKey, duration)
        }

        // Mark only a movie or an episodic item with a real episode identity.
        // Synthetic player coordinates are not enough to create watched markers.
        val canMarkWatched = canMarkPlaybackAsWatched(
            mediaType = mediaType,
            isMoviePlayback = isMoviePlayback,
            hasEpisodeIdentity = hasEpisodeIdentity,
        )

        if (canMarkWatched && duration > 0 && position >= duration * 0.9 && watchedKey != resumeKey) {
            watchedKey = resumeKey
            WatchedStore.setWatched(
                context = this,
                apiName = entry.apiName,
                url = entry.url,
                season = watchedSeason,
                episode = watchedEpisode,
                resumeKey = resumeKey,
                watched = true,
            )
        }
    }

    /** Bind the real ExoPlayer state to the wall-clock watch-time accumulator. */
    private fun syncWatchStatistics(fragment: GeneratorPlayer) {
        val mediaType = args.queue?.type ?: args.history?.type.orEmpty()
        val enabled = AppPrefs.watchStatisticsEnabled(this) && isCountableWatchStatsType(mediaType)
        val player = fragment.player as? CS3IPlayer
        if (!enabled || player == null) {
            watchStatsPlayer?.setPlaybackStateObserver(null)
            watchStatsPlayer = null
            WatchStatsStore.updatePlaybackState(this, false)
            return
        }

        if (watchStatsPlayer !== player) {
            watchStatsPlayer?.setPlaybackStateObserver(null)
            watchStatsPlayer = player
            player.setPlaybackStateObserver { isPlaying ->
                val stillEnabled = ::args.isInitialized && AppPrefs.watchStatisticsEnabled(this) &&
                    isCountableWatchStatsType(args.queue?.type ?: args.history?.type.orEmpty())
                WatchStatsStore.updatePlaybackState(this, stillEnabled && isPlaying)
            }
        } else {
            // Reconcile the current state after activity recreation or a missed callback.
            WatchStatsStore.updatePlaybackState(this, player.getIsPlaying())
        }
        // Flush every five seconds while leaving the active interval open.
        WatchStatsStore.flushActive(this)
    }

    /** Turns Koda's playback arguments into the episode list the original player expects. */
    private fun episodesFor(context: Context): Pair<List<ResultEpisode>, Int> {
        val queue = args.queue
        val template = args.history
        val tvType = when (queue?.type ?: template?.type) {
            "anime" -> TvType.Anime
            "series" -> TvType.TvSeries
            else -> TvType.Movie
        }

        val episodes = if (queue != null && queue.episodes.isNotEmpty()) {
            queue.episodes.map { ep ->
                val resumeKey = if (ep.data.startsWith("content://") || ep.data.startsWith("file://")) {
                    "local|" + DownloadStore.idOf(queue.apiName, queue.url, ep.season, ep.number)
                } else {
                    queue.apiName + "|" + ep.data
                }
                ResultEpisode(
                    headerName = queue.title,
                    name = ep.name,
                    poster = ep.posterUrl ?: queue.posterUrl,
                    episode = ep.number ?: -1,
                    seasonIndex = ep.seasonIndex,
                    season = ep.season,
                    data = ep.data,
                    apiName = queue.apiName,
                    id = playbackEpisodeId(resumeKey),
                    index = ep.index,
                    position = 0L,
                    duration = 0L,
                    score = null,
                    description = null,
                    isFiller = false,
                    tvType = tvType,
                    parentId = playbackEpisodeId("parent|${queue.apiName}|${queue.url}"),
                    videoWatchState = VideoWatchState.None,
                    totalEpisodeIndex = ep.index,
                    resumeKey = resumeKey,
                )
            }
        } else {
            listOf(
                ResultEpisode(
                    headerName = args.title,
                    name = template?.episodeTitle ?: args.subtitle,
                    poster = template?.posterUrl,
                    episode = template?.episode ?: 0,
                    // Use the persisted user-facing season number when known,
                    // never inventing "Season 0" from raw provider keys.
                    seasonIndex = template?.seasonDisplayNumber?.takeIf { it > 0 },
                    season = template?.season,
                    data = args.data,
                    apiName = args.apiName,
                    id = playbackEpisodeId(args.resumeKey),
                    index = 0,
                    position = 0L,
                    duration = 0L,
                    score = null,
                    description = null,
                    isFiller = false,
                    tvType = tvType,
                    parentId = playbackEpisodeId("parent|${args.apiName}|${template?.url ?: args.resumeKey}"),
                    videoWatchState = VideoWatchState.None,
                    resumeKey = args.resumeKey,
                ),
            )
        }

        val index = if (queue != null) {
            findPlaybackQueueIndex(
                episodes = queue.episodes,
                data = args.data,
                season = template?.season,
                episode = template?.episode,
            )
        } else {
            episodes.indexOfFirst { it.data == args.data }
        }
        val safeIndex = index.takeIf { it >= 0 } ?: 0

        // Seed the original player's resume store from Koda's saved history and
        // per-episode positions, so playback starts where it stopped.
        val known = template?.let { h ->
            HistoryStore.current(context).firstOrNull { it.key == h.key }
        }
        episodes.forEach { episode ->
            val identity = episode.resumeKey ?: return@forEach
            val legacyId = identity.hashCode()
            val legacyProgress = DataStoreHelper.getViewPos(legacyId)
            val storedPosition = AppPrefs.position(context, identity)
                .takeIf { it > 0L } ?: legacyProgress?.position ?: 0L
            val storedDuration = known?.takeIf { it.resumeKey == identity }?.durationMs
                ?.takeIf { it > 0L }
                ?: AppPrefs.duration(context, identity).takeIf { it > 0L }
                ?: legacyProgress?.duration
                ?: 0L
            val safePosition = storedPosition.coerceIn(0L, storedDuration.coerceAtLeast(0L))
            if (storedDuration > 30_000L && safePosition > 0L) {
                DataStoreHelper.setViewPos(episode.id, safePosition, storedDuration)
            }
            // Preserve the original player's completion badge when moving away from
            // hashCode-based IDs. Old IDs are not deleted because collisions may exist.
            DataStoreHelper.getVideoWatchState(legacyId)?.let { oldState ->
                if (DataStoreHelper.getVideoWatchState(episode.id) == null) {
                    DataStoreHelper.setVideoWatchState(episode.id, oldState)
                }
            }
        }

        return episodes to safeIndex
    }
}
