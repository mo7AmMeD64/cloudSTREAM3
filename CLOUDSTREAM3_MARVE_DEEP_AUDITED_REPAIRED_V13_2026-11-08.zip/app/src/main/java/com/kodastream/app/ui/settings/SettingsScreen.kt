package com.kodastream.app.ui.settings

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material.icons.rounded.ViewSidebar
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.Theaters
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import com.kodastream.app.data.WatchedStore
import com.kodastream.app.data.WatchStatsStore
import com.kodastream.app.data.watchDurationParts
import com.kodastream.app.data.watchedEpisodeCount
import com.kodastream.app.data.watchedMovieCount
import com.kodastream.app.data.watchedSeriesCount
import com.kodastream.app.ui.theme.findPalette
import com.kodastream.app.BuildConfig
import com.kodastream.app.R
import com.kodastream.app.data.AppPrefs
import com.kodastream.app.data.DownloadLocations
import com.kodastream.app.downloads.DownloadService
import com.kodastream.app.data.SearchHistoryStore
import com.kodastream.app.ui.home.hero.HeroStyle
import com.kodastream.app.ui.theme.APP_PALETTES
import com.kodastream.app.ui.theme.DYNAMIC_PALETTE_ID
import com.kodastream.app.ui.theme.PALETTE_CATEGORIES
import com.kodastream.app.ui.theme.PaletteStyle
import com.kodastream.app.ui.theme.ThemeMode
import com.kodastream.app.ui.theme.ThemeViewModel
import com.kodastream.app.ui.theme.contrastInk

private const val GITHUB_URL = "https://github.com/mo7AmMeD64/cloudSTREAM3"
private const val DONATE_URL = "https://creators.sa/x3onq"
private const val TELEGRAM_URL = "https://t.me/fullappk"

@Composable
fun SettingsScreen(
    contentPadding: PaddingValues,
    themeViewModel: ThemeViewModel,
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    fun openLink(url: String) {
        try {
            uriHandler.openUri(url)
        } catch (_: Exception) {
            Toast.makeText(context, R.string.update_link_failed, Toast.LENGTH_SHORT).show()
        }
    }

    var autoUpdate by remember { mutableStateOf(AppPrefs.autoUpdate(context)) }
    var navPosition by remember { mutableStateOf(AppPrefs.navPosition(context)) }
    var navBarStyle by remember { mutableStateOf(AppPrefs.navBarStyle(context)) }
    var fixedNavigation by remember { mutableStateOf(AppPrefs.fixedNavigation(context)) }
    var navDragSwitchEnabled by remember { mutableStateOf(AppPrefs.navDragSwitchEnabled(context)) }
    var homeCatalogMode by remember { mutableStateOf(AppPrefs.homeCatalogMode(context)) }
    var watchStatisticsEnabled by remember { mutableStateOf(AppPrefs.watchStatisticsEnabled(context)) }
    var playerGestureMode by remember { mutableStateOf(AppPrefs.playerGestureMode(context)) }
    var playerVerticalSwipe by remember { mutableStateOf(AppPrefs.playerVerticalSwipeEnabled(context)) }
    var playerExtraBrightness by remember { mutableStateOf(AppPrefs.playerExtraBrightnessEnabled(context)) }
    var playerHorizontalSwipe by remember { mutableStateOf(AppPrefs.playerHorizontalSwipeEnabled(context)) }
    var playerDoubleTap by remember { mutableStateOf(AppPrefs.playerDoubleTapEnabled(context)) }
    var playerDoubleTapPause by remember { mutableStateOf(AppPrefs.playerDoubleTapPauseEnabled(context)) }
    var playerSeekSeconds by remember { mutableStateOf(AppPrefs.playerSeekSeconds(context)) }
    var playerProgressStyle by remember { mutableStateOf(AppPrefs.playerProgressStyle(context)) }
    var playerShowSource by remember { mutableStateOf(AppPrefs.playerShowSourceControl(context)) }
    var playerShowLock by remember { mutableStateOf(AppPrefs.playerShowLockControl(context)) }
    var playerShowRotate by remember { mutableStateOf(AppPrefs.playerShowRotateControl(context)) }
    var playerShowResize by remember { mutableStateOf(AppPrefs.playerShowResizeControl(context)) }
    var playerShowSubtitleOffset by remember { mutableStateOf(AppPrefs.playerShowSubtitleOffsetControl(context)) }
    var playerShowTracks by remember { mutableStateOf(AppPrefs.playerShowTracksControl(context)) }
    var playerShowSeekButtons by remember { mutableStateOf(AppPrefs.playerShowSeekButtons(context)) }
    var playerCompactControls by remember { mutableStateOf(AppPrefs.playerCompactControls(context)) }
    var watchedKeys by remember { mutableStateOf(WatchedStore.current(context)) }
    var totalWatchMs by remember { mutableStateOf(WatchStatsStore.current(context)) }
    LaunchedEffect(Unit) {
        WatchedStore.keys.collect { keys -> if (keys != null) watchedKeys = keys }
    }
    LaunchedEffect(watchStatisticsEnabled) {
        if (watchStatisticsEnabled) {
            totalWatchMs = WatchStatsStore.current(context)
            WatchStatsStore.totalMs.collect { value -> if (value != null) totalWatchMs = value }
        }
    }
    var pauseHistory by remember { mutableStateOf(AppPrefs.pauseHistory(context)) }
    var keepScreenOn by remember { mutableStateOf(AppPrefs.keepScreenOn(context)) }
    var holdToSpeedUp by remember { mutableStateOf(AppPrefs.holdToSpeedUp(context)) }
    var downloadWifiOnly by remember { mutableStateOf(AppPrefs.downloadWifiOnly(context)) }
    var downloadConcurrent by remember { mutableStateOf(AppPrefs.downloadMaxConcurrent(context)) }
    var downloadLocation by remember { mutableStateOf(DownloadLocations.readableLocation(context)) }
    var customFolder by remember { mutableStateOf(AppPrefs.downloadTreeUri(context) != null) }
    var appLanguage by remember { mutableStateOf(AppPrefs.appLanguage(context)) }
    var languageDialog by remember { mutableStateOf(false) }
    var styleDialog by remember { mutableStateOf(false) }
    var heroStyle by remember { mutableStateOf(HeroStyle.parse(AppPrefs.homeHeroStyle(context))) }
    var heroDialog by remember { mutableStateOf(false) }

    val resolvedDark = when (themeViewModel.mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val dynamicAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val wallpaper = dynamicAvailable && themeViewModel.palette == DYNAMIC_PALETTE_ID

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            if (DownloadLocations.adoptTree(context, uri)) {
                downloadLocation = DownloadLocations.readableLocation(context)
                customFolder = true
            } else {
                Toast.makeText(context, R.string.download_folder_invalid, Toast.LENGTH_SHORT).show()
            }
        }
    }

    CenteredListBox { gutter ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = gutter,
                end = gutter,
                top = contentPadding.calculateTopPadding() + 8.dp,
                bottom = contentPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = stringResource(R.string.nav_settings),
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.semantics { heading() },
                    )
                    Text(
                        text = stringResource(R.string.settings_version, BuildConfig.VERSION_NAME),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item(key = "appearance") {
                val showBottomStyleChoice = navPosition == AppPrefs.NAV_BOTTOM
                val navPositionIndex = if (resolvedDark) 3 else 2
                val styleOffset = if (showBottomStyleChoice) 1 else 0
                val fixedIndex = navPositionIndex + styleOffset + 1
                val dragIndex = fixedIndex + 1
                val heroIndex = dragIndex + 1
                val count = heroIndex + 1
                SettingsGroup(stringResource(R.string.settings_appearance)) {
                    ChoiceRow(
                        index = 0,
                        count = count,
                        icon = Icons.Rounded.DarkMode,
                        title = stringResource(R.string.settings_theme),
                        options = ThemeMode.entries,
                        selected = themeViewModel.mode,
                        label = { mode ->
                            stringResource(
                                when (mode) {
                                    ThemeMode.SYSTEM -> R.string.theme_system
                                    ThemeMode.LIGHT -> R.string.theme_light
                                    ThemeMode.DARK -> R.string.theme_dark
                                }
                            )
                        },
                        onSelect = themeViewModel::updateMode,
                    )
                    NavigationRow(
                        index = 1,
                        count = count,
                        icon = Icons.Rounded.Translate,
                        title = stringResource(R.string.setup_language_title),
                        supporting = languageLabel(appLanguage),
                        onClick = { languageDialog = true },
                    )
                    if (resolvedDark) {
                        SwitchRow(
                            index = 2,
                            count = count,
                            icon = Icons.Rounded.Contrast,
                            title = stringResource(R.string.settings_amoled),
                            supporting = stringResource(R.string.settings_amoled_summary),
                            checked = themeViewModel.amoled,
                            onCheckedChange = themeViewModel::updateAmoled,
                        )
                    }
                    ChoiceRow(
                        index = navPositionIndex,
                        count = count,
                        icon = Icons.Rounded.ViewSidebar,
                        title = stringResource(R.string.settings_navigation),
                        options = listOf(AppPrefs.NAV_SIDE, AppPrefs.NAV_BOTTOM),
                        selected = navPosition,
                        label = { position ->
                            stringResource(
                                if (position == AppPrefs.NAV_SIDE) {
                                    R.string.nav_position_side
                                } else {
                                    R.string.nav_position_bottom
                                }
                            )
                        },
                        onSelect = { position ->
                            AppPrefs.setNavPosition(context, position)
                            navPosition = position
                        },
                    )
                    if (showBottomStyleChoice) ChoiceRow(
                        index = navPositionIndex + 1,
                        count = count,
                        icon = Icons.Rounded.ViewCarousel,
                        title = stringResource(R.string.settings_nav_bar_style),
                        options = listOf(AppPrefs.NAV_BAR_CLOUD, AppPrefs.NAV_BAR_BUBBLE),
                        selected = navBarStyle,
                        label = { style ->
                            stringResource(
                                if (style == AppPrefs.NAV_BAR_BUBBLE) R.string.nav_bar_style_bubble
                                else R.string.nav_bar_style_cloud
                            )
                        },
                        onSelect = { style ->
                            AppPrefs.setNavBarStyle(context, style)
                            navBarStyle = style
                        },
                    )
                    SwitchRow(
                        index = fixedIndex,
                        count = count,
                        icon = Icons.Rounded.ViewSidebar,
                        title = stringResource(R.string.settings_fixed_navigation),
                        supporting = stringResource(R.string.settings_fixed_navigation_summary),
                        checked = fixedNavigation,
                        onCheckedChange = { value ->
                            AppPrefs.setFixedNavigation(context, value)
                            fixedNavigation = value
                        },
                    )
                    SwitchRow(
                        index = dragIndex,
                        count = count,
                        icon = Icons.Rounded.TouchApp,
                        title = stringResource(R.string.settings_nav_drag_switch),
                        supporting = stringResource(R.string.settings_nav_drag_switch_summary),
                        checked = navDragSwitchEnabled,
                        onCheckedChange = { enabled ->
                            AppPrefs.setNavDragSwitchEnabled(context, enabled)
                            navDragSwitchEnabled = enabled
                        },
                    )
                    NavigationRow(
                        index = heroIndex,
                        count = count,
                        icon = Icons.Rounded.ViewCarousel,
                        title = stringResource(R.string.settings_home_hero),
                        supporting = stringResource(heroStyle.labelRes),
                        onClick = { heroDialog = true },
                    )
                }
            }

            item(key = "colors") {
                val firstCategory = if (dynamicAvailable) 1 else 0
                val count = firstCategory + PALETTE_CATEGORIES.size + 2
                SettingsGroup(stringResource(R.string.settings_colors)) {
                    if (dynamicAvailable) {
                        SwitchRow(
                            index = 0,
                            count = count,
                            icon = Icons.Rounded.Palette,
                            title = stringResource(R.string.settings_wallpaper_colors),
                            supporting = stringResource(R.string.settings_wallpaper_colors_summary),
                            checked = wallpaper,
                            onCheckedChange = themeViewModel::setWallpaperColors,
                        )
                    }
                    PALETTE_CATEGORIES.forEachIndexed { categoryIndex, category ->
                        PaletteCategoryRow(
                            index = firstCategory + categoryIndex,
                            count = count,
                            category = category,
                            selectedId = themeViewModel.palette,
                            dimmed = wallpaper,
                            onPick = themeViewModel::updatePalette,
                        )
                    }
                    ButtonAccentPaletteRow(
                        index = firstCategory + PALETTE_CATEGORIES.size,
                        count = count,
                        selectedId = themeViewModel.buttonPalette,
                        // Expose the complete curated accent range, not only a
                        // short fixed row that hides the available choices.
                        options = APP_PALETTES.filterNot { it.id == "black" || it.id == "white" }
                            .map { it.id } + DYNAMIC_PALETTE_ID,
                        dynamicPrimary = if (dynamicAvailable) {
                            if (resolvedDark) dynamicDarkColorScheme(context).primary else dynamicLightColorScheme(context).primary
                        } else MaterialTheme.colorScheme.primary,
                        dynamicSecondary = if (dynamicAvailable) {
                            if (resolvedDark) dynamicDarkColorScheme(context).tertiary else dynamicLightColorScheme(context).tertiary
                        } else MaterialTheme.colorScheme.tertiary,
                        label = { id ->
                            if (id == DYNAMIC_PALETTE_ID) {
                                stringResource(R.string.settings_button_color_system)
                            } else {
                                findPalette(id)?.name ?: id
                            }
                        },
                        onPick = themeViewModel::updateButtonPalette,
                    )
                    NavigationRow(
                        index = count - 1,
                        count = count,
                        icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_palette_style),
                        supporting = stringResource(themeViewModel.style.labelRes),
                        onClick = { styleDialog = true },
                    )
                }
            }

            item(key = "home_catalog") {
                SettingsGroup(stringResource(R.string.settings_home_catalog_mode)) {
                    ChoiceRow(
                        index = 0,
                        count = 1,
                        icon = Icons.Rounded.VideoLibrary,
                        title = stringResource(R.string.settings_home_catalog_mode),
                        options = listOf("grid", "shelf"),
                        selected = homeCatalogMode,
                        label = { mode -> stringResource(if (mode == "shelf") R.string.settings_home_catalog_shelf else R.string.settings_home_catalog_grid) },
                        onSelect = { mode ->
                            AppPrefs.setHomeCatalogMode(context, mode)
                            homeCatalogMode = mode
                        },
                    )
                }
            }

            item(key = "playback") {
                SettingsGroup(stringResource(R.string.settings_playback)) {
                    SwitchRow(
                        index = 0,
                        count = 2,
                        icon = Icons.Rounded.Speed,
                        title = stringResource(R.string.settings_keep_screen_on),
                        supporting = stringResource(R.string.settings_keep_screen_on_summary),
                        checked = keepScreenOn,
                        onCheckedChange = { value ->
                            AppPrefs.setKeepScreenOn(context, value)
                            keepScreenOn = value
                        },
                    )
                    SwitchRow(
                        index = 1,
                        count = 2,
                        icon = Icons.Rounded.FastForward,
                        title = stringResource(R.string.settings_hold_speedup),
                        supporting = stringResource(R.string.settings_hold_speedup_summary),
                        checked = holdToSpeedUp,
                        onCheckedChange = { value ->
                            AppPrefs.setHoldToSpeedUp(context, value)
                            holdToSpeedUp = value
                        },
                    )
                }
            }

            item(key = "player_controls") {
                val count = 7
                SettingsGroup(stringResource(R.string.settings_player_controls)) {
                    SwitchRow(index = 0, count = count, icon = Icons.Rounded.Extension,
                        title = stringResource(R.string.settings_player_show_source),
                        supporting = stringResource(R.string.settings_player_show_source_summary),
                        checked = playerShowSource,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowSourceControl(context, value); playerShowSource = value })
                    SwitchRow(index = 1, count = count, icon = Icons.Rounded.Visibility,
                        title = stringResource(R.string.settings_player_show_lock),
                        supporting = stringResource(R.string.settings_player_show_lock_summary),
                        checked = playerShowLock,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowLockControl(context, value); playerShowLock = value })
                    SwitchRow(index = 2, count = count, icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_player_show_rotate),
                        supporting = stringResource(R.string.settings_player_show_rotate_summary),
                        checked = playerShowRotate,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowRotateControl(context, value); playerShowRotate = value })
                    SwitchRow(index = 3, count = count, icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_player_show_resize),
                        supporting = stringResource(R.string.settings_player_show_resize_summary),
                        checked = playerShowResize,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowResizeControl(context, value); playerShowResize = value })
                    SwitchRow(index = 4, count = count, icon = Icons.Rounded.Visibility,
                        title = stringResource(R.string.settings_player_show_subtitle_offset),
                        supporting = stringResource(R.string.settings_player_show_subtitle_offset_summary),
                        checked = playerShowSubtitleOffset,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowSubtitleOffsetControl(context, value); playerShowSubtitleOffset = value })
                    SwitchRow(index = 5, count = count, icon = Icons.Rounded.VideoLibrary,
                        title = stringResource(R.string.settings_player_show_tracks),
                        supporting = stringResource(R.string.settings_player_show_tracks_summary),
                        checked = playerShowTracks,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowTracksControl(context, value); playerShowTracks = value })
                    SwitchRow(index = 6, count = count, icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_player_compact_controls),
                        supporting = stringResource(R.string.settings_player_compact_controls_summary),
                        checked = playerCompactControls,
                        onCheckedChange = { value -> AppPrefs.setPlayerCompactControls(context, value); playerCompactControls = value })
                }
            }

            item(key = "player_gestures") {
                val count = 9
                SettingsGroup(stringResource(R.string.settings_player_gestures)) {
                    ChoiceRow(index = 0, count = count, icon = Icons.Rounded.TouchApp,
                        title = stringResource(R.string.settings_player_gesture_mode),
                        options = listOf(AppPrefs.PLAYER_GESTURE_CLASSIC, AppPrefs.PLAYER_GESTURE_MARVE),
                        selected = playerGestureMode,
                        label = { mode -> stringResource(if (mode == AppPrefs.PLAYER_GESTURE_CLASSIC) R.string.settings_player_gesture_mode_classic else R.string.settings_player_gesture_mode_marve) },
                        onSelect = { value -> AppPrefs.setPlayerGestureMode(context, value); playerGestureMode = value })
                    SwitchRow(index = 1, count = count, icon = Icons.Rounded.TouchApp,
                        title = stringResource(R.string.settings_player_vertical_swipe),
                        supporting = stringResource(R.string.settings_player_vertical_swipe_summary),
                        checked = playerVerticalSwipe,
                        onCheckedChange = { value -> AppPrefs.setPlayerVerticalSwipeEnabled(context, value); playerVerticalSwipe = value })
                    SwitchRow(index = 2, count = count, icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_player_extra_brightness),
                        supporting = stringResource(R.string.settings_player_extra_brightness_summary),
                        checked = playerExtraBrightness,
                        onCheckedChange = { value -> AppPrefs.setPlayerExtraBrightnessEnabled(context, value); playerExtraBrightness = value })
                    SwitchRow(index = 3, count = count, icon = Icons.Rounded.TouchApp,
                        title = stringResource(R.string.settings_player_horizontal_swipe),
                        supporting = stringResource(R.string.settings_player_horizontal_swipe_summary),
                        checked = playerHorizontalSwipe,
                        onCheckedChange = { value -> AppPrefs.setPlayerHorizontalSwipeEnabled(context, value); playerHorizontalSwipe = value })
                    SwitchRow(index = 4, count = count, icon = Icons.Rounded.FastForward,
                        title = stringResource(R.string.settings_player_double_tap),
                        supporting = stringResource(R.string.settings_player_double_tap_summary),
                        checked = playerDoubleTap,
                        onCheckedChange = { value -> AppPrefs.setPlayerDoubleTapEnabled(context, value); playerDoubleTap = value })
                    SwitchRow(index = 5, count = count, icon = Icons.Rounded.TouchApp,
                        title = stringResource(R.string.settings_player_double_tap_pause),
                        supporting = stringResource(R.string.settings_player_double_tap_pause_summary),
                        checked = playerDoubleTapPause,
                        onCheckedChange = { value -> AppPrefs.setPlayerDoubleTapPauseEnabled(context, value); playerDoubleTapPause = value })
                    ChoiceRow(index = 6, count = count, icon = Icons.Rounded.FastForward,
                        title = stringResource(R.string.settings_player_seek_duration),
                        options = listOf(5, 10, 15, 20), selected = playerSeekSeconds,
                        label = { seconds -> stringResource(R.string.player_seek_seconds, seconds) },
                        onSelect = { value -> AppPrefs.setPlayerSeekSeconds(context, value); playerSeekSeconds = value })
                    ChoiceRow(index = 7, count = count, icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_player_progress_style),
                        options = listOf("slim", "standard", "bold"), selected = playerProgressStyle,
                        label = { value -> stringResource(when (value) { "slim" -> R.string.player_progress_style_slim; "bold" -> R.string.player_progress_style_bold; else -> R.string.player_progress_style_standard }) },
                        onSelect = { value -> AppPrefs.setPlayerProgressStyle(context, value); playerProgressStyle = value })
                    SwitchRow(index = 8, count = count, icon = Icons.Rounded.FastForward,
                        title = stringResource(R.string.settings_player_show_seek_buttons),
                        supporting = stringResource(R.string.settings_player_show_seek_buttons_summary),
                        checked = playerShowSeekButtons,
                        onCheckedChange = { value -> AppPrefs.setPlayerShowSeekButtons(context, value); playerShowSeekButtons = value })
                }
            }

            item(key = "watch_statistics") {
                val duration = watchDurationParts(totalWatchMs)
                val watchTimeLabel = when {
                    duration.years > 0L -> stringResource(R.string.watch_statistics_time_value_years, duration.years, duration.months, duration.days, duration.hours, duration.minutes)
                    duration.months > 0L -> stringResource(R.string.watch_statistics_time_value_months, duration.months, duration.days, duration.hours, duration.minutes)
                    duration.days > 0L -> stringResource(R.string.watch_statistics_time_value_days, duration.days, duration.hours, duration.minutes)
                    else -> stringResource(R.string.watch_statistics_time_value, duration.hours, duration.minutes)
                }
                val watchedMovies = watchedMovieCount(watchedKeys)
                val watchedEpisodes = watchedEpisodeCount(watchedKeys)
                val watchedSeries = watchedSeriesCount(watchedKeys)
                SettingsGroup(stringResource(R.string.watch_statistics_title)) {
                    SwitchRow(index = 0, count = if (watchStatisticsEnabled) 5 else 1, icon = Icons.Rounded.Visibility,
                        title = stringResource(R.string.settings_watch_statistics_enabled),
                        supporting = stringResource(R.string.settings_watch_statistics_enabled_summary),
                        checked = watchStatisticsEnabled,
                        onCheckedChange = { value -> AppPrefs.setWatchStatisticsEnabled(context, value); watchStatisticsEnabled = value; if (value) totalWatchMs = WatchStatsStore.current(context) })
                    if (watchStatisticsEnabled) {
                        InfoRow(index = 1, count = 5, icon = Icons.Rounded.History,
                            title = stringResource(R.string.watch_statistics_time), supporting = watchTimeLabel)
                        InfoRow(index = 2, count = 5, icon = Icons.Rounded.Visibility,
                            title = stringResource(R.string.watch_statistics_episodes), supporting = stringResource(R.string.watch_statistics_count, watchedEpisodes))
                        InfoRow(index = 3, count = 5, icon = Icons.Rounded.Theaters,
                            title = stringResource(R.string.watch_statistics_movies), supporting = stringResource(R.string.watch_statistics_count, watchedMovies))
                        InfoRow(index = 4, count = 5, icon = Icons.Rounded.VideoLibrary,
                            title = stringResource(R.string.watch_statistics_series), supporting = stringResource(R.string.watch_statistics_count, watchedSeries))
                    }
                }
            }

            item(key = "downloads") {
                val count = 3 + if (customFolder) 1 else 0
                SettingsGroup(stringResource(R.string.settings_downloads)) {
                    NavigationRow(
                        index = 0,
                        count = count,
                        icon = Icons.Rounded.Folder,
                        title = stringResource(R.string.download_location),
                        supporting = downloadLocation,
                        onClick = { pickFolder.launch(null) },
                    )
                    if (customFolder) {
                        NavigationRow(
                            index = 1,
                            count = count,
                            icon = Icons.Rounded.Restore,
                            title = stringResource(R.string.download_location_reset),
                            supporting = stringResource(R.string.download_location_reset_summary),
                            onClick = {
                                AppPrefs.setDownloadTreeUri(context, null)
                                downloadLocation = DownloadLocations.readableLocation(context)
                                customFolder = false
                            },
                        )
                    }
                    SwitchRow(
                        index = if (customFolder) 2 else 1,
                        count = count,
                        icon = Icons.Rounded.Wifi,
                        title = stringResource(R.string.download_wifi_only),
                        supporting = stringResource(R.string.download_wifi_summary),
                        checked = downloadWifiOnly,
                        onCheckedChange = { value ->
                            AppPrefs.setDownloadWifiOnly(context, value)
                            downloadWifiOnly = value
                            DownloadService.ensure(context)
                        },
                    )
                    ChoiceRow(
                        index = if (customFolder) 3 else 2,
                        count = count,
                        icon = Icons.Rounded.Download,
                        title = stringResource(R.string.download_max_concurrent),
                        options = listOf(1, 2, 3),
                        selected = downloadConcurrent,
                        label = { it.toString() },
                        onSelect = { value ->
                            AppPrefs.setDownloadMaxConcurrent(context, value)
                            downloadConcurrent = value
                            DownloadService.ensure(context)
                        },
                    )
                }
            }

            item(key = "privacy") {
                SettingsGroup(stringResource(R.string.settings_privacy_history)) {
                    SwitchRow(
                        index = 0,
                        count = 2,
                        icon = Icons.Rounded.History,
                        title = stringResource(R.string.settings_pause_history),
                        supporting = stringResource(R.string.settings_pause_history_summary),
                        checked = pauseHistory,
                        onCheckedChange = { value ->
                            AppPrefs.setPauseHistory(context, value)
                            pauseHistory = value
                        },
                    )
                    NavigationRow(
                        index = 1,
                        count = 2,
                        icon = Icons.Rounded.Search,
                        title = stringResource(R.string.settings_clear_search_history),
                        supporting = stringResource(R.string.settings_clear_search_history_summary),
                        onClick = {
                            SearchHistoryStore.clear(context)
                            Toast.makeText(
                                context,
                                R.string.search_history_cleared,
                                Toast.LENGTH_SHORT,
                            ).show()
                        },
                    )
                }
            }

            item(key = "extensions") {
                SettingsGroup(stringResource(R.string.nav_extensions)) {
                    SwitchRow(
                        index = 0,
                        count = 1,
                        icon = Icons.Rounded.Extension,
                        title = stringResource(R.string.settings_auto_update),
                        supporting = stringResource(R.string.settings_auto_update_summary),
                        checked = autoUpdate,
                        onCheckedChange = { value ->
                            AppPrefs.setAutoUpdate(context, value)
                            autoUpdate = value
                        },
                    )
                }
            }

            item(key = "about") {
                SettingsGroup(stringResource(R.string.settings_about)) {
                    val count = 5
                    InfoRow(
                        index = 0,
                        count = count,
                        icon = Icons.Rounded.Info,
                        title = stringResource(R.string.app_name),
                        supporting = stringResource(R.string.settings_version, BuildConfig.VERSION_NAME),
                    )
                    AboutFooterRow(index = 1, count = count)
                    NavigationRow(
                        index = 2,
                        count = count,
                        icon = Icons.Rounded.Code,
                        title = stringResource(R.string.settings_github_title),
                        supporting = stringResource(R.string.settings_github_summary),
                        onClick = { openLink(GITHUB_URL) },
                    )
                    NavigationRow(
                        index = 3,
                        count = count,
                        icon = Icons.Rounded.VolunteerActivism,
                        title = stringResource(R.string.settings_donate_title),
                        supporting = stringResource(R.string.settings_donate_summary),
                        onClick = { openLink(DONATE_URL) },
                    )
                    NavigationRow(
                        index = 4,
                        count = count,
                        icon = Icons.AutoMirrored.Rounded.Send,
                        title = stringResource(R.string.settings_telegram_title),
                        supporting = stringResource(R.string.settings_telegram_summary),
                        onClick = { openLink(TELEGRAM_URL) },
                    )
                }
            }
        }
    }

    if (languageDialog) {
        ChoiceDialog(
            title = stringResource(R.string.setup_language_title),
            options = listOf(AppPrefs.LANGUAGE_SYSTEM, "en", "ar"),
            selected = appLanguage,
            icon = Icons.Rounded.Translate,
            label = { tag -> languageLabel(tag) },
            onSelect = { tag ->
                AppPrefs.setAppLanguage(context, tag)
                appLanguage = tag
                languageDialog = false
                AppPrefs.applyAppLanguage(context)
            },
            onDismiss = { languageDialog = false },
        )
    }

    if (styleDialog) {
        ChoiceDialog(
            title = stringResource(R.string.settings_palette_style),
            options = PaletteStyle.entries,
            selected = themeViewModel.style,
            icon = Icons.Rounded.Tune,
            label = { style -> stringResource(style.labelRes) },
            onSelect = { style ->
                themeViewModel.updateStyle(style)
                styleDialog = false
            },
            onDismiss = { styleDialog = false },
        )
    }

    if (heroDialog) {
        ChoiceDialog(
            title = stringResource(R.string.settings_home_hero),
            options = HeroStyle.entries,
            selected = heroStyle,
            icon = Icons.Rounded.ViewCarousel,
            label = { style -> stringResource(style.labelRes) },
            description = { style -> stringResource(style.descriptionRes) },
            onSelect = { style ->
                AppPrefs.setHomeHeroStyle(context, style.storageId)
                heroStyle = style
                heroDialog = false
            },
            onDismiss = { heroDialog = false },
        )
    }
}

@Composable
private fun languageLabel(tag: String): String = stringResource(
    when (tag) {
        "en" -> R.string.setup_language_english
        "ar" -> R.string.setup_language_arabic
        else -> R.string.setup_language_system
    }
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun ButtonAccentPaletteRow(
    index: Int,
    count: Int,
    selectedId: String,
    options: List<String>,
    dynamicPrimary: Color,
    dynamicSecondary: Color,
    label: @Composable (String) -> String,
    onPick: (String) -> Unit,
) {
    Surface(
        shape = ListItemDefaults.segmentedShapes(index = index, count = count).shape,
        color = MaterialTheme.colorScheme.surfaceBright,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = stringResource(R.string.settings_button_color),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = stringResource(R.string.settings_button_color_summary),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            options.chunked(3).forEach { optionRow ->
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    optionRow.forEach { id ->
                        val palette = findPalette(id)
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            Swatch(
                                first = palette?.seedPrimary ?: dynamicPrimary,
                                second = palette?.seedTertiary ?: dynamicSecondary,
                                selected = id == selectedId,
                                label = label(id),
                                onClick = { onPick(id) },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                    repeat(3 - optionRow.size) { Box(Modifier.weight(1f)) }
                }
            }
        }
    }
}


/**
 * One palette category inside the Colors card. The swatches stay tappable
 * while wallpaper colors are on; a tap turns the switch off and takes that
 * seed, which is the shortest way out of the disabled state.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun PaletteCategoryRow(
    index: Int,
    count: Int,
    category: String,
    selectedId: String,
    dimmed: Boolean,
    onPick: (String) -> Unit,
) {
    Surface(
        shape = ListItemDefaults.segmentedShapes(index = index, count = count).shape,
        color = MaterialTheme.colorScheme.surfaceBright,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .graphicsLayer { alpha = if (dimmed) 0.45f else 1f },
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = category,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(APP_PALETTES.filter { it.category == category }, key = { it.id }) { palette ->
                    Swatch(
                        first = palette.seedPrimary,
                        second = palette.seedTertiary,
                        selected = palette.id == selectedId,
                        label = palette.name,
                        onClick = { onPick(palette.id) },
                    )
                }
            }
        }
    }
}

/** A round preview of a palette: two of its seed colors side by side. */
@Composable
private fun Swatch(
    first: Color,
    second: Color,
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(first, second)))
                .border(
                    border = BorderStroke(
                        width = if (selected) 3.dp else 1.dp,
                        color = if (selected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.outlineVariant
                        },
                    ),
                    shape = CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = contrastInk(first),
                    modifier = Modifier.size(24.dp),
                )
            }
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun AboutFooterRow(index: Int, count: Int) {
    Surface(
        shape = ListItemDefaults.segmentedShapes(index = index, count = count).shape,
        color = MaterialTheme.colorScheme.surfaceBright,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = stringResource(R.string.about_text),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = stringResource(R.string.about_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = stringResource(R.string.about_nuvio),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
