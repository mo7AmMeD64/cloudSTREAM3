package com.kodastream.app.data

/** Single source of truth for the seek intervals offered by player settings. */
internal val PLAYER_SEEK_INTERVALS_SECONDS = listOf(5, 10, 15, 20)

/**
 * Resolve persisted or externally supplied values to one of the actual UI choices.
 * Ties intentionally choose the shorter interval to avoid an unexpected large seek.
 */
internal fun normalizePlayerSeekSeconds(value: Int): Int =
    PLAYER_SEEK_INTERVALS_SECONDS.minWithOrNull(
        compareBy<Int> { kotlin.math.abs(it.toLong() - value.toLong()) }.thenBy { it },
    ) ?: 10
