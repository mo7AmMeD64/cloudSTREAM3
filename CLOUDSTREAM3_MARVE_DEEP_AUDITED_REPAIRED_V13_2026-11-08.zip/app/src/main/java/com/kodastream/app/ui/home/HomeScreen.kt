package com.kodastream.app.ui.home

import android.app.Application
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kodastream.app.R
import com.kodastream.app.data.AppPrefs
import com.kodastream.app.engine.Engine
import com.kodastream.app.engine.readableMessage
import com.kodastream.app.ui.components.EmptyBox
import com.kodastream.app.ui.components.ErrorBox
import com.kodastream.app.ui.components.ExpressivePullToRefresh
import com.kodastream.app.ui.components.LoadingBox
import com.kodastream.app.ui.components.PosterCard
import com.kodastream.app.ui.components.PosterShelfSkeleton
import com.kodastream.app.ui.components.SectionHeader
import com.kodastream.app.ui.components.SkeletonBox
import com.kodastream.app.ui.components.SkeletonPulseProvider
import com.kodastream.app.ui.components.staggeredEnter
import com.kodastream.app.ui.home.hero.HeroStyle
import com.kodastream.app.ui.home.hero.HomeHeroReservedSpace
import com.kodastream.app.ui.home.hero.HomeHeroSection
import com.kodastream.app.ui.home.hero.LocalScreenActive
import com.kodastream.app.ui.home.hero.rememberHeroStretchState
import com.kodastream.app.ui.home.hero.rememberHomeHeroState
import com.kodastream.app.ui.home.hero.toHeroItem
import com.kodastream.app.ui.sources.SourceViewModel
import com.kodastream.app.ui.theme.ArtworkStatusBarIcons
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.metaproviders.TmdbProvider
import com.lagradost.cloudstream3.MainPageData
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.plugins.PluginManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

@Immutable
data class HomeRow(
    val key: String,
    val title: String,
    val items: List<SearchResponse>,
    val horizontal: Boolean,
    /** Index in `api.mainPage`, so an expanded page can request the same section. */
    val pageIndex: Int,
    /** The last page loaded into [items]. */
    val page: Int,
    val hasNext: Boolean,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val _providers = MutableStateFlow(Engine.homeProviders())
    val providers: StateFlow<List<MainAPI>> = _providers.asStateFlow()

    /** The provider currently loaded; set only by [setSource], never chosen here. */
    private val _selected = MutableStateFlow<String?>(null)
    val selected: StateFlow<String?> = _selected.asStateFlow()

    private val _rows = MutableStateFlow<List<HomeRow>>(emptyList())
    val rows: StateFlow<List<HomeRow>> = _rows.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    /** Additional works loaded page-by-page from the currently selected source. */
    private val _catalogItems = MutableStateFlow<List<SearchResponse>>(emptyList())
    val catalogItems: StateFlow<List<SearchResponse>> = _catalogItems.asStateFlow()
    private val _catalogLoading = MutableStateFlow(false)
    val catalogLoading: StateFlow<Boolean> = _catalogLoading.asStateFlow()
    private val _catalogHasMore = MutableStateFlow(false)
    val catalogHasMore: StateFlow<Boolean> = _catalogHasMore.asStateFlow()
    private val _catalogFailed = MutableStateFlow(false)
    val catalogFailed: StateFlow<Boolean> = _catalogFailed.asStateFlow()

    private data class CatalogPageSource(
        val index: Int,
        val page: MainPageData,
        val nextPage: Int,
        val stalePages: Int = 0,
    )

    private var catalogSources: List<CatalogPageSource> = emptyList()
    private var catalogJob: Job? = null
    private var catalogGeneration: Long = 0L
    private var activeApi: MainAPI? = null

    /**
     * The hero comes from the first shelf that has enough posters, preferring
     * a portrait row. Derived here so composition never walks the shelves,
     * and cached eagerly because the Home screen reads it right away.
     */
    val hero: StateFlow<List<SearchResponse>> = _rows
        .map { rows ->
            rows.sortedBy { it.horizontal }
                .firstOrNull { row -> row.items.count { !it.posterUrl.isNullOrBlank() } >= 3 }
                ?.items
                .orEmpty()
                .filter { !it.posterUrl.isNullOrBlank() }
                .distinctBy { it.url }
                .take(8)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var loadJob: Job? = null

    init {
        viewModelScope.launch {
            // Runs again every time an extension is installed, updated or removed.
            PluginManager.revision.collect { _providers.value = Engine.homeProviders() }
        }
    }

    /**
     * Loads the name the source owner resolved. An equal name is a no-op, so a
     * revision that does not change the selection never cancels a running load.
     */
    fun setSource(name: String?) {
        if (name == _selected.value) return
        _selected.value = name
        if (name == null) {
            activeApi = null
            loadJob?.cancel()
            catalogGeneration++
            catalogJob?.cancel()
            catalogJob = null
            catalogSources = emptyList()
            _catalogItems.value = emptyList()
            _catalogLoading.value = false
            _catalogHasMore.value = false
            _catalogFailed.value = false
            _rows.value = emptyList()
            _loading.value = false
            _error.value = null
            return
        }
        val api = Engine.provider(name)
        if (api == null || !api.hasMainPage) {
            activeApi = api
            loadJob?.cancel()
            catalogGeneration++
            catalogJob?.cancel()
            catalogJob = null
            catalogSources = emptyList()
            _catalogItems.value = emptyList()
            _catalogLoading.value = false
            _catalogHasMore.value = false
            _catalogFailed.value = false
            _rows.value = emptyList()
            _loading.value = false
            _error.value = null
            return
        }
        load(api)
    }

    fun retry() {
        val api = Engine.provider(_selected.value) ?: return
        load(api)
    }

    private fun load(api: MainAPI) {
        activeApi = api
        loadJob?.cancel()
        // Invalidate every earlier home/catalog request before starting this load.
        // Engine providers are extension code and may not always cooperate with
        // coroutine cancellation, so every result below is also generation-guarded.
        val generation = ++catalogGeneration
        catalogJob?.cancel()
        catalogJob = null
        loadJob = viewModelScope.launch {
            _loading.value = true
            _error.value = null
            _rows.value = emptyList()
            _catalogItems.value = emptyList()
            _catalogLoading.value = false
            _catalogHasMore.value = false
            _catalogFailed.value = false
            catalogSources = emptyList()

            val pages = api.mainPage
            val results = arrayOfNulls<List<HomeRow>>(pages.size)
            val nextSources = java.util.concurrent.ConcurrentHashMap<Int, CatalogPageSource>()
            var lastFailure: String? = null
            val gate = Semaphore(if (api.sequentialMainPage) 1 else 3)

            coroutineScope {
                pages.forEachIndexed { index, page ->
                    launch {
                        gate.withPermit {
                            val result = Engine.mainPage(api, page)
                            result.onSuccess { response ->
                                if (generation != catalogGeneration || activeApi !== api) return@onSuccess
                                results[index] = response.lists
                                    .mapNotNull { list ->
                                        val owned = list.list.filter { item ->
                                            item.apiName == api.name ||
                                                (api is TmdbProvider && item.apiName.isNotBlank() && Engine.provider(item.apiName) != null)
                                        }.distinctBy { it.apiName to it.url }
                                        if (owned.isEmpty()) null else list to owned
                                    }
                                    .mapIndexed { i, (list, owned) ->
                                        HomeRow(
                                            key = "$index-$i-${list.name}",
                                            title = list.name.ifBlank { page.name },
                                            items = owned,
                                            horizontal = list.isHorizontalImages,
                                            pageIndex = index,
                                            page = 1,
                                            hasNext = response.hasNext,
                                        )
                                    }
                                val sourceHasItems = response.lists.any { list ->
                                    list.list.any { item ->
                                        item.apiName == api.name ||
                                            (api is TmdbProvider && item.apiName.isNotBlank() && Engine.provider(item.apiName) != null)
                                    }
                                }
                                if (response.hasNext && sourceHasItems) {
                                    nextSources[index] = CatalogPageSource(index, page, 2)
                                }
                                _rows.value = results.filterNotNull().flatten()
                            }
                            result.onFailure {
                                if (generation == catalogGeneration && activeApi === api) {
                                    lastFailure = it.readableMessage()
                                }
                            }
                        }
                    }
                }
            }

            if (generation == catalogGeneration && activeApi === api) {
                _loading.value = false
                catalogSources = nextSources.values.sortedBy { it.index }
                _catalogHasMore.value = catalogSources.isNotEmpty()
                if (_rows.value.isEmpty()) {
                    _error.value = lastFailure ?: ""
                }
            }
        }
    }

    /** Loads another page for each original provider shelf, merging unseen works only. */
    fun loadMoreCatalog(retry: Boolean = false) {
        if (_catalogLoading.value || !_catalogHasMore.value || (_catalogFailed.value && !retry)) return
        val requestedName = _selected.value ?: return
        val api = Engine.provider(requestedName) ?: return
        if (activeApi !== api) return
        val sources = catalogSources
        if (sources.isEmpty()) {
            _catalogHasMore.value = false
            return
        }
        catalogJob?.cancel()
        val generation = ++catalogGeneration
        catalogJob = viewModelScope.launch {
            _catalogLoading.value = true
            _catalogFailed.value = false
            val failedSources = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
            val gate = Semaphore(if (api.sequentialMainPage) 1 else 3)
            val nextSources = java.util.concurrent.ConcurrentHashMap<Int, CatalogPageSource>()
            // Page requests may finish in a different order; retain each page by
            // source index so the All catalogue follows the provider's stable order.
            val receivedBySource = java.util.concurrent.ConcurrentHashMap<Int, List<SearchResponse>>()
            val known = (_rows.value.flatMap { it.items } + _catalogItems.value)
                .mapTo(HashSet()) { it.apiName to it.url }
            coroutineScope {
                sources.forEach { source ->
                    launch {
                        gate.withPermit {
                            val result = Engine.mainPage(api, source.page, source.nextPage)
                            result.onSuccess { response ->
                                val pageItems = response.lists.flatMap { it.list }
                                    .filter { item ->
                                        item.apiName == requestedName ||
                                            (api is TmdbProvider && item.apiName.isNotBlank() && Engine.provider(item.apiName) != null)
                                    }
                                    .distinctBy { it.apiName to it.url }
                                receivedBySource[source.index] = pageItems
                                val hasFresh = pageItems.any { (it.apiName to it.url) !in known }
                                val stale = if (hasFresh) 0 else source.stalePages + 1
                                if (response.hasNext && pageItems.isNotEmpty() && stale < 2 && source.nextPage < 100) {
                                    nextSources[source.index] = source.copy(nextPage = source.nextPage + 1, stalePages = stale)
                                }
                            }.onFailure {
                                // Retain a failed cursor and expose an explicit retry instead
                                // of repeatedly launching a failing request while at list end.
                                failedSources += source.index
                                nextSources[source.index] = source
                            }
                        }
                    }
                }
            }
            if (_selected.value == requestedName && activeApi === api && generation == catalogGeneration) {
                val existing = (_rows.value.flatMap { it.items } + _catalogItems.value)
                    .mapTo(HashSet()) { it.apiName to it.url }
                val received = receivedBySource.toSortedMap().values.flatten()
                val fresh = received.filter { existing.add(it.apiName to it.url) }
                _catalogItems.value = _catalogItems.value + fresh
                catalogSources = nextSources.values.sortedBy { it.index }
                _catalogHasMore.value = catalogSources.isNotEmpty()
                _catalogFailed.value = failedSources.isNotEmpty()
            }
            if (generation == catalogGeneration) _catalogLoading.value = false
        }
    }
}

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    onOpenItem: (SearchResponse) -> Unit,
    onOpenExtensions: () -> Unit,
    onOpenSources: () -> Unit,
    sourceViewModel: SourceViewModel,
    expandedViewModel: ExpandedHomeViewModel,
    onOpenSection: () -> Unit,
    onOpenCatalog: () -> Unit,
    viewModel: HomeViewModel,
) {
    val providers by viewModel.providers.collectAsState()
    val selected by viewModel.selected.collectAsState()
    val rows by viewModel.rows.collectAsState()
    val hero by viewModel.hero.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()
    val catalogItems by viewModel.catalogItems.collectAsState()
    val catalogLoading by viewModel.catalogLoading.collectAsState()
    val catalogHasMore by viewModel.catalogHasMore.collectAsState()
    val catalogFailed by viewModel.catalogFailed.collectAsState()
    val sections by expandedViewModel.sections.collectAsState()
    val startupDone by PluginManager.startupDone.collectAsState()
    val sourceName by sourceViewModel.home.collectAsState()

    // One direction: the source owner resolves the name, Home only loads it.
    LaunchedEffect(sourceName) { viewModel.setSource(sourceName) }
    // A different provider invalidates every paged section and its page indexes.
    LaunchedEffect(selected) { expandedViewModel.setProvider(selected) }

    Box(Modifier.fillMaxSize()) {
        when {
            providers.isEmpty() && !startupDone -> LoadingBox(Modifier.padding(contentPadding))

            providers.isEmpty() -> EmptyBox(
                title = stringResource(R.string.home_empty_title),
                hint = stringResource(R.string.home_empty_hint),
                modifier = Modifier.padding(contentPadding),
            ) {
                Button(onClick = onOpenExtensions) { Text(stringResource(R.string.open_extensions)) }
            }

            // The owner is still resolving the saved source; do not show a
            // different provider's shelves in the meantime.
            selected == null -> LoadingBox(Modifier.padding(contentPadding))

            else -> ExpressivePullToRefresh(
                isRefreshing = loading,
                onRefresh = {
                    // Fresh source lists make every paged copy stale.
                    expandedViewModel.reset()
                    viewModel.retry()
                },
            ) {
                HomeShelves(
                    selectedSource = selected,
                    rows = rows,
                    hero = hero,
                    loading = loading,
                    error = error,
                    catalogItems = catalogItems,
                    catalogLoading = catalogLoading,
                    catalogHasMore = catalogHasMore,
                    catalogFailed = catalogFailed,
                    onLoadMoreCatalog = { viewModel.loadMoreCatalog() },
                    onRetryCatalog = { viewModel.loadMoreCatalog(retry = true) },
                    onOpenCatalog = onOpenCatalog,
                    sections = sections,
                    contentPadding = contentPadding,
                    onOpenSources = onOpenSources,
                    onOpenItem = onOpenItem,
                    onRetry = viewModel::retry,
                    onViewMore = { row ->
                        val provider = selected
                        if (provider != null) {
                            expandedViewModel.open(provider, row)
                            onOpenSection()
                        }
                    },
                )
            }
        }
    }
}

/**
 * The shelves themselves, split out of the pull-to-refresh wrapper so the
 * refresh container is not recomposed on every provider switch.
 */
@Composable
private fun HomeShelves(
    selectedSource: String?,
    rows: List<HomeRow>,
    hero: List<SearchResponse>,
    loading: Boolean,
    error: String?,
    catalogItems: List<SearchResponse>,
    catalogLoading: Boolean,
    catalogHasMore: Boolean,
    catalogFailed: Boolean,
    onLoadMoreCatalog: () -> Unit,
    onRetryCatalog: () -> Unit,
    onOpenCatalog: () -> Unit,
    sections: Map<String, ExpandedSection>,
    contentPadding: PaddingValues,
    onOpenSources: () -> Unit,
    onOpenItem: (SearchResponse) -> Unit,
    onRetry: () -> Unit,
    onViewMore: (HomeRow) -> Unit,
) {
    val context = LocalContext.current
    val screenActive = LocalScreenActive.current
    // Re-read on return, so a Settings change applies without an app restart.
    val heroStyle = remember(screenActive) { HeroStyle.parse(AppPrefs.homeHeroStyle(context)) }
    val isCinematic = heroStyle == HeroStyle.CINEMATIC
    val showCinematicHero = isCinematic && (hero.isNotEmpty() || loading)
    val heroItems = remember(hero) { hero.map { it.toHeroItem() } }
    val cinematicHeroItems = if (isCinematic) {
        rememberHomeHeroState(heroItems, selectedSource)
    } else {
        heroItems
    }
    val chooseSourceLabel = stringResource(R.string.cd_choose_source)
    val listState = rememberLazyListState()
    val topInset = with(LocalDensity.current) { contentPadding.calculateTopPadding().roundToPx() }
    val heroUnderBar by remember(listState, topInset) {
        derivedStateOf {
            listState.layoutInfo.visibleItemsInfo
                .firstOrNull { it.key == "hero" }
                ?.let { it.offset < topInset } == true
        }
    }
    ArtworkStatusBarIcons(overArtwork = heroUnderBar && !(isCinematic && hero.isEmpty()))

    // The final All section is a combined catalogue for this selected source:
    // it includes the original shelf items and every additional page, without
    // repeating the same provider/title identity inside the combined view.
    val catalogMode = remember(screenActive) { AppPrefs.homeCatalogMode(context) }
    val allSourceWorks = remember(rows, catalogItems, selectedSource) {
        (rows.flatMap { it.items } + catalogItems).distinctBy { it.apiName to it.url }
    }
    val allSourceWorkRows = remember(allSourceWorks) { allSourceWorks.chunked(3) }
    val catalogShelfState = rememberLazyListState()
    val pagingHasMore by rememberUpdatedState(catalogHasMore)
    val pagingLoading by rememberUpdatedState(catalogLoading)
    val pagingFailed by rememberUpdatedState(catalogFailed)
    val pagingLoadMore by rememberUpdatedState(onLoadMoreCatalog)
    LaunchedEffect(listState, catalogMode) {
        if (catalogMode != "grid") return@LaunchedEffect
        snapshotFlow {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            Triple(last to info.totalItemsCount, pagingHasMore, pagingLoading to pagingFailed)
        }.distinctUntilChanged().collect { (range, hasMore, state) ->
            val (last, total) = range
            val (isLoading, hasFailed) = state
            val nearEnd = total > 0 && last >= (total - 4).coerceAtLeast(0)
            if (nearEnd && hasMore && !isLoading && !hasFailed) pagingLoadMore()
        }
    }
    LaunchedEffect(catalogMode, allSourceWorks.size, catalogHasMore, catalogLoading, catalogFailed) {
        if (catalogMode == "shelf" && allSourceWorks.isEmpty() && catalogHasMore && !catalogLoading && !catalogFailed) {
            onLoadMoreCatalog()
        }
    }
    LaunchedEffect(catalogShelfState, catalogMode) {
        if (catalogMode != "shelf") return@LaunchedEffect
        snapshotFlow {
            val info = catalogShelfState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            Triple(last to info.totalItemsCount, pagingHasMore, pagingLoading to pagingFailed)
        }.distinctUntilChanged().collect { (range, hasMore, state) ->
            val (last, total) = range
            val (isLoading, hasFailed) = state
            val nearEnd = total > 0 && last >= total - 4
            if (nearEnd && hasMore && !isLoading && !hasFailed) pagingLoadMore()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val stretchState = if (isCinematic) rememberHeroStretchState(listState) else null
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (stretchState != null) {
                        Modifier.nestedScroll(stretchState.nestedScrollConnection)
                    } else {
                        Modifier
                    },
                ),
            contentPadding = PaddingValues(
                top = if (showCinematicHero) 0.dp else contentPadding.calculateTopPadding(),
                bottom = contentPadding.calculateBottomPadding() + 16.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (showCinematicHero) {
                item(key = "hero") {
                    Crossfade(
                        targetState = hero.isEmpty(),
                        animationSpec = tween(320),
                        label = "HomeHeroLoading",
                    ) { empty ->
                        if (empty) {
                            HomeHeroReservedSpace(viewportHeight = maxHeight)
                        } else {
                            HomeHeroSection(
                                items = cinematicHeroItems,
                                viewportHeight = maxHeight,
                                mobileBelowSectionHeightHint = null,
                                listState = listState,
                                stretchPx = { stretchState?.stretchPx ?: 0f },
                                onItemClick = { item -> item.source?.let(onOpenItem) },
                            )
                        }
                    }
                }
            }

            item(key = "title") {
                Column(
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.home_title),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.semantics { heading() },
                    )
                    // With the chip row gone, this line names the provider and opens the sheet.
                    if (selectedSource != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(MaterialTheme.shapes.small)
                                .clickable(onClickLabel = chooseSourceLabel, onClick = onOpenSources),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = selectedSource,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }

            if (!showCinematicHero && hero.isNotEmpty() && heroStyle != HeroStyle.OFF) {
                item(key = "hero") {
                    HomeHero(items = hero, onOpen = onOpenItem)
                }
            }

            if (rows.isEmpty() && loading) {
                // The carousel needs its own placeholder; the cinematic hero
                // already reserved the exact same space above the title.
                item(key = "skeleton") {
                    SkeletonPulseProvider {
                        Column {
                            if (heroStyle == HeroStyle.CAROUSEL) {
                                SkeletonBox(
                                    modifier = Modifier
                                        .padding(horizontal = 16.dp)
                                        .fillMaxWidth()
                                        .height(480.dp),
                                    shape = MaterialTheme.shapes.extraLarge,
                                )
                                Spacer(Modifier.height(24.dp))
                            }
                            SkeletonBox(
                                modifier = Modifier
                                    .padding(start = 16.dp)
                                    .size(width = 160.dp, height = 24.dp),
                                shape = MaterialTheme.shapes.small,
                            )
                            Spacer(Modifier.height(12.dp))
                            PosterShelfSkeleton()
                        }
                    }
                }
            } else if (rows.isEmpty()) {
                item(key = "error") {
                    Box(Modifier.fillMaxWidth().height(360.dp)) {
                        ErrorBox(
                            message = error?.takeIf { it.isNotBlank() }
                                ?: stringResource(R.string.nothing_found),
                            onRetry = onRetry,
                        )
                    }
                }
            }

            itemsIndexed(
                items = rows,
                key = { _, row -> row.key },
                contentType = { _, _ -> "shelf" },
            ) { index, row ->
                // The expanded screen turns hasNext off when a page ends or fails,
                // and that hides the button here without reloading Home.
                val canViewMore = row.hasNext &&
                    sections[sectionKey(selectedSource.orEmpty(), row.key)]?.hasNext != false
                val viewMore: (() -> Unit)? = if (canViewMore) ({ onViewMore(row) }) else null
                // The first three shelves rise in once; later ones just appear, and
                // a provider switch reuses the already-settled rows.
                if (index < 3) {
                    val entrance = remember { MutableTransitionState(false).apply { targetState = true } }
                    AnimatedVisibility(
                        visibleState = entrance,
                        enter = staggeredEnter(index),
                    ) {
                        Shelf(row = row, onOpenItem = onOpenItem, onViewMore = viewMore)
                    }
                } else {
                    Shelf(row = row, onOpenItem = onOpenItem, onViewMore = viewMore)
                }
            }

            if (rows.isNotEmpty() && loading) {
                item(key = "more") {
                    Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        LoadingIndicator(Modifier.size(32.dp))
                    }
                }
            }

            if (rows.isNotEmpty()) {
                item(key = "all_source_header") {
                    SectionHeader(
                        stringResource(R.string.home_catalog_all),
                        onViewMore = onOpenCatalog,
                    )
                }
                if (catalogMode == "shelf") {
                    item(key = "all_source_shelf") {
                        LazyRow(
                            state = catalogShelfState,
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            items(items = allSourceWorks, key = { "all|${it.apiName}|${it.url}" }) { item ->
                                PosterCard(item = item, onClick = { onOpenItem(item) }, cardWidth = 128.dp)
                            }
                            if (catalogLoading) item(key = "all_source_loading") { LoadingIndicator(Modifier.padding(16.dp).size(28.dp)) }
                        }
                    }
                } else {
                    itemsIndexed(
                        items = allSourceWorkRows,
                        key = { index, chunk -> "all_grid_${index}_${chunk.firstOrNull()?.url.orEmpty()}" },
                    ) { _, chunk ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            repeat(3) { column ->
                                val item = chunk.getOrNull(column)
                                if (item == null) {
                                    Spacer(Modifier.weight(1f))
                                } else {
                                    Box(Modifier.weight(1f)) {
                                        PosterCard(item = item, onClick = { onOpenItem(item) }, modifier = Modifier.fillMaxWidth(), cardWidth = null)
                                    }
                                }
                            }
                        }
                    }
                    if (catalogLoading) item(key = "all_grid_loading") {
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { LoadingIndicator(Modifier.size(28.dp)) }
                    }
                }
                if (catalogFailed && catalogHasMore) {
                    item(key = "all_source_retry") {
                        androidx.compose.material3.TextButton(
                            onClick = onRetryCatalog,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(R.string.retry)) }
                    }
                }
                if (!catalogHasMore && allSourceWorks.isEmpty() && !catalogLoading) {
                    item(key = "all_empty") {
                        Text(
                            text = stringResource(R.string.home_catalog_empty),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Shelf(
    row: HomeRow,
    onOpenItem: (SearchResponse) -> Unit,
    onViewMore: (() -> Unit)?,
) {
    Column {
        SectionHeader(row.title, onViewMore = onViewMore)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // No keys here: providers sometimes return the same item twice.
            items(
                items = row.items,
                contentType = { if (row.horizontal) "horizontal" else "poster" },
            ) { item ->
                PosterCard(
                    item = item,
                    horizontal = row.horizontal,
                    onClick = { onOpenItem(item) },
                    cardWidth = if (row.horizontal) 220.dp else 128.dp,
                )
            }
        }
    }
}
