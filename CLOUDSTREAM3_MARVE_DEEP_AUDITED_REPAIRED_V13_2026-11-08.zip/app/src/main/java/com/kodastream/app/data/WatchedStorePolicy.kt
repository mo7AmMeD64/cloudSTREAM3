package com.kodastream.app.data

/**
 * Adds/removes watched timestamps while retaining the original timestamp of
 * every item that remains watched. Existing entries must not be re-dated just
 * because a different movie or episode changed state.
 */
internal fun updateWatchedTimestamps(
    existing: Map<String, Long>,
    changedKeys: Collection<String>,
    watched: Boolean,
    now: Long,
): Map<String, Long> {
    val updated = existing.toMutableMap()
    changedKeys.asSequence()
        .filter { it.isNotBlank() }
        .forEach { key ->
            if (watched) {
                if (!updated.containsKey(key)) updated[key] = now
            } else {
                updated.remove(key)
            }
        }
    return updated
}
