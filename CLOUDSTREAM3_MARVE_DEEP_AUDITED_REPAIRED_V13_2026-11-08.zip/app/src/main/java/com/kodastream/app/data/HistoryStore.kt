package com.kodastream.app.data

import android.content.Context
import com.lagradost.cloudstream3.utils.DataStore.getKey
import com.lagradost.cloudstream3.utils.DataStore.setKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicLong

/**
 * What the user watched, newest first, one entry per title - for series and
 * anime only the latest watched episode is kept. Stored as one JSON list
 * under CloudStream's DataStore, the same persistence the rest of the app
 * uses, so it survives restarts next to everything else.
 *
 * The in-memory list is the working copy; every change is published to the
 * flow immediately and serialized to disk on a background dispatcher, so
 * recording progress never touches the main thread's frame budget.
 */
object HistoryStore {
    data class HistoryEntry(
        /** "provider|details url" - one entry per title. */
        val key: String,
        val apiName: String,
        /** The details page url, to fall back to when a provider is gone. */
        val url: String,
        val title: String,
        val posterUrl: String? = null,
        val posterHeaders: Map<String, String>? = null,
        /** movie | series | anime */
        val type: String = "movie",
        val season: Int? = null,
        val episode: Int? = null,
        val episodeTitle: String? = null,
        /** The data string the saved episode plays with. */
        val data: String,
        val subtitle: String? = null,
        val resumeKey: String,
        val positionMs: Long = 0L,
        val durationMs: Long = 0L,
        val lastWatchedAt: Long = 0L,
        /** Set by hand from "mark as watched"; progress alone derives it at 90%. */
        val completed: Boolean = false,
    ) {
        /** No progress bar is shown once the item is complete, however it became so. */
        val isComplete: Boolean
            get() = completed || (durationMs > 0 && positionMs >= durationMs * 0.9)
    }

    private const val STORE_KEY = "watch_history"
    private const val MAX_ENTRIES = 200

    private val _entries = MutableStateFlow<List<HistoryEntry>?>(null)
    val entries: StateFlow<List<HistoryEntry>?> = _entries.asStateFlow()

    private val stateLock = Any()
    private val persistenceMutex = Mutex()
    private val persistRevision = AtomicLong(0L)
    private var loaded = false

    // Serialization of the whole list happens here, never on the main thread.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Must be called under [stateLock]. A failed read leaves the store retryable. */
    private fun loadLocked(context: Context) {
        if (loaded) return
        val stored = context.getKey<List<HistoryEntry>>(STORE_KEY).orEmpty()
        _entries.value = stored
            .asSequence()
            .filter { it.key.isNotBlank() }
            .distinctBy { it.key }
            .map { entry ->
                entry.copy(
                    positionMs = entry.positionMs.coerceAtLeast(0L),
                    durationMs = entry.durationMs.coerceAtLeast(0L),
                    lastWatchedAt = entry.lastWatchedAt.coerceAtLeast(0L),
                )
            }
            .sortedByDescending { it.lastWatchedAt }
            .take(MAX_ENTRIES)
            .toList()
        loaded = true
    }

    /** The history, newest first. Loads once, then serves the in-memory snapshot. */
    fun current(context: Context): List<HistoryEntry> = synchronized(stateLock) {
        loadLocked(context)
        _entries.value.orEmpty()
    }

    /** Playback started: replaces an earlier entry for that title and moves it to the top. */
    fun upsert(context: Context, entry: HistoryEntry) {
        val stamped = entry.copy(
            positionMs = entry.positionMs.coerceAtLeast(0L),
            durationMs = entry.durationMs.coerceAtLeast(0L),
            lastWatchedAt = System.currentTimeMillis(),
        )
        mutate(context) { current ->
            (listOf(stamped) + current.filterNot { it.key == entry.key }).take(MAX_ENTRIES)
        }
    }

    /** Progress while playing, and on pause/stop/close/background. Order is kept as-is. */
    fun updateProgress(context: Context, key: String, positionMs: Long, durationMs: Long) {
        val now = System.currentTimeMillis()
        mutate(context) { current ->
            current.map { entry ->
                if (entry.key == key) {
                    entry.copy(
                        positionMs = positionMs.coerceAtLeast(0L),
                        durationMs = durationMs.coerceAtLeast(0L),
                        lastWatchedAt = now,
                    )
                } else entry
            }.sortedByDescending { it.lastWatchedAt }
        }
    }

    fun remove(context: Context, key: String) {
        mutate(context) { current -> current.filterNot { it.key == key } }
    }

    /** Restores an entry after Undo without falsifying its original watch timestamp. */
    fun restore(context: Context, entry: HistoryEntry) {
        val safeEntry = entry.copy(
            positionMs = entry.positionMs.coerceAtLeast(0L),
            durationMs = entry.durationMs.coerceAtLeast(0L),
        )
        mutate(context) { current ->
            (current.filterNot { it.key == safeEntry.key } + safeEntry)
                .sortedByDescending { it.lastWatchedAt }
                .take(MAX_ENTRIES)
        }
    }

    /** Marks a title completed (or clears the mark) without touching its position. */
    fun setCompleted(context: Context, key: String, completed: Boolean) {
        mutate(context) { current -> current.map { entry ->
            if (entry.key == key) entry.copy(completed = completed) else entry
        } }
    }

    /** Clears a title's saved progress, so unmarking starts it over. */
    fun resetProgress(context: Context, key: String) {
        mutate(context) { current -> current.map { entry ->
            if (entry.key == key) entry.copy(positionMs = 0L) else entry
        } }
    }

    fun clear(context: Context) {
        mutate(context) { emptyList() }
    }

    private fun mutate(context: Context, transform: (List<HistoryEntry>) -> List<HistoryEntry>) {
        synchronized(stateLock) {
            loadLocked(context)
            _entries.value = transform(_entries.value.orEmpty()).take(MAX_ENTRIES)
            persistRevision.incrementAndGet()
        }
        schedulePersist(context)
    }

    /**
     * Coalesces background writes and persists only the newest revision. This
     * prevents a delayed progress update from overwriting a later clear/remove.
     */
    private fun schedulePersist(context: Context) {
        val requestedRevision = persistRevision.get()
        scope.launch {
            persistenceMutex.withLock {
                val snapshot = synchronized(stateLock) {
                    if (requestedRevision == persistRevision.get()) _entries.value.orEmpty().toList()
                    else null
                }
                if (snapshot != null) context.setKey(STORE_KEY, snapshot)
            }
        }
    }

    /** A deterministic flush hook for lifecycle/tests that need disk to catch up. */
    suspend fun flush(context: Context) {
        persistenceMutex.withLock {
            val latest = synchronized(stateLock) {
                loadLocked(context)
                _entries.value.orEmpty().toList()
            }
            context.setKey(STORE_KEY, latest)
        }
    }

}
