package com.kodastream.app.data

/** A validated HTTP byte range response for a request starting at [start]. */
data class DownloadContentRange(
    val start: Long,
    val endInclusive: Long,
    val totalBytes: Long,
)

/** A completed file GET supports only a whole representation (200) or a validated range (206). */
internal fun isSupportedDownloadHttpStatus(statusCode: Int): Boolean =
    statusCode == 200 || statusCode == 206

/**
 * Parses and validates Content-Range for a `Range: bytes=<offset>-` request.
 * Open-ended requests must return the remainder of the representation through
 * its final byte; accepting a shorter or mismatched 206 response can silently
 * append unrelated bytes or mark a truncated download as complete.
 */
fun parseDownloadContentRange(
    header: String?,
    requestedOffset: Long,
    contentLength: Long?,
): DownloadContentRange? {
    if (requestedOffset < 0L || contentLength != null && contentLength < 0L) return null
    val match = Regex("^bytes\\s+(\\d+)-(\\d+)/(\\d+)$", RegexOption.IGNORE_CASE)
        .matchEntire(header?.trim().orEmpty()) ?: return null
    val start = match.groupValues[1].toLongOrNull() ?: return null
    val end = match.groupValues[2].toLongOrNull() ?: return null
    val total = match.groupValues[3].toLongOrNull() ?: return null
    if (start != requestedOffset || end < start || total <= end) return null
    val rangeLength = end - start + 1L
    if (contentLength != null && contentLength != rangeLength) return null
    if (end != total - 1L) return null
    return DownloadContentRange(start, end, total)
}
