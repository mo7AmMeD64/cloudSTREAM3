package com.kodastream.app.data

/** Maximum number of records retained in the download queue. */
internal const val MAX_DOWNLOAD_RECORDS = 500

enum class DownloadEnqueueResult {
    ADDED,
    ALREADY_PRESENT,
    LIMIT_REACHED,
}

/**
 * Determines whether a new record can be appended without evicting an existing
 * download. Duplicate detection takes precedence so callers can report the
 * more useful result even when the queue is full.
 */
internal fun decideDownloadEnqueue(
    currentCount: Int,
    alreadyPresent: Boolean,
    maxEntries: Int = MAX_DOWNLOAD_RECORDS,
): DownloadEnqueueResult {
    if (alreadyPresent) return DownloadEnqueueResult.ALREADY_PRESENT
    val safeLimit = maxEntries.coerceAtLeast(1)
    return if (currentCount.coerceAtLeast(0) >= safeLimit) {
        DownloadEnqueueResult.LIMIT_REACHED
    } else {
        DownloadEnqueueResult.ADDED
    }
}
