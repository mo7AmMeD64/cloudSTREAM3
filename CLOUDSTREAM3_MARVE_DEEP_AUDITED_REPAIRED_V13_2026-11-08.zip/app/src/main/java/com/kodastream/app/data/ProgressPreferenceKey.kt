package com.kodastream.app.data

import java.nio.charset.StandardCharsets
import java.security.MessageDigest

private const val HEX = "0123456789abcdef"

/** Collision-resistant key for per-media playback position and duration preferences. */
internal fun progressPreferenceKey(prefix: String, mediaIdentity: String): String {
    val digest = MessageDigest.getInstance("SHA-256")
        .digest(mediaIdentity.toByteArray(StandardCharsets.UTF_8))
    return buildString(prefix.length + digest.size * 2) {
        append(prefix)
        digest.forEach { byte ->
            val value = byte.toInt() and 0xff
            append(HEX[value ushr 4])
            append(HEX[value and 0x0f])
        }
    }
}

/** Collision-resistant poster cache filename for one persisted download identity. */
internal fun downloadPosterFileName(downloadId: String): String =
    progressPreferenceKey("", downloadId) + ".jpg"

/** Stable 32-bit bridge for the legacy player store, which only accepts Int IDs. */
internal fun playbackEpisodeId(mediaIdentity: String): Int {
    val digest = MessageDigest.getInstance("SHA-256")
        .digest(mediaIdentity.toByteArray(StandardCharsets.UTF_8))
    return ((digest[0].toInt() and 0xff) shl 24) or
        ((digest[1].toInt() and 0xff) shl 16) or
        ((digest[2].toInt() and 0xff) shl 8) or
        (digest[3].toInt() and 0xff)
}
