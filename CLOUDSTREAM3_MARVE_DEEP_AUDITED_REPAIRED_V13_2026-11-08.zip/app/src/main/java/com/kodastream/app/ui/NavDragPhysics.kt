package com.kodastream.app.ui

import kotlin.math.abs
import kotlin.math.exp

/**
 * Pure, deterministic target-selection math for the navigation drag gesture.
 * Centers and pointer positions must be expressed in the same pixel coordinate space.
 */
internal object NavDragPhysics {
    private const val PROJECTION_SECONDS = 0.12f


    /** Converts a pointer coordinate to a finite position inside a measured track. */
    fun clampTrackPosition(position: Float, trackWidth: Float): Float {
        if (!position.isFinite() || !trackWidth.isFinite() || trackWidth <= 0f) return 0f
        return position.coerceIn(0f, trackWidth)
    }

    /** Keeps the bubble's center under the pointer while respecting the track edges. */
    fun centeredOffset(pointer: Float, bubbleWidth: Float, trackWidth: Float): Float {
        if (!pointer.isFinite() || !bubbleWidth.isFinite() || !trackWidth.isFinite()) return 0f
        val safeTrack = trackWidth.coerceAtLeast(0f)
        val safeWidth = bubbleWidth.coerceIn(0f, safeTrack)
        return (pointer - safeWidth / 2f).coerceIn(0f, (safeTrack - safeWidth).coerceAtLeast(0f))
    }

    /** Smooth, density-independent stretch response for every finite finger speed. */
    fun stretchRatio(velocityPxPerSecond: Float, density: Float): Float {
        val speed = abs(velocityPxPerSecond.takeIf { it.isFinite() } ?: 0f)
        val safeDensity = density.takeIf { it.isFinite() && it > 0f } ?: 1f
        val speedDpPerSecond = speed / safeDensity
        return (1f - exp(-speedDpPerSecond / 1800f)).coerceIn(0f, 1f)
    }

    fun physicalIndex(logicalIndex: Int, itemCount: Int, isRtl: Boolean): Int {
        if (itemCount <= 0) return -1
        val safeIndex = logicalIndex.coerceIn(0, itemCount - 1)
        return if (isRtl) itemCount - 1 - safeIndex else safeIndex
    }

    /**
     * Physical X center for an equally-sized bottom-navigation item.
     * The result is in the track's local pixel space (zero is its left edge),
     * independent of the layout direction used to place logical destinations.
     */
    fun equalTabCenter(
        logicalIndex: Int,
        itemCount: Int,
        trackWidthPx: Float,
        isRtl: Boolean,
    ): Float {
        if (itemCount <= 0 || !trackWidthPx.isFinite() || trackWidthPx <= 0f) {
            return Float.NaN
        }
        val physical = physicalIndex(logicalIndex, itemCount, isRtl)
        if (physical < 0) return Float.NaN
        val cellWidth = trackWidthPx / itemCount
        return (physical + 0.5f) * cellWidth
    }

    fun nearestIndex(position: Float, itemCenters: FloatArray): Int? {
        if (!position.isFinite()) return null
        var bestIndex: Int? = null
        var bestDistance = Float.POSITIVE_INFINITY
        itemCenters.forEachIndexed { index, center ->
            if (center.isFinite()) {
                val distance = abs(center - position)
                if (distance < bestDistance) {
                    bestDistance = distance
                    bestIndex = index
                }
            }
        }
        return bestIndex
    }

    fun releaseTarget(
        releasedAt: Float,
        axisVelocityPxPerSecond: Float,
        itemCenters: FloatArray,
    ): Int? {
        val velocity = axisVelocityPxPerSecond.takeIf { it.isFinite() } ?: 0f
        val current = nearestIndex(releasedAt, itemCenters) ?: return null
        val currentCenter = itemCenters[current]
        // Clamp against the next center in the *direction of travel*. The
        // navigation pill's selected item can expand, so left and right gaps
        // are not necessarily equal. Using the globally nearest neighbor here
        // incorrectly lets the smaller opposite-side gap limit this flick.
        val directionalNeighborDistance = when {
            velocity > 0f -> itemCenters.asSequence()
                .filter { it.isFinite() && it > currentCenter }
                .minOrNull()
                ?.minus(currentCenter)
            velocity < 0f -> itemCenters.asSequence()
                .filter { it.isFinite() && it < currentCenter }
                .maxOrNull()
                ?.let { currentCenter - it }
            else -> 0f
        } ?: 0f
        val rawProjectionPx = (velocity * PROJECTION_SECONDS)
            .takeIf { it.isFinite() } ?: 0f
        val boundedProjectionPx = rawProjectionPx.coerceIn(
            -directionalNeighborDistance,
            directionalNeighborDistance,
        )
        val projectedPosition = releasedAt + boundedProjectionPx
        // Selection follows the actual release velocity continuously. There is
        // no separate speed threshold that can force an unexpected extra jump.
        // Projection remains bounded to one neighboring interval for predictability.
        return nearestIndex(projectedPosition, itemCenters) ?: current
    }
}

