package com.kodastream.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.HorizontalFloatingToolbar
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlinx.coroutines.withTimeoutOrNull
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import android.app.Application
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.kodastream.app.R
import com.kodastream.app.data.AppEvents
import com.kodastream.app.data.AppPrefs
import com.kodastream.app.data.DetailsArgs
import com.kodastream.app.data.NavArgs
import com.kodastream.app.data.PlayerArgs
import com.kodastream.app.ui.components.softSpring
import com.kodastream.app.ui.details.DetailsScreen
import com.kodastream.app.ui.details.DetailsViewModel
import com.kodastream.app.ui.extensions.ExtensionsScreen
import com.kodastream.app.ui.history.HistoryScreen
import com.kodastream.app.ui.home.ExpandedHomeViewModel
import com.kodastream.app.ui.home.HomeViewModel
import com.kodastream.app.ui.home.SourceCatalogScreen
import com.kodastream.app.ui.home.HomeScreen
import com.kodastream.app.ui.home.SectionScreen
import com.kodastream.app.ui.home.hero.LocalScreenActive
import com.kodastream.app.ui.library.LibraryScreen
import com.kodastream.app.ui.player.PlayerActivity
import com.kodastream.app.ui.search.SearchScreen
import com.kodastream.app.ui.settings.SettingsScreen
import com.kodastream.app.ui.sources.SourceSheet
import com.kodastream.app.ui.sources.SourceViewModel
import com.kodastream.app.ui.theme.ThemeViewModel
import com.lagradost.cloudstream3.SearchResponse

private object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val HISTORY = "history"
    const val EXTENSIONS = "extensions"
    const val SETTINGS = "settings"
    const val SECTION = "section"
    const val SOURCE_CATALOG = "source_catalog"
    const val DETAILS = "details/{id}"
}

private data class TopLevel(
    val route: String,
    val labelRes: Int,
    val filledIcon: ImageVector,
    val outlinedIcon: ImageVector,
)

private val topLevelDestinations = listOf(
    TopLevel(Routes.HOME, R.string.nav_home, Icons.Rounded.Home, Icons.Outlined.Home),
    TopLevel(Routes.SEARCH, R.string.nav_search, Icons.Rounded.Search, Icons.Outlined.Search),
    TopLevel(Routes.LIBRARY, R.string.nav_library, Icons.Rounded.VideoLibrary, Icons.Outlined.VideoLibrary),
    TopLevel(Routes.HISTORY, R.string.nav_history, Icons.Rounded.History, Icons.Outlined.History),
    TopLevel(Routes.EXTENSIONS, R.string.nav_extensions, Icons.Rounded.Extension, Icons.Outlined.Extension),
    TopLevel(Routes.SETTINGS, R.string.nav_settings, Icons.Rounded.Settings, Icons.Outlined.Settings),
)

// Direct touch-drag navigation is shared by the horizontal and vertical layouts.
// It waits only for the platform touch slop and an axis-dominant movement; taps and
// perpendicular scrolling remain available to their own handlers.
private enum class NavDragAxis { Horizontal, Vertical }

// The side rail also scrolls vertically, so its items retain a short hold-to-drag
// disambiguation. The bottom bubble and horizontal pill start tracking immediately.
private const val SIDE_NAV_DRAG_HOLD_MS = 100L


/** Coordinate holder shared by the pointer detector and the tab-center measurements. */
private class NavGestureCoordinateSpace {
    var coordinates: LayoutCoordinates? = null
}

@Composable
private fun rememberNavDragModifier(
    enabled: Boolean,
    axis: NavDragAxis,
    itemCenters: FloatArray,
    itemBounds: Array<Rect?>,
    onSelectIndex: (Int) -> Unit,
    onDragStart: () -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit = {},
    onDragPosition: (Float) -> Unit = {},
    onDragVelocity: (Float) -> Unit = {},
    coordinateSpace: NavGestureCoordinateSpace? = null,
    localCoordinates: Boolean = false,
    restrictToItemBounds: Boolean = true,
    activationDelayMs: Long = 0L,
): Modifier {
    val select by rememberUpdatedState(onSelectIndex)
    val start by rememberUpdatedState(onDragStart)
    val end by rememberUpdatedState(onDragEnd)
    val cancel by rememberUpdatedState(onDragCancel)
    val move by rememberUpdatedState(onDragPosition)
    val velocityChanged by rememberUpdatedState(onDragVelocity)
    val gestureCoordinates = remember(coordinateSpace) { coordinateSpace ?: NavGestureCoordinateSpace() }

    return Modifier
        .onGloballyPositioned { gestureCoordinates.coordinates = it }
        // Observe from Initial (parent-to-child) so an interactive tab's
        // clickable handler cannot consume the down/move before the drag detector
        // gets a chance to claim an axis-dominant gesture after touch slop.
        .pointerInput(enabled, axis, itemCenters.size, activationDelayMs, localCoordinates, restrictToItemBounds) {
            if (!enabled || itemCenters.size < 2) return@pointerInput

            fun axisCoordinate(x: Float, y: Float): Float =
                if (axis == NavDragAxis.Horizontal) x else y

            fun gesturePosition(localPosition: Offset): Offset {
                if (localCoordinates) return localPosition
                val coordinates = gestureCoordinates.coordinates
                return if (coordinates?.isAttached == true) {
                    coordinates.localToRoot(localPosition)
                } else localPosition
            }

            awaitEachGesture {
                val down = awaitFirstDown(
                    requireUnconsumed = false,
                    pass = PointerEventPass.Initial,
                )
                val downPosition = gesturePosition(down.position)
                // The side rail restricts drag ownership to its measured tab cells.
                // A bottom bar's pointer detector already covers only the six-tab
                // track, so applying root-space child hit testing there is redundant
                // and can reject valid touches when transformed/padded coordinates differ.
                if (restrictToItemBounds && itemBounds.none { bounds -> bounds?.contains(downPosition) == true }) {
                    return@awaitEachGesture
                }

                val velocityTracker = VelocityTracker().apply {
                    addPosition(down.uptimeMillis, downPosition)
                }

                // The side rail's drag axis is also its scroll axis. Let a short
                // movement or a quick tap remain with scrolling/click handling;
                // only a held touch can claim a vertical section-drag gesture.
                if (activationDelayMs > 0L) {
                    val holdCompleted = withTimeoutOrNull(activationDelayMs) {
                        while (true) {
                            val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                            if (event.changes.any { it.id != down.id && it.pressed }) {
                                return@withTimeoutOrNull false
                            }
                            val change = event.changes.firstOrNull { it.id == down.id }
                                ?: return@withTimeoutOrNull false
                            if (change.isConsumed || !change.pressed) return@withTimeoutOrNull false
                            val position = gesturePosition(change.position)
                            velocityTracker.addPosition(change.uptimeMillis, position)
                            val dx = position.x - downPosition.x
                            val dy = position.y - downPosition.y
                            if (abs(dx) > viewConfiguration.touchSlop || abs(dy) > viewConfiguration.touchSlop) {
                                return@withTimeoutOrNull false
                            }
                        }
                        false
                    } == null
                    if (!holdCompleted) return@awaitEachGesture
                }

                var dragActivated = false
                var releasedNormally = false
                var pointerValid = true
                var releasedAt = axisCoordinate(downPosition.x, downPosition.y)
                var lastDragPosition = releasedAt
                var lastSelectedIndex: Int? = null

                fun selectIfChanged(index: Int?) {
                    if (index != null && index != lastSelectedIndex) {
                        lastSelectedIndex = index
                        select(index)
                    }
                }

                try {
                    // Begin as soon as a clear axis-dominant drag crosses touchSlop.
                    // A tap is left untouched; perpendicular movement stays with
                    // the surrounding scroll container. No hold timer can reject
                    // a fast first swipe or delay the bubble behind the finger.
                    while (pointerValid) {
                        val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                        if (event.changes.any { it.id != down.id && it.pressed }) {
                            pointerValid = false
                            break
                        }
                        val change = event.changes.firstOrNull { it.id == down.id }
                        if (change == null) {
                            pointerValid = false
                            break
                        }

                        val position = gesturePosition(change.position)
                        velocityTracker.addPosition(change.uptimeMillis, position)
                        releasedAt = axisCoordinate(position.x, position.y)
                        lastDragPosition = releasedAt

                        if (!change.pressed) {
                            if (dragActivated) {
                                // The up event can carry a final coordinate different
                                // from the previous move. Apply it before capturing the
                                // release point so the bubble never snaps from stale data.
                                move(lastDragPosition)
                                change.consume()
                                releasedNormally = true
                            }
                            pointerValid = false
                            break
                        }

                        if (change.isConsumed) {
                            pointerValid = false
                            break
                        }

                        val dx = position.x - downPosition.x
                        val dy = position.y - downPosition.y
                        val axisDelta = abs(axisCoordinate(dx, dy))
                        val crossAxisDelta = abs(axisCoordinate(dy, dx))
                        val slop = viewConfiguration.touchSlop

                        if (!dragActivated) {
                            if (axisDelta > slop && axisDelta >= crossAxisDelta * 1.12f) {
                                dragActivated = true
                                change.consume()
                                start()
                                move(lastDragPosition)
                                val velocity = velocityTracker.calculateVelocity()
                                val axisVelocity = if (axis == NavDragAxis.Horizontal) velocity.x else velocity.y
                                velocityChanged(axisVelocity.takeIf { it.isFinite() } ?: 0f)
                                selectIfChanged(NavDragPhysics.nearestIndex(releasedAt, itemCenters))
                            } else if (crossAxisDelta > slop && crossAxisDelta >= axisDelta * 1.12f) {
                                pointerValid = false
                            }
                        } else {
                            change.consume()
                            move(lastDragPosition)
                            val velocity = velocityTracker.calculateVelocity()
                            val axisVelocity = if (axis == NavDragAxis.Horizontal) velocity.x else velocity.y
                            velocityChanged(axisVelocity.takeIf { it.isFinite() } ?: 0f)
                            selectIfChanged(NavDragPhysics.nearestIndex(releasedAt, itemCenters))
                        }
                    }

                    if (dragActivated && releasedNormally) {
                        val velocity = velocityTracker.calculateVelocity()
                        val measuredAxisVelocity = if (axis == NavDragAxis.Horizontal) velocity.x else velocity.y
                        val axisVelocity = measuredAxisVelocity.takeIf { it.isFinite() } ?: 0f
                        selectIfChanged(
                            NavDragPhysics.releaseTarget(
                                releasedAt = releasedAt,
                                axisVelocityPxPerSecond = axisVelocity,
                                itemCenters = itemCenters,
                            )
                        )
                        velocityChanged(axisVelocity)
                    }
                } finally {
                    if (dragActivated) {
                        if (releasedNormally) end() else cancel()
                    }
                }
            }
        }
}

// ------------------------------------------------------------------ shared nav motion

/**
 * The animation language both navigation bars speak, extracted so the side
 * pill and the bottom pill feel identical: colours cross-fade on one 200ms
 * tween, the item's inner padding and the label's appearance/disappearance
 * ride the expressive fast-spatial spring, and the label shows only for the
 * open tab. The bars differ only in the axis the active pill expands on -
 * horizontally in the bottom bar with the label beside the icon, vertically
 * in the side bar with the label under it.
 */
private const val NAV_COLOR_MS = 200

private val NavItemPaddingCollapsed = 12.dp
private val NavItemPaddingExpanded = 20.dp

/** The shared size of every nav icon, active or not. */
private val NavIconSize = 24.dp

/** The gap between an item's icon and its expanding label. */
private val NavLabelGap = 8.dp

@Composable
private fun navItemPadding(selected: Boolean): Dp =
    animateDpAsState(
        targetValue = if (selected) NavItemPaddingExpanded else NavItemPaddingCollapsed,
        animationSpec = MaterialTheme.motionScheme.fastSpatialSpec(),
        label = "navItemPadding",
    ).value

@Composable
private fun navContainerColor(selected: Boolean, activeContainer: Color): Color =
    animateColorAsState(
        targetValue = if (selected) activeContainer else Color.Transparent,
        animationSpec = tween(durationMillis = NAV_COLOR_MS),
        label = "navContainerColor",
    ).value

@Composable
private fun navContentColor(selected: Boolean, activeContent: Color): Color =
    animateColorAsState(
        targetValue = if (selected) activeContent else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(durationMillis = NAV_COLOR_MS),
        label = "navContentColor",
    ).value

/** Theme-aware paired colors for the custom navigation bubble and its selected icon. */
private fun navBubbleColors(
    index: Int,
    scheme: androidx.compose.material3.ColorScheme,
): Pair<Color, Color> = when (index) {
    0 -> scheme.primaryContainer to scheme.onPrimaryContainer
    1 -> scheme.secondaryContainer to scheme.onSecondaryContainer
    2 -> scheme.tertiaryContainer to scheme.onTertiaryContainer
    3 -> scheme.surfaceVariant to scheme.onSurfaceVariant
    4 -> scheme.primary.copy(alpha = 0.19f) to scheme.onSurface
    else -> scheme.tertiary.copy(alpha = 0.17f) to scheme.onSurface
}

// The side bar's fixed geometry: the pill is 64dp wide, its items get a
// 48dp touch target inside, and the whole bar floats 14dp off the edge.
private val SideBarWidth = 64.dp
private val SideBarMargin = 14.dp

private fun NavHostController.navigateTopLevel(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun NavHostController.openDetails(args: DetailsArgs) {
    navigate("details/${NavArgs.put(args)}")
}

private fun NavHostController.openDetails(item: SearchResponse) {
    openDetails(
        DetailsArgs(
            apiName = item.apiName,
            url = item.url,
            title = item.name,
            posterUrl = item.posterUrl,
            posterHeaders = item.posterHeaders,
        )
    )
}

@Composable
fun AppRoot(themeViewModel: ThemeViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBar = topLevelDestinations.any { it.route == route }
    val sourceVisible = route == Routes.HOME || route == Routes.SEARCH
    val sources: SourceViewModel = viewModel()
    // Activity-scoped: paged Home sections survive rotation and Back to Home.
    val expanded: ExpandedHomeViewModel = viewModel()
    // Shared across Home and its expanded source catalogue so paging continues on that page.
    val homeViewModel: HomeViewModel = viewModel()

    // The source sheet is hosted here so both routes and both shells share it.
    var sourceSheetOpen by remember { mutableStateOf(false) }
    val sourceList by sources.providers.collectAsState()
    val homeSource by sources.home.collectAsState()
    val searchScope by sources.search.collectAsState()

    // A repository link opened from outside the app: go to the Extensions tab, which shows the dialog.
    val pendingRepo by AppEvents.pendingRepoUrl.collectAsState()
    LaunchedEffect(pendingRepo) {
        if (pendingRepo != null) navController.navigateTopLevel(Routes.EXTENSIONS)
    }

    val context = LocalContext.current
    val navPosition by AppPrefs.navPosition.collectAsState(initial = AppPrefs.navPosition(context))
    val fixedNavigationState by AppPrefs.fixedNavigationFlow.collectAsState(
        initial = AppPrefs.fixedNavigation(context),
    )
    val fixedNavigation = fixedNavigationState ?: true
    val navBarStyleState by AppPrefs.navBarStyle.collectAsState(
        initial = AppPrefs.navBarStyle(context),
    )
    val navBarStyle = navBarStyleState ?: AppPrefs.NAV_BAR_CLOUD
    val navDragEnabledState by AppPrefs.navDragSwitchEnabled.collectAsState(
        initial = AppPrefs.navDragSwitchEnabled(context),
    )
    val navDragEnabled = navDragEnabledState ?: true
    val sideMode = showBar && navPosition != AppPrefs.NAV_BOTTOM

    // Either shell hands the screens the same contract: system-bar insets,
    // plus the pill's strip (and the source button above it) when it is there.
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val contentPadding = when {
        !showBar -> PaddingValues(0.dp)
        sideMode -> PaddingValues(top = topInset, bottom = navInset)
        else -> PaddingValues(
            top = topInset,
            bottom = 84.dp + navInset + if (sourceVisible) 60.dp else 0.dp,
        )
    }

    if (sideMode) {
        Box(Modifier.fillMaxSize()) {
            // The bar mirrors with the locale: left in LTR, right in Arabic.
            // `start` on both the content padding and the bar keeps them on
            // the same side without direction-dependent branches.
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(start = SideBarWidth + SideBarMargin)
            ) {
                AppNavGraph(
                    navController = navController,
                    themeViewModel = themeViewModel,
                    contentPadding = contentPadding,
                    sources = sources,
                    expanded = expanded,
                    homeViewModel = homeViewModel,
                    onOpenSources = { sourceSheetOpen = true },
                )
            }

            FloatingSideBar(
                selectedRoute = route,
                onSelect = { navController.navigateTopLevel(it) },
                sourceVisible = sourceVisible,
                onOpenSources = { sourceSheetOpen = true },
                fixedNavigation = fixedNavigation,
                dragEnabled = navDragEnabled,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .displayCutoutPadding()
                    .padding(start = SideBarMargin),
            )
        }
    } else {
        Box(Modifier.fillMaxSize()) {
            AppNavGraph(
                navController = navController,
                themeViewModel = themeViewModel,
                contentPadding = contentPadding,
                sources = sources,
                expanded = expanded,
                homeViewModel = homeViewModel,
                onOpenSources = { sourceSheetOpen = true },
            )
            AnimatedVisibility(
                visible = showBar,
                enter = fadeIn(tween(220)) +
                    slideInVertically(animationSpec = softSpring()) { it * 2 },
                exit = fadeOut(tween(180)) +
                    slideOutVertically(animationSpec = softSpring()) { it * 2 },
                modifier = Modifier.align(Alignment.BottomCenter),
            ) {
                Column(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(bottom = 20.dp),
                    horizontalAlignment = Alignment.End,
                ) {
                    // A separate button above the pill: attaching it to the
                    // toolbar would squeeze the six tabs on narrow screens.
                    AnimatedVisibility(
                        visible = sourceVisible,
                        enter = scaleIn(tween(220)) + fadeIn(tween(220)),
                        exit = scaleOut(tween(180)) + fadeOut(tween(180)),
                    ) {
                        // Physical-left placement is intentional in both RTL and LTR
                        // locales. The source selector remains available on Home/Search only.
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            ) {
                                SmallFloatingActionButton(
                                    onClick = { sourceSheetOpen = true },
                                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 16.dp),
                                ) {
                                    Icon(
                                        Icons.Rounded.Dns,
                                        contentDescription = stringResource(R.string.cd_choose_source),
                                    )
                                }
                            }
                        }
                    }
                    if (navBarStyle == AppPrefs.NAV_BAR_BUBBLE) {
                        FloatingNavBubble(
                            selectedRoute = route,
                            fixedNavigation = fixedNavigation,
                            dragEnabled = navDragEnabled,
                            onSelect = { navController.navigateTopLevel(it) },
                        )
                    } else {
                        FloatingNavPill(
                            selectedRoute = route,
                            fixedNavigation = fixedNavigation,
                            dragEnabled = navDragEnabled,
                            onSelect = { navController.navigateTopLevel(it) },
                        )
                    }
                }
            }
        }
    }

    if (sourceSheetOpen) {
        val search = route == Routes.SEARCH
        SourceSheet(
            providers = sourceList,
            selected = if (search) searchScope else homeSource,
            showAllSources = search,
            onSelect = { name ->
                sourceSheetOpen = false
                if (search) sources.selectSearch(name) else if (name != null) sources.selectHome(name)
            },
            onOpenExtensions = {
                sourceSheetOpen = false
                navController.navigateTopLevel(Routes.EXTENSIONS)
            },
            onDismiss = { sourceSheetOpen = false },
        )
    }
}

/** The routes themselves, shared verbatim by both navigation shells. */
@Composable
private fun AppNavGraph(
    navController: NavHostController,
    themeViewModel: ThemeViewModel,
    contentPadding: PaddingValues,
    sources: SourceViewModel,
    expanded: ExpandedHomeViewModel,
    homeViewModel: HomeViewModel,
    onOpenSources: () -> Unit,
) {
    val context = LocalContext.current
    fun openPlayer(playerArgs: PlayerArgs) {
        context.startActivity(PlayerActivity.newIntent(context, NavArgs.put(playerArgs)))
    }

    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        modifier = Modifier.fillMaxSize(),
    ) {
        composable(Routes.HOME) { entry ->
            val lifecycleState by entry.lifecycle.currentStateFlow.collectAsState()
            CompositionLocalProvider(
                LocalScreenActive provides lifecycleState.isAtLeast(Lifecycle.State.RESUMED),
            ) {
                HomeScreen(
                    contentPadding = contentPadding,
                    onOpenItem = navController::openDetails,
                    onOpenExtensions = { navController.navigateTopLevel(Routes.EXTENSIONS) },
                    onOpenSources = onOpenSources,
                    sourceViewModel = sources,
                    expandedViewModel = expanded,
                    onOpenSection = { navController.navigate(Routes.SECTION) },
                    onOpenCatalog = { navController.navigate(Routes.SOURCE_CATALOG) },
                    viewModel = homeViewModel,
                )
            }
        }
        composable(Routes.SEARCH) {
            SearchScreen(
                contentPadding = contentPadding,
                onOpenItem = navController::openDetails,
                sourceViewModel = sources,
            )
        }
        composable(Routes.LIBRARY) {
            LibraryScreen(
                contentPadding = contentPadding,
                onOpenItem = navController::openDetails,
                onResume = { playerArgs -> openPlayer(playerArgs) },
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                contentPadding = contentPadding,
                onOpenItem = navController::openDetails,
                onResume = { playerArgs -> openPlayer(playerArgs) },
            )
        }
        composable(Routes.EXTENSIONS) {
            ExtensionsScreen(contentPadding = contentPadding)
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(contentPadding = contentPadding, themeViewModel = themeViewModel)
        }
        composable(Routes.SECTION) {
            SectionScreen(
                viewModel = expanded,
                onBack = { navController.popBackStack() },
                onOpenItem = navController::openDetails,
            )
        }
        composable(Routes.SOURCE_CATALOG) {
            SourceCatalogScreen(
                viewModel = homeViewModel,
                sourceViewModel = sources,
                onBack = { navController.popBackStack() },
                onOpenItem = navController::openDetails,
            )
        }
        composable(
            route = Routes.DETAILS,
            arguments = listOf(navArgument("id") { type = NavType.IntType }),
        ) { entry ->
            val args = NavArgs.details(entry.arguments?.getInt("id") ?: -1)
            if (args == null) {
                // The process was recreated and the in-memory arguments are gone.
                LaunchedEffect(Unit) { navController.popBackStack() }
            } else {
                val viewModel: DetailsViewModel = viewModel(
                    factory = viewModelFactory { initializer { DetailsViewModel(args) } }
                )
                DetailsScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenItem = navController::openDetails,
                    onOpenDownloads = { navController.navigateTopLevel(Routes.LIBRARY) },
                    onPlay = { playerArgs -> openPlayer(playerArgs) },
                )
            }
        }
    }
}

/**
 * The floating side pill: a stadium-ended vertical bar on the start edge
 * (left in LTR, right in Arabic), wrapping its content, over the page
 * rather than attached to it. Same six destinations, same icons, same
 * order as the bottom bar. Scrollable for short screens in landscape; the
 * insets in [modifier]'s chain cap its height to the space between the
 * status and nav bars.
 */
@Composable
private fun FloatingSideBar(
    selectedRoute: String?,
    onSelect: (String) -> Unit,
    sourceVisible: Boolean,
    onOpenSources: () -> Unit,
    fixedNavigation: Boolean,
    dragEnabled: Boolean,
    modifier: Modifier = Modifier,
) {
    val selectedIndex = topLevelDestinations.indexOfFirst { it.route == selectedRoute }.coerceAtLeast(0)
    var dragPreviewIndex by remember { mutableStateOf(-1) }
    var isDragging by remember { mutableStateOf(false) }
    val centers = remember { FloatArray(topLevelDestinations.size) { Float.NaN } }
    val itemBounds = remember { Array<Rect?>(topLevelDestinations.size) { null } }
    val gestureCoordinates = remember { NavGestureCoordinateSpace() }
    val haptics = LocalHapticFeedback.current
    LaunchedEffect(selectedRoute) { dragPreviewIndex = -1 }
    val dragModifier = rememberNavDragModifier(
        enabled = dragEnabled,
        axis = NavDragAxis.Vertical,
        itemCenters = centers,
        itemBounds = itemBounds,
        coordinateSpace = gestureCoordinates,
        activationDelayMs = SIDE_NAV_DRAG_HOLD_MS,
        onSelectIndex = { dragPreviewIndex = it },
        onDragStart = { dragPreviewIndex = selectedIndex; isDragging = true; haptics.performHapticFeedback(HapticFeedbackType.LongPress) },
        onDragEnd = {
            val target = dragPreviewIndex
            isDragging = false
            if (target >= 0) topLevelDestinations.getOrNull(target)?.takeIf { it.route != selectedRoute }?.let { onSelect(it.route) }
        },
        onDragCancel = { dragPreviewIndex = -1; isDragging = false },
    )
    val visualIndex = dragPreviewIndex.takeIf { it >= 0 } ?: selectedIndex
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier
                .width(SideBarWidth)
                .padding(horizontal = 8.dp, vertical = 10.dp)
                .then(dragModifier)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            topLevelDestinations.forEachIndexed { index, destination ->
                SideNavItem(
                    destination = destination,
                    selected = visualIndex == index,
                    fixedNavigation = fixedNavigation,
                    layoutSelected = if (isDragging && !fixedNavigation) selectedIndex == index else visualIndex == index,
                    onPosition = { itemCoordinates ->
                        val host = gestureCoordinates.coordinates
                        if (host?.isAttached == true && itemCoordinates.isAttached) {
                            val item = itemCoordinates.boundsInRoot()
                            val viewport = host.boundsInRoot()
                            // Clip partially visible items to the actual scroll viewport.
                            // A sliver that can receive a touch remains selectable, while
                            // fully off-screen items cannot win nearest-center selection.
                            val left = maxOf(item.left, viewport.left)
                            val top = maxOf(item.top, viewport.top)
                            val right = minOf(item.right, viewport.right)
                            val bottom = minOf(item.bottom, viewport.bottom)
                            if (right > left && bottom > top) {
                                val visibleBounds = Rect(left, top, right, bottom)
                                itemBounds[index] = visibleBounds
                                centers[index] = visibleBounds.center.y
                            } else {
                                itemBounds[index] = null
                                centers[index] = Float.NaN
                            }
                        } else {
                            itemBounds[index] = null
                            centers[index] = Float.NaN
                        }
                    },
                    onClick = { dragPreviewIndex = index; onSelect(destination.route) },
                )
            }
            AnimatedVisibility(
                visible = sourceVisible,
                enter = scaleIn(tween(220)) + fadeIn(tween(220)),
                exit = scaleOut(tween(180)) + fadeOut(tween(180)),
            ) {
                Surface(
                    onClick = onOpenSources,
                    shape = RoundedCornerShape(50),
                    color = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Box(
                        modifier = Modifier.height(48.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Rounded.Dns,
                            contentDescription = stringResource(R.string.cd_choose_source),
                            modifier = Modifier.size(NavIconSize),
                        )
                    }
                }
            }
        }
    }
}

/**
 * One side-bar item: the open tab's pill expands vertically with its label
 * sliding in under the icon, on exactly the shared specs - the same 200ms
 * colour tween, the same fast-spatial spring, the same 12-to-20dp padding
 * growth - as the bottom bar's item.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun SideNavItem(
    destination: TopLevel,
    selected: Boolean,
    fixedNavigation: Boolean,
    layoutSelected: Boolean,
    onPosition: (LayoutCoordinates) -> Unit,
    onClick: () -> Unit,
) {
    val animatedPadding = navItemPadding(layoutSelected)
    val animatedContainerColor = navContainerColor(
        selected = selected,
        activeContainer = MaterialTheme.colorScheme.secondaryContainer,
    )
    val animatedContentColor = navContentColor(
        selected = selected,
        activeContent = MaterialTheme.colorScheme.onSecondaryContainer,
    )

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = animatedContainerColor,
        contentColor = animatedContentColor,
        modifier = Modifier.fillMaxWidth().onGloballyPositioned(onPosition),
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = if (fixedNavigation) NavItemPaddingCollapsed else animatedPadding)
                .then(if (fixedNavigation) Modifier else Modifier.animateContentSize(
                    animationSpec = MaterialTheme.motionScheme.fastSpatialSpec()
                )),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                imageVector = if (selected) destination.filledIcon else destination.outlinedIcon,
                contentDescription = stringResource(destination.labelRes),
                modifier = Modifier.size(NavIconSize),
            )
            // The pill names only the open tab, under its icon.
            AnimatedVisibility(
                visible = selected && !fixedNavigation,
                enter = fadeIn() + expandVertically(
                    animationSpec = MaterialTheme.motionScheme.fastSpatialSpec()
                ),
                exit = fadeOut() + shrinkVertically(
                    animationSpec = MaterialTheme.motionScheme.fastSpatialSpec()
                ),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(modifier = Modifier.height(NavLabelGap))
                    Text(
                        text = stringResource(destination.labelRes),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

/**
 * Custom bottom navigation with a single elastic bubble that tracks the actual
 * pointer coordinate during direct touch-drag. Tab centers and pointer positions stay
 * in the track's local pixel space for hit selection, finger tracking, and drawing.
 * This avoids mixing root and padded-content coordinates in the bottom rail.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun FloatingNavBubble(
    selectedRoute: String?,
    fixedNavigation: Boolean,
    dragEnabled: Boolean,
    onSelect: (String) -> Unit,
) {
    BoxWithConstraints(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center,
    ) {
        val pillWidth = (maxWidth - 16.dp).coerceAtLeast(0.dp).coerceAtMost(420.dp)
        val density = LocalDensity.current
        val layoutDirection = LocalLayoutDirection.current
        val selectedIndex = topLevelDestinations.indexOfFirst { it.route == selectedRoute }.coerceAtLeast(0)
        var dragPreviewIndex by remember { mutableStateOf(-1) }
        val visualIndex = dragPreviewIndex.takeIf { it >= 0 } ?: selectedIndex
        LaunchedEffect(selectedRoute) { dragPreviewIndex = -1 }
        val physicalSelectedIndex = NavDragPhysics.physicalIndex(
            logicalIndex = visualIndex,
            itemCount = topLevelDestinations.size,
            isRtl = layoutDirection == LayoutDirection.Rtl,
        )
        val centers = remember { FloatArray(topLevelDestinations.size) { Float.NaN } }
        var isDragging by remember { mutableStateOf(false) }
        var isSettling by remember { mutableStateOf(false) }
        // High-frequency pointer values are read inside graphicsLayer below,
        // avoiding recomposition of all six navigation items on every move.
        var dragPositionPx by remember { mutableFloatStateOf(Float.NaN) }
        var dragVelocityPx by remember { mutableFloatStateOf(0f) }
        var releasePositionPx by remember { mutableFloatStateOf(Float.NaN) }
        var releaseVelocityPx by remember { mutableFloatStateOf(0f) }
        val haptics = LocalHapticFeedback.current
        val selectedBubbleColors = navBubbleColors(visualIndex, MaterialTheme.colorScheme)
        val bubbleColor by animateColorAsState(
            targetValue = selectedBubbleColors.first,
            animationSpec = tween(150),
            label = "navBubbleColor",
        )
        Surface(
            modifier = Modifier.width(pillWidth),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.97f),
            contentColor = MaterialTheme.colorScheme.onSurface,
            tonalElevation = 5.dp,
            shadowElevation = 3.dp,
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 7.dp)
                    .height(54.dp),
                // X coordinates in this track are physical: zero is always left.
                contentAlignment = AbsoluteAlignment.TopLeft,
            ) {
                val cellWidth = maxWidth / topLevelDestinations.size
                val showLabel = !fixedNavigation && cellWidth >= 58.dp && !isDragging
                // A little wider and taller than the tab's icon lane so the
                // moving highlight reads as a proper capsule, while staying in-track.
                val baseBubbleWidth = (cellWidth + 8.dp).coerceAtLeast(28.dp).coerceAtMost(76.dp).coerceAtMost(maxWidth)
                val maxStretch = minOf(12.dp, cellWidth * 0.18f)
                val bubbleHeight by animateDpAsState(
                    targetValue = if (showLabel) 54.dp else 50.dp,
                    animationSpec = spring(dampingRatio = 0.86f, stiffness = 620f),
                    label = "navBubbleHeight",
                )
                // Continuous response: no dead zone or hard speed threshold.
                val trackWidthPx = with(density) { maxWidth.toPx() }
                topLevelDestinations.indices.forEach { index ->
                    centers[index] = NavDragPhysics.equalTabCenter(
                        logicalIndex = index,
                        itemCount = topLevelDestinations.size,
                        trackWidthPx = trackWidthPx,
                        isRtl = layoutDirection == LayoutDirection.Rtl,
                    )
                }
                // Use the shared Initial-pass recognizer here as well as in the
                // side rail. Each tab below is a clickable Surface layered above
                // the capsule; a Main-pass drag detector can therefore lose the
                // gesture to the child click handler before it ever starts. The
                // Initial pass observes the pointer before those click handlers,
                // then consumes only after horizontal touch-slop is crossed.
                // Coordinates stay local to this full-size track, exactly matching
                // the X values used by graphicsLayer and NavDragPhysics.
                val bubbleDragModifier = rememberNavDragModifier(
                    enabled = dragEnabled,
                    axis = NavDragAxis.Horizontal,
                    itemCenters = centers,
                    itemBounds = emptyArray(),
                    onSelectIndex = { index -> dragPreviewIndex = index },
                    onDragStart = {
                        isSettling = false
                        dragPreviewIndex = selectedIndex
                        isDragging = true
                        dragPositionPx = Float.NaN
                        releasePositionPx = Float.NaN
                        releaseVelocityPx = 0f
                        dragVelocityPx = 0f
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    },
                    onDragPosition = { position ->
                        dragPositionPx = NavDragPhysics.clampTrackPosition(position, trackWidthPx)
                    },
                    onDragVelocity = { velocity -> dragVelocityPx = velocity },
                    onDragEnd = {
                        releasePositionPx = dragPositionPx.takeIf { it.isFinite() } ?: Float.NaN
                        releaseVelocityPx = dragVelocityPx.takeIf { it.isFinite() } ?: 0f
                        isDragging = false
                        isSettling = releasePositionPx.isFinite()
                        if (!isSettling) {
                            dragVelocityPx = 0f
                            releasePositionPx = Float.NaN
                            releaseVelocityPx = 0f
                        }
                        val targetIndex = dragPreviewIndex
                        if (targetIndex >= 0) {
                            topLevelDestinations.getOrNull(targetIndex)
                                ?.takeIf { it.route != selectedRoute }
                                ?.let { onSelect(it.route) }
                        }
                    },
                    onDragCancel = {
                        dragPreviewIndex = -1
                        releasePositionPx = dragPositionPx.takeIf { it.isFinite() } ?: Float.NaN
                        releaseVelocityPx = 0f
                        isDragging = false
                        isSettling = releasePositionPx.isFinite()
                        if (!isSettling) dragVelocityPx = 0f
                    },
                    localCoordinates = true,
                    restrictToItemBounds = false,
                )
                val baseBubbleWidthPx = with(density) { baseBubbleWidth.toPx() }
                val maxStretchPx = with(density) { maxStretch.toPx() }
                val normalLeftPx = with(density) {
                    (cellWidth * physicalSelectedIndex + (cellWidth - baseBubbleWidth) / 2).toPx()
                }.coerceIn(0f, (trackWidthPx - baseBubbleWidthPx).coerceAtLeast(0f))
                val normalCenterPx = normalLeftPx + baseBubbleWidthPx / 2f

                // Animate only the resting/settling center. During direct touch,
                // the graphics layer reads the pointer's local X without an
                // animation step or a full navigation-row recomposition.
                val restingCenter = remember { Animatable(0f) }
                var centerInitialized by remember { mutableStateOf(false) }
                LaunchedEffect(isDragging, isSettling, physicalSelectedIndex, trackWidthPx) {
                    if (isDragging) return@LaunchedEffect
                    // Handle release before first-layout initialization as well. This
                    // avoids a rare fast-touch race leaving the bubble frozen at the
                    // finger location without ever entering its settling animation.
                    if (isSettling) {
                        // On a restarted effect (for example, the destination route
                        // changes after release), resume from the current animated
                        // center instead of jumping back to the original finger point.
                        val startCenter = releasePositionPx.takeIf { it.isFinite() }
                            ?: if (centerInitialized) restingCenter.value else normalCenterPx
                        restingCenter.snapTo(startCenter)
                        centerInitialized = true
                        releasePositionPx = Float.NaN
                        // Preserve measured velocity continuously; only an extreme
                        // sample is bounded for numerical stability at the track edge.
                        val measuredVelocity = releaseVelocityPx.takeIf { it.isFinite() } ?: 0f
                        val safeVelocity = measuredVelocity.coerceIn(
                            -trackWidthPx * 5f,
                            trackWidthPx * 5f,
                        )
                        restingCenter.animateTo(
                            targetValue = normalCenterPx,
                            animationSpec = spring(dampingRatio = 0.78f, stiffness = 560f),
                            initialVelocity = safeVelocity,
                        )
                        dragPositionPx = Float.NaN
                        dragVelocityPx = 0f
                        releaseVelocityPx = 0f
                        isSettling = false
                    } else if (!centerInitialized) {
                        restingCenter.snapTo(normalCenterPx)
                        centerInitialized = true
                    } else {
                        restingCenter.animateTo(
                            targetValue = normalCenterPx,
                            animationSpec = spring(dampingRatio = 0.82f, stiffness = 620f),
                        )
                    }
                }
                // A settings/geometry change restarts pointerInput. Clear an in-flight
                // drag too, otherwise the old detector may be cancelled before its
                // end/cancel callback and leave the capsule stuck in drag mode.
                LaunchedEffect(dragEnabled, trackWidthPx) {
                    if (isDragging) {
                        isDragging = false
                        isSettling = false
                        dragPreviewIndex = -1
                        dragPositionPx = Float.NaN
                        dragVelocityPx = 0f
                        releasePositionPx = Float.NaN
                        releaseVelocityPx = 0f
                    }
                }

                val bubbleShape = CircleShape

                Box(
                    // The bubble translation is computed in physical track-local X
                    // coordinates (zero is always the left edge). TopStart mirrors
                    // to the right in RTL and adds an unwanted base offset, which
                    // sends the translated capsule outside the track instead of
                    // keeping its origin fixed under the finger. Keep this layer
                    // physically left-anchored in both LTR and RTL.
                    modifier = Modifier.fillMaxSize().then(bubbleDragModifier),
                    contentAlignment = AbsoluteAlignment.TopLeft,
                ) {
                    Box(
                        modifier = Modifier
                            .width(baseBubbleWidth)
                            .height(bubbleHeight)
                            .graphicsLayer {
                                val speedRatio = if (isDragging) {
                                    NavDragPhysics.stretchRatio(dragVelocityPx, density.density)
                                } else 0f
                                val horizontalStretch = if (baseBubbleWidthPx > 0f) {
                                    (maxStretchPx / baseBubbleWidthPx) * speedRatio
                                } else 0f
                                val scale = 1f + horizontalStretch
                                val renderedWidthPx = size.width * scale
                                val fingerCenter = dragPositionPx
                                val center = when {
                                    isDragging && fingerCenter.isFinite() -> fingerCenter
                                    isSettling && releasePositionPx.isFinite() -> releasePositionPx
                                    centerInitialized -> restingCenter.value
                                    else -> normalCenterPx
                                }
                                val boundedLeftPx = NavDragPhysics.centeredOffset(
                                    pointer = center,
                                    bubbleWidth = renderedWidthPx,
                                    trackWidth = trackWidthPx,
                                )
                                val boundedCenterPx = boundedLeftPx + renderedWidthPx / 2f
                                // scaleX is centered around the layer pivot; translation
                                // therefore uses the unscaled layout half-width.
                                translationX = boundedCenterPx - size.width / 2f
                                scaleX = scale
                                translationY = with(density) { ((54.dp - bubbleHeight) / 2).toPx() }
                                shape = bubbleShape
                                clip = true
                                shadowElevation = with(density) { if (isDragging) 10.dp.toPx() else 7.dp.toPx() }
                            }
                            .background(bubbleColor, bubbleShape)
                            .border(
                                width = 1.dp,
                                color = Color.White.copy(alpha = if (isDragging) 0.34f else 0.22f),
                                shape = bubbleShape,
                            ),
                    ) {
                        Box(
                            Modifier.fillMaxWidth().height(18.dp).background(
                                Brush.verticalGradient(
                                    listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.07f), Color.Transparent),
                                ),
                            ),
                        )
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth(0.72f).height(1.dp)
                                .background(Color.White.copy(alpha = 0.20f), CircleShape),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        topLevelDestinations.forEachIndexed { index, destination ->
                            val selected = visualIndex == index
                            val contentColor by animateColorAsState(
                                targetValue = if (selected) selectedBubbleColors.second
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                                animationSpec = tween(130),
                                label = "navBubbleItemColor$index",
                            )
                            val iconSize by animateDpAsState(
                                targetValue = if (selected) 25.dp else 23.dp,
                                animationSpec = spring(dampingRatio = 0.82f, stiffness = 720f),
                                label = "navBubbleIconSize$index",
                            )
                            Surface(
                                onClick = {
                                    dragPreviewIndex = index
                                    onSelect(destination.route)
                                },
                                shape = CircleShape,
                                color = Color.Transparent,
                                contentColor = contentColor,
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                ) {
                                    Icon(
                                        imageVector = if (selected) destination.filledIcon else destination.outlinedIcon,
                                        contentDescription = stringResource(destination.labelRes),
                                        modifier = Modifier.size(iconSize),
                                    )
                                    AnimatedVisibility(
                                        visible = selected && showLabel,
                                        enter = fadeIn(tween(100)) + scaleIn(
                                            initialScale = 0.86f,
                                            animationSpec = spring(dampingRatio = 0.9f, stiffness = 700f),
                                        ),
                                        exit = fadeOut(tween(70)) + scaleOut(targetScale = 0.9f, animationSpec = tween(90)),
                                    ) {
                                        Text(
                                            text = stringResource(destination.labelRes),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            softWrap = false,
                                            textAlign = TextAlign.Center,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The floating bottom pill: one tonal capsule, the open tab expanding to
 * say its name, the rest as icons. Its items use the same shared specs as
 * the side bar's, expanding on the horizontal axis instead.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun FloatingNavPill(
    selectedRoute: String?,
    fixedNavigation: Boolean,
    dragEnabled: Boolean,
    onSelect: (String) -> Unit,
) {
    val selectedIndex = topLevelDestinations.indexOfFirst { it.route == selectedRoute }.coerceAtLeast(0)
    var dragPreviewIndex by remember { mutableStateOf(-1) }
    var isDragging by remember { mutableStateOf(false) }
    val centers = remember { FloatArray(topLevelDestinations.size) { Float.NaN } }
    val trackCoordinates = remember { NavGestureCoordinateSpace() }
    val haptics = LocalHapticFeedback.current
    LaunchedEffect(selectedRoute) { dragPreviewIndex = -1 }
    val dragModifier = rememberNavDragModifier(
        enabled = dragEnabled,
        axis = NavDragAxis.Horizontal,
        itemCenters = centers,
        itemBounds = emptyArray(),
        coordinateSpace = trackCoordinates,
        restrictToItemBounds = false,
        onSelectIndex = { dragPreviewIndex = it },
        onDragStart = { dragPreviewIndex = selectedIndex; isDragging = true; haptics.performHapticFeedback(HapticFeedbackType.LongPress) },
        onDragEnd = {
            val target = dragPreviewIndex
            isDragging = false
            if (target >= 0) topLevelDestinations.getOrNull(target)?.takeIf { it.route != selectedRoute }?.let { onSelect(it.route) }
        },
        onDragCancel = { dragPreviewIndex = -1; isDragging = false },
    )
    val visualIndex = dragPreviewIndex.takeIf { it >= 0 } ?: selectedIndex
    HorizontalFloatingToolbar(
        modifier = dragModifier,
        expanded = true,
        content = {
            topLevelDestinations.forEach { destination ->
                val index = topLevelDestinations.indexOf(destination)
                val selected = visualIndex == index
                val layoutSelected = if (isDragging && !fixedNavigation) selectedIndex == index else selected
                val animatedPadding = navItemPadding(layoutSelected)
                val animatedContainerColor = navContainerColor(
                    selected = selected,
                    activeContainer = MaterialTheme.colorScheme.primaryContainer,
                )
                val animatedContentColor = navContentColor(
                    selected = selected,
                    activeContent = MaterialTheme.colorScheme.onPrimaryContainer,
                )

                Surface(
                    onClick = { onSelect(destination.route) },
                    shape = CircleShape,
                    color = animatedContainerColor,
                    contentColor = animatedContentColor,
                    modifier = Modifier.height(48.dp).onGloballyPositioned { coordinates ->
                        centers[index] = coordinates.boundsInRoot().center.x
                    },
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = if (fixedNavigation) NavItemPaddingCollapsed else animatedPadding)
                            .then(if (fixedNavigation) Modifier else Modifier.animateContentSize(
                                animationSpec = MaterialTheme.motionScheme.fastSpatialSpec()
                            )),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = if (selected) destination.filledIcon else destination.outlinedIcon,
                            contentDescription = stringResource(destination.labelRes),
                            modifier = Modifier.size(NavIconSize)
                        )
                        // The pill names only the open tab.
                        AnimatedVisibility(
                            visible = selected && !fixedNavigation && !isDragging,
                            enter = fadeIn() + expandHorizontally(
                                animationSpec = MaterialTheme.motionScheme.fastSpatialSpec()
                            ),
                            exit = fadeOut() + shrinkHorizontally(
                                animationSpec = MaterialTheme.motionScheme.fastSpatialSpec()
                            ),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Spacer(modifier = Modifier.width(NavLabelGap))
                                Text(
                                    text = stringResource(destination.labelRes),
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }
                }
            }
        },
    )
}
