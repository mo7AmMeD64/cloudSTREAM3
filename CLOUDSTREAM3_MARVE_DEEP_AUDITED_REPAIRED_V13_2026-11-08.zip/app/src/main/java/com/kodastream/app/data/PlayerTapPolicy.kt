package com.kodastream.app.data

/** True only when two taps belong to the same seek/pause region and are close enough. */
internal fun areTapsInSamePlayerZone(
    firstX: Float,
    secondX: Float,
    viewWidth: Int,
    centerPauseEnabled: Boolean,
    maxDistanceFraction: Float = 0.25f,
    centerPauseHalfWidthFraction: Float = 0.06f,
): Boolean {
    val width = viewWidth.coerceAtLeast(1).toFloat()
    fun zone(x: Float): Int {
        val center = width / 2f
        if (!centerPauseEnabled) return if (x < center) -1 else 1
        val pauseHalfWidth = centerPauseHalfWidthFraction * width
        return when {
            x < center - pauseHalfWidth -> -1
            x > center + pauseHalfWidth -> 1
            else -> 0
        }
    }
    return zone(firstX) == zone(secondX) &&
        kotlin.math.abs(firstX - secondX) <= maxDistanceFraction * width
}

/**
 * When only center double-tap pause is enabled, side taps must remain ordinary
 * single taps; otherwise two quick side taps would collapse into one UI action.
 */
internal fun canRecognizePlayerDoubleTap(
    doubleTapSeekEnabled: Boolean,
    centerPauseEnabled: Boolean,
    isInCenterPauseZone: Boolean,
): Boolean = doubleTapSeekEnabled || (centerPauseEnabled && isInCenterPauseZone)

internal fun isInPlayerCenterPauseZone(
    x: Float,
    viewWidth: Int,
    centerPauseHalfWidthFraction: Float = 0.06f,
): Boolean {
    val width = viewWidth.coerceAtLeast(1).toFloat()
    return kotlin.math.abs(x - width / 2f) <= centerPauseHalfWidthFraction * width
}
