package com.kodastream.app.downloads

import java.net.URI
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Pure HLS playlist parsing and URI resolution, separated from the Android download worker. */
internal object HlsPlaylistParser {
    data class EncryptionKey(
        val url: String,
        /** A normalized 128-bit IV in 32 hexadecimal digits, or null for media-sequence IV. */
        val ivHex: String?,
    )

    data class Segment(
        val url: String,
        val key: EncryptionKey?,
    )

    data class MediaPlaylist(
        val mediaSequence: Long,
        val segments: List<Segment>,
    )

    /** Selects the highest-bandwidth variant and resolves it against the master playlist URL. */
    fun selectHighestBandwidthVariant(masterUrl: String, text: String): String? {
        val lines = text.lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
        var bestBandwidth = Long.MIN_VALUE
        var bestUrl: String? = null
        for (index in lines.indices) {
            val line = lines[index]
            if (!line.startsWith("#EXT-X-STREAM-INF:", ignoreCase = true)) continue
            val attributes = parseAttributes(line.substringAfter(':'))
            val bandwidth = attributes["BANDWIDTH"]?.toLongOrNull() ?: 0L
            // EXT-X-STREAM-INF is followed immediately by its URI line.
            val variant = lines.getOrNull(index + 1)?.takeIf { !it.startsWith('#') } ?: continue
            if (bandwidth > bestBandwidth) {
                bestBandwidth = bandwidth
                bestUrl = resolve(masterUrl, variant)
            }
        }
        return bestUrl
    }

    /**
     * Parses a media playlist using that playlist's own URL as the base for segment and key URIs.
     * METHOD=NONE explicitly clears encryption state for following segments.
     */
    fun parseMediaPlaylist(playlistUrl: String, text: String): MediaPlaylist {
        var mediaSequence = 0L
        var currentKey: EncryptionKey? = null
        val segments = ArrayList<Segment>()

        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            when {
                line.startsWith("#EXT-X-MEDIA-SEQUENCE", ignoreCase = true) -> {
                    mediaSequence = line.substringAfter(':', "").toLongOrNull() ?: 0L
                }

                line.startsWith("#EXT-X-MAP:", ignoreCase = true) ->
                    throw IllegalArgumentException("Fragmented MP4 HLS initialization maps are not supported")

                line.startsWith("#EXT-X-BYTERANGE:", ignoreCase = true) ->
                    throw IllegalArgumentException("HLS byte-range segments are not supported")

                line.startsWith("#EXT-X-KEY:", ignoreCase = true) -> {
                    val attributes = parseAttributes(line.substringAfter(':'))
                    when (attributes["METHOD"]?.uppercase()) {
                        "NONE" -> currentKey = null
                        "AES-128" -> {
                            val keyFormat = attributes["KEYFORMAT"] ?: "identity"
                            if (!keyFormat.equals("identity", ignoreCase = true)) {
                                throw IllegalArgumentException("Unsupported HLS key format: $keyFormat")
                            }
                            val keyUri = attributes["URI"]
                                ?: throw IllegalArgumentException("AES-128 HLS key URI is missing")
                            currentKey = EncryptionKey(
                                url = resolve(playlistUrl, keyUri),
                                ivHex = normalizeIv(attributes["IV"]),
                            )
                        }

                        else -> throw IllegalArgumentException("Unsupported HLS encryption method")
                    }
                }

                line.isNotEmpty() && !line.startsWith('#') ->
                    segments.add(Segment(resolve(playlistUrl, line), currentKey))
            }
        }

        if (segments.isEmpty()) throw IllegalArgumentException("No segments in the media playlist")
        return MediaPlaylist(mediaSequence, segments)
    }

    fun resolve(baseUrl: String, relativeOrAbsoluteUrl: String): String = try {
        URI(baseUrl).resolve(relativeOrAbsoluteUrl).toString()
    } catch (_: Exception) {
        relativeOrAbsoluteUrl
    }

    /** Decrypts an AES-128 HLS segment and removes valid PKCS#7 block padding. */
    fun decryptAes128Segment(
        encryptedBytes: ByteArray,
        keyBytes: ByteArray,
        explicitIvHex: String?,
        mediaSequence: Long,
    ): ByteArray {
        require(keyBytes.size == 16) { "HLS AES-128 key must contain 16 bytes" }
        val iv = if (explicitIvHex != null) {
            require(explicitIvHex.length == 32) { "HLS AES-128 IV must contain 16 bytes" }
            explicitIvHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } else {
            ByteArray(16).also { buffer ->
                var value = mediaSequence
                for (index in 15 downTo 0) {
                    buffer[index] = (value and 0xFF).toByte()
                    value = value ushr 8
                }
            }
        }
        val cipher = Cipher.getInstance("AES/CBC/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(iv))
        val plain = cipher.doFinal(encryptedBytes)
        if (plain.isEmpty()) return plain
        val paddingLength = plain.last().toInt() and 0xFF
        if (paddingLength !in 1..16 || paddingLength > plain.size) return plain
        val paddingStart = plain.size - paddingLength
        val validPadding = (paddingStart until plain.size).all {
            (plain[it].toInt() and 0xFF) == paddingLength
        }
        return if (validPadding) plain.copyOf(paddingStart) else plain
    }

    private fun normalizeIv(rawIv: String?): String? {
        if (rawIv.isNullOrBlank()) return null
        val value = rawIv.removePrefix("0x").removePrefix("0X")
        require(value.isNotEmpty() && value.length <= 32 && value.all { it.digitToIntOrNull(16) != null }) {
            "Invalid HLS AES-128 IV"
        }
        return value.padStart(32, '0').uppercase()
    }

    private fun parseAttributes(input: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val regex = Regex("""([A-Z0-9-]+)=("[^"]*"|[^,]*)""", RegexOption.IGNORE_CASE)
        regex.findAll(input).forEach { match ->
            result[match.groupValues[1].uppercase()] = match.groupValues[2]
                .trim()
                .removeSurrounding("\"")
        }
        return result
    }
}
