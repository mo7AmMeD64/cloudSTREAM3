package com.kodastream.app.ui.details

import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.SeasonData
import com.lagradost.cloudstream3.SeasonMetadata
import java.time.Instant
import java.time.ZoneOffset




/**
 * Derive a season's start year only when the first episode is known. A minimum
 * over whichever episode dates happen to exist can incorrectly place a season
 * when the premiere date is missing but a later episode is dated.
 */
internal fun releaseYearForSeasonEpisodes(episodes: List<Episode>): Int? {
    if (episodes.isEmpty()) return null
    val firstKnownAiring = if (episodes.all { it.episode != null }) {
        episodes.withIndex()
            .minWithOrNull(compareBy<IndexedValue<Episode>> { it.value.episode }.thenBy { it.index })
            ?.value?.date?.takeIf { it > 0L }
    } else {
        val validDates = episodes.mapNotNull { it.date?.takeIf { date -> date > 0L } }
        validDates.takeIf { it.size == episodes.size }?.minOrNull()
    }
    return firstKnownAiring?.let { millis ->
        runCatching { Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).year }.getOrNull()
    }
}

/** One visited season plus the exact audio variant that supplied its episodes. */
internal data class SeasonNavigationPoint<Variant>(
    val season: Int,
    val variant: Variant?,
)

/** Result of stepping backward through in-page season navigation. */
internal data class SeasonBackNavigation<Variant>(
    val targetSeason: Int?,
    val targetVariant: Variant?,
    val remainingHistory: List<SeasonNavigationPoint<Variant>>,
)

/**
 * Push the season/variant being left, not the destination. Keeping the audio
 * variant is essential when S1 is only in one dub and S2 only in another: Back
 * must restore both the old season and the source that actually supplied it.
 */
internal fun <Variant> pushSeasonBackStack(
    history: List<SeasonNavigationPoint<Variant>>,
    currentSeason: Int?,
    currentVariant: Variant?,
    targetSeason: Int,
    maxDepth: Int = 24,
): List<SeasonNavigationPoint<Variant>> {
    if (maxDepth <= 0) return emptyList()
    if (currentSeason == null || currentSeason == targetSeason) return history.takeLast(maxDepth)
    if (history.lastOrNull()?.season == currentSeason && history.lastOrNull()?.variant == currentVariant) {
        return history.takeLast(maxDepth)
    }
    return (history + SeasonNavigationPoint(currentSeason, currentVariant)).takeLast(maxDepth)
}

/** Pop the latest season that still belongs to the current provider's season union. */
internal fun <Variant> popSeasonBackStack(
    history: List<SeasonNavigationPoint<Variant>>,
    availableSeasons: List<Int>,
): SeasonBackNavigation<Variant> {
    val validIndex = history.indexOfLast { it.season in availableSeasons }
    if (validIndex < 0) {
        return SeasonBackNavigation(targetSeason = null, targetVariant = null, remainingHistory = emptyList())
    }
    val target = history[validIndex]
    return SeasonBackNavigation(
        targetSeason = target.season,
        targetVariant = target.variant,
        remainingHistory = history.take(validIndex),
    )
}

/**
 * The episode header also owns the dub selector and optional season chips. Keep it
 * visible for an upcoming or currently empty season when there is still a way to
 * switch audio variants or seasons.
 */
@Suppress("UNUSED_PARAMETER")
internal fun shouldShowEpisodeHeader(
    isMovie: Boolean,
    visibleEpisodeCount: Int,
    seasonFilterEnabled: Boolean,
    seasonCount: Int,
    dubOptionCount: Int,
): Boolean = !isMovie && (
    // The header is the in-place season/dub selector and remains a scroll target
    // in both layouts. This helper only controls that header; it does not create
    // a separate "More seasons" or season/release carousel below the episodes.
    // Hiding it for an empty upcoming season would leave no way to switch seasons.
    visibleEpisodeCount > 0 || seasonCount > 1 || dubOptionCount > 1
)

/**
 * Sorts provider season keys by their user-facing season numbers when available.
 * Some sources use a non-sequential internal season key and expose displaySeason
 * specifically to keep the UI order correct.
 */
internal fun seasonDisplayNumberMap(
    seasons: List<Int>,
    seasonNames: List<SeasonData>,
): Map<Int, Int> {
    // Season 0 is valid (specials); negative keys are provider sentinels/corruption.
    val keys = seasons.filter { it >= 0 }.distinct()
    if (keys.isEmpty()) return emptyMap()

    // Keep every SeasonData row for a key: a few providers publish duplicate rows
    // with different names, and choosing the first one can erase its Part/Cour label.
    val namesBySeason = seasonNames.groupBy { it.season }
    val proposed = keys.associateWith { key ->
        namesBySeason[key].orEmpty().firstNotNullOfOrNull { it.displaySeason } ?: key
    }
    val duplicateGroups = proposed.entries.groupBy { it.value }.filterValues { it.size > 1 }
    if (duplicateGroups.isEmpty()) return proposed

    fun splitSignature(key: Int): Pair<Int?, Int?>? {
        val signatures = namesBySeason[key].orEmpty().mapNotNull { row ->
            row.name?.takeIf(String::isNotBlank)?.let(::parseTitleParts)
        }.map { it.courNumber to it.partNumber }
            .filter { it.first != null || it.second != null }
            .distinct()
        // A key with conflicting Part/Cour labels is not a trustworthy split.
        // Only one unambiguous signature per key can prove a distinct release.
        return signatures.singleOrNull()
    }

    // A collision is not evidence of a new numbered season. Preserve the provider's
    // display number and let seasonTimelineMetadata expose an explicit source-group
    // suffix unless distinct Part/Cour markers prove that these are split releases.
    // Preserve every unambiguous provider number (for example, keep a real S4
    // labelled 4 even when two other rows both claim 3). Internal keys remain
    // untouched for routing and episode filtering.
    val sortedGroups = proposed.entries.groupBy { it.value }.toSortedMap()
    val result = LinkedHashMap<Int, Int>(keys.size)
    for ((displayNumber, group) in sortedGroups) {
        val orderedGroup = group.sortedWith(
            compareBy<Map.Entry<Int, Int>> { splitSignature(it.key)?.first ?: Int.MAX_VALUE }
                .thenBy { splitSignature(it.key)?.second ?: Int.MAX_VALUE }
                .thenBy { it.key }
        )
        // Never invent a new season number to make a provider collision look neat.
        // Explicit Parts/Cours share the provider's season number; ambiguous rows
        // also retain that number and are visibly disambiguated as source groups.
        orderedGroup.forEach { result[it.key] = displayNumber }
    }
    return result
}

/**
 * Result of reconciling a provider's partial season list with a verified catalog.
 * `seasonNames` carries the display-number mapping for any synthetic internal keys,
 * while `seasonMetadata` remains keyed by the same internal key used by episodes.
 */
internal data class SeasonCatalogMergeResult(
    val seasonNames: List<SeasonData>,
    val seasonMetadata: List<SeasonMetadata>,
)

/**
 * Merge every verified catalog season into a provider response without assuming its
 * internal season ids equal the displayed season numbers. A scraper may return only
 * Season 2 and tag its episodes as key 1; the catalog's Season 1 must then receive a
 * fresh internal key and an explicit `displaySeason = 1` mapping instead of colliding
 * with the page's existing key. Ambiguous duplicate source mappings are left alone.
 */
internal fun mergeCatalogSeasonMetadata(
    pageTitle: String,
    episodes: List<Episode>,
    sourceSeasonNames: List<SeasonData>,
    sourceMetadata: List<SeasonMetadata>,
    catalogMetadata: List<SeasonMetadata>,
): SeasonCatalogMergeResult {
    if (catalogMetadata.isEmpty()) {
        return SeasonCatalogMergeResult(sourceSeasonNames, sourceMetadata)
    }

    val sourceKeys = (
        episodes.mapNotNull { it.season } +
            sourceSeasonNames.map { it.season } +
            sourceMetadata.map { it.season }
        ).filter { it >= 0 }.distinct().let { keys ->
            if (keys.isEmpty() && episodes.isNotEmpty()) listOf(1) else keys
        }
    val parsedPageTitle = parseTitleParts(pageTitle)
    val effectiveSourceNames = effectiveSeasonNamesForPage(pageTitle, sourceKeys, sourceSeasonNames)
    // Providers sometimes put "Season 2" in SeasonData.name but leave
    // displaySeason null. Recover that explicit number for canonical catalog mapping.
    val normalizedSourceNames = effectiveSourceNames.map { row ->
        val nameSeason = row.name?.let(::parseTitleParts)?.seasonNumber
        if (row.displaySeason == null && nameSeason != null) row.copy(displaySeason = nameSeason) else row
    }.toMutableList()
    // A standalone page title is the only safe mapping source when it exposes one
    // internal key but its extension omitted displaySeason (or left the name blank).
    if (sourceKeys.size == 1 && parsedPageTitle.seasonNumber != null &&
        normalizedSourceNames.none { it.season == sourceKeys.single() && it.displaySeason != null }
    ) {
        val pageKey = sourceKeys.single()
        normalizedSourceNames += SeasonData(
            season = pageKey,
            name = normalizedSourceNames.firstOrNull { it.season == pageKey }?.name,
            displaySeason = parsedPageTitle.seasonNumber,
        )
    }
    val sourceDisplayMap = seasonDisplayNumberMap(sourceKeys, normalizedSourceNames)
    val usedKeys = sourceKeys.toMutableSet()
    // Keep title-derived mapping rows. Once catalog seasons are appended, the page
    // no longer has a single season key, so Compose cannot safely infer this mapping
    // from the title alone during its next recomposition.
    val mergedNames = normalizedSourceNames.toMutableList()

    // Preserve the source's pre-enrichment single-season fallback. Before catalog
    // seasons are appended, the UI assigns seasonless rows to the sole available key;
    // leaving them null after the catalogue expands to multiple keys would make those
    // same playable episodes disappear from every season. Multi-key responses are
    // deliberately left untouched because their seasonless rows are ambiguous.
    if (sourceKeys.size == 1) {
        val pageInternalKey = sourceKeys.single()
        episodes.filter { it.season == null || it.season!! < 0 }
            .forEach { it.season = pageInternalKey }
    }
    val mergedMetadata = sourceMetadata.associateBy { it.season }.toMutableMap()

    fun allocateInternalKey(): Int {
        var candidate = (usedKeys.filter { it >= 0 }.maxOrNull() ?: 0) + 1
        if (candidate > 0 && candidate !in usedKeys) {
            usedKeys += candidate
            return candidate
        }
        candidate = 0
        while (candidate in usedKeys && candidate < Int.MAX_VALUE) candidate++
        usedKeys += candidate
        return candidate
    }

    catalogMetadata.asSequence()
        .filter { it.season >= 0 }
        .distinctBy { it.season }
        .sortedBy { it.season }
        .forEach { catalog ->
            val matchingKeys = sourceKeys.filter { sourceDisplayMap[it] == catalog.season }
            val internalKey = when (matchingKeys.size) {
                1 -> matchingKeys.single()
                0 -> allocateInternalKey().also { syntheticKey ->
                    mergedNames += SeasonData(
                        season = syntheticKey,
                        name = catalog.name?.takeIf(String::isNotBlank),
                        displaySeason = catalog.season,
                    )
                }
                // Two source keys already claim this display season. Do not invent a
                // third row or guess which source group owns the catalog metadata.
                else -> return@forEach
            }
            val existing = mergedMetadata[internalKey]
            mergedMetadata[internalKey] = catalog.copy(
                season = internalKey,
                tmdbId = catalog.tmdbId ?: existing?.tmdbId,
                name = existing?.name?.takeIf(String::isNotBlank) ?: catalog.name,
                overview = existing?.overview?.takeIf(String::isNotBlank) ?: catalog.overview,
                // Catalog lookup supplies relationship/season metadata only. Artwork
                // belongs to the selected provider and must not be replaced by TMDB art.
                posterPath = existing?.posterPath?.takeIf(String::isNotBlank),
                posterUrl = existing?.posterUrl?.takeIf(String::isNotBlank),
                airDate = existing?.airDate?.takeIf(String::isNotBlank) ?: catalog.airDate,
                episodeCount = existing?.episodeCount?.takeIf { it > 0 } ?: catalog.episodeCount,
            )
        }

    return SeasonCatalogMergeResult(
        seasonNames = mergedNames.distinctBy { it.season to it.displaySeason to it.name },
        seasonMetadata = mergedMetadata.values.sortedBy { it.season },
    )
}

internal fun orderSeasonsForDisplay(seasons: List<Int>, seasonNames: List<SeasonData>): List<Int> {
    val keys = seasons.filter { it >= 0 }.distinct()
    val displayNumbers = seasonDisplayNumberMap(keys, seasonNames)
    val namesBySeason = seasonNames.groupBy { it.season }
    fun partOrder(key: Int): Pair<Int, Int> {
        val signatures = namesBySeason[key].orEmpty().asSequence()
            .mapNotNull { it.name?.takeIf(String::isNotBlank)?.let(::parseTitleParts) }
            .map { it.courNumber to it.partNumber }
            .filter { it.first != null || it.second != null }
            .distinct()
            .toList()
        val signature = signatures.singleOrNull()
        return (signature?.first ?: Int.MAX_VALUE) to (signature?.second ?: Int.MAX_VALUE)
    }
    // Specials / season 0 sort after the numbered seasons so the page never opens
    // on "Specials". For same-season split records, explicit Cour/Part metadata
    // orders the entries before the internal source key is used as a stable tie-break.
    return keys.sortedWith(
        compareBy<Int> { (displayNumbers[it] ?: it) <= 0 }
            .thenBy { displayNumbers[it] ?: it }
            .thenBy { partOrder(it).first }
            .thenBy { partOrder(it).second }
            .thenBy { it }
    )
}

/**
 * Maps seasonless episode rows only when the source exposes exactly one season.
 * For multi-season data, assigning an unknown episode to an arbitrary season
 * would show the wrong titles when the user selects a season card.
 */
internal fun groupEpisodesByDisplaySeason(
    episodes: List<Episode>,
    seasons: List<Int>,
): Map<Int, List<Episode>> = episodes.mapNotNull { episode ->
    val season = episode.season?.takeIf { it >= 0 } ?: seasons.singleOrNull()
    season?.takeIf { it >= 0 }?.let { it to episode }
}.groupBy({ it.first }, { it.second })

/** Null and negative provider sentinels both mean that no usable season was assigned. */
internal fun isUnassignedSeason(season: Int?): Boolean = season == null || season < 0

/**
 * Keep season artwork only when it is not shared by multiple seasons. A large
 * number of providers expose the series poster on every episode; treating it as
 * season art makes every season card an identical copy of the work poster.
 */
internal fun uniqueSeasonArtworkBySeason(
    episodesBySeason: Map<Int, List<Episode>>,
): Map<Int, String?> {
    val candidates = episodesBySeason.mapValues { (_, episodes) ->
        episodes.mapNotNull { it.posterUrl?.takeIf(String::isNotBlank) }.distinct()
    }
    val owners = candidates.flatMap { (season, posters) ->
        posters.map { poster -> poster to season }
    }.groupBy({ it.first }, { it.second })
    return candidates.mapValues { (_, posters) ->
        posters.firstOrNull { owners[it]?.distinct()?.size == 1 }
    }
}

/**
 * A stable episode key for comparing artwork across audio variants. Explicit
 * season/episode coordinates identify the same episode across dubs even when
 * their playback URLs differ. When coordinates are incomplete, keep each row
 * separate rather than guessing that two entries are the same episode.
 */
private fun episodeArtworkOwnerKey(episode: Episode): String = when {
    episode.season != null && episode.episode != null ->
        "season:${episode.season}|episode:${episode.episode}"
    else -> "unresolved:${episode.season ?: "?"}|${episode.data}"
}

/**
 * Keep episode artwork only when a URL belongs to exactly one logical episode
 * across the full work, not merely the currently visible season/audio variant.
 * Repeated source posters fall back to the work poster instead of reappearing
 * through the raw Episode.posterUrl field.
 */
internal fun uniqueEpisodeArtworkByKey(
    episodes: List<Pair<String, Episode>>,
    allEpisodes: List<Episode> = episodes.map { it.second },
): Map<String, String?> {
    val postersByEpisode = allEpisodes.groupBy(::episodeArtworkOwnerKey).mapValues { (_, rows) ->
        rows.mapNotNull { it.posterUrl?.takeIf(String::isNotBlank) }.toSet()
    }
    val ownersByPoster = mutableMapOf<String, MutableSet<String>>()
    postersByEpisode.forEach { (owner, posters) ->
        posters.forEach { poster -> ownersByPoster.getOrPut(poster) { linkedSetOf() }.add(owner) }
    }
    return episodes.associate { (key, episode) ->
        val poster = episode.posterUrl?.takeIf(String::isNotBlank)
        key to poster?.takeIf { ownersByPoster[it]?.size == 1 }
    }
}

/** Prefer exact episode art, then the verified season image, then the work poster. */
internal fun episodeArtworkFallback(
    uniqueEpisodeArtwork: String?,
    seasonPoster: String?,
    workPoster: String?,
): String? = sequenceOf(uniqueEpisodeArtwork, seasonPoster, workPoster)
    .firstOrNull { !it.isNullOrBlank() }

/**
 * Use only artwork supplied by the opened provider. External metadata catalogs
 * may identify a season but must not supply artwork to this provider's page.
 */
internal fun seasonArtworkFallback(
    entryPoster: String?,
    uniqueSeasonPoster: String?,
    workPoster: String?,
): String? = sequenceOf(entryPoster, uniqueSeasonPoster, workPoster)
    .firstOrNull { !it.isNullOrBlank() }

/**
 * Order episodes only when the provider gives a complete ordering signal. A complete
 * episode-number set wins; otherwise complete dates are used. Partial metadata keeps
 * the provider's original order instead of moving unknown episodes to arbitrary places.
 */
internal fun orderEpisodesWithinSeason(episodes: List<Episode>): List<Episode> {
    if (episodes.size < 2) return episodes
    return when {
        episodes.all { it.episode != null } -> episodes.withIndex()
            .sortedWith(compareBy<IndexedValue<Episode>> { it.value.episode }.thenBy { it.index })
            .map { it.value }
        episodes.all { it.date != null } -> episodes.withIndex()
            .sortedWith(compareBy<IndexedValue<Episode>> { it.value.date }.thenBy { it.index })
            .map { it.value }
        else -> episodes
    }
}

/**
 * Return only episodes that can be assigned to the requested season. In a
 * multi-season work, a seasonless row is never guessed into a season. When no
 * season is selected and the provider's mapping is partial, preserve provider
 * order and the complete list so the user can still inspect available rows.
 */
internal fun visibleEpisodesForSeason(
    episodes: List<Episode>,
    selectedSeason: Int?,
    orderedSeasons: List<Int>,
    isMovie: Boolean,
    mappingUnavailable: Boolean,
): List<Episode> {
    if (isMovie) return emptyList()
    if (selectedSeason == null) {
        return if (mappingUnavailable) episodes else orderEpisodesWithinSeason(episodes)
    }
    val filtered = episodes.filter { episode ->
        episode.season == selectedSeason || (isUnassignedSeason(episode.season) && orderedSeasons.size <= 1)
    }
    return orderEpisodesWithinSeason(filtered)
}

/**
 * Pick the audio variant with the broadest reliable season coverage. The old
 * first-match rule chose the first variant containing *any* season tag, even if
 * another variant exposed more seasons (or had fewer unassigned episodes). That
 * made real seasons disappear from both the rail and the filter.
 */
internal fun <Option> preferredSeasonMappedOption(
    options: List<Option>,
    seasons: List<Int>,
    episodesByOption: Map<Option, List<Episode>>,
): Option? {
    if (options.isEmpty()) return null
    if (seasons.size <= 1) {
        // Preserve source order among usable variants, but never default to an empty
        // variant when another audio option actually contains the season's episodes.
        return options.firstOrNull { !episodesByOption[it].isNullOrEmpty() } ?: options.first()
    }
    return options.sortedWith(
        compareByDescending<Option> { option ->
            val episodes = episodesByOption[option].orEmpty()
            episodes.isNotEmpty()
        }.thenByDescending { option ->
            val episodes = episodesByOption[option].orEmpty()
            // A complete mapping is safer than a larger but ambiguous list.
            episodes.isNotEmpty() && episodes.none { it.season == null }
        }.thenByDescending { option ->
            episodesByOption[option].orEmpty().mapNotNull { it.season }.distinct().size
        }.thenBy { option -> episodesByOption[option].orEmpty().count { it.season == null } }
            .thenByDescending { option -> episodesByOption[option].orEmpty().count { it.season != null } }
    ).firstOrNull()
}

/**
 * Select the audio variant that can actually play a requested season. Keep the
 * user's current variant when it contains that season; otherwise choose the
 * variant with the most episode rows for the target season. Seasonless rows are
 * only eligible when the work has one season, where the mapping is unambiguous.
 */
/**
 * Source-declared seasons remain navigable when episode rows are temporarily absent,
 * provided the source has a stable catalog id or declares a positive episode count.
 * This covers TMDB season records and grouped providers such as MyDramaList.
 */
/** Season rows explicitly declared by the owning provider are real seasons even when
 * its episode endpoint temporarily returns no rows and no TMDB metadata is attached. */
internal fun providerDeclaredSeasonKeys(seasonNames: List<SeasonData>): Set<Int> =
    seasonNames.asSequence()
        .map { it.season }
        .filter { it >= 0 }
        .toCollection(LinkedHashSet())

internal fun catalogVerifiedEmptySeasons(
    seasonMetadata: List<SeasonMetadata>,
    allVariantEpisodes: List<Episode>,
): Set<Int> {
    val episodeBackedSeasons = allVariantEpisodes.mapNotNull { it.season }.toSet()
    return seasonMetadata.asSequence()
        .filter {
            it.season >= 0 && ((it.tmdbId ?: 0) > 0 || (it.episodeCount ?: 0) > 0) &&
                it.season !in episodeBackedSeasons
        }
        .map { it.season }
        .toCollection(LinkedHashSet())
}

/** Select a season only when the active variant can identify it. */
internal fun initialSelectedSeason(
    seasons: List<Int>,
    selectedVariantEpisodes: List<Episode>,
    mappingUnavailable: Boolean,
    verifiedEmptySeasons: Set<Int> = emptySet(),
): Int? {
    if (seasons.isEmpty()) return null
    // A partially mapped variant can still identify real seasons. Prefer the first
    // explicit season it contains; a TMDB-declared season is also a safe initial
    // target even when its episode endpoint currently returns an empty list.
    seasons.firstOrNull { season -> selectedVariantEpisodes.any { it.season == season } }?.let { return it }
    seasons.firstOrNull { it in verifiedEmptySeasons }?.let { return it }
    if (mappingUnavailable) return null
    return seasons.firstOrNull()
}

internal fun <Option> preferredOptionForSeason(
    options: List<Option>,
    season: Int,
    episodesByOption: Map<Option, List<Episode>>,
    singleSeason: Boolean,
    currentOption: Option?,
): Option? {
    val matching = options.filter { option ->
        episodesByOption[option].orEmpty().any { episode ->
            episode.season == season || (singleSeason && episode.season == null)
        }
    }
    return matching.firstOrNull { it == currentOption }
        ?: matching.maxByOrNull { option ->
            episodesByOption[option].orEmpty().count { it.season == season || (singleSeason && it.season == null) }
        }
}


/**
 * Builds the complete playback sequence from the same per-season variant choices
 * used by the details screen. A provider may put different seasons in different
 * dub/sub variants; using only the currently selected variant silently truncates
 * Next/Previous at the end of the first variant's last season.
 *
 * If multi-season mapping is ambiguous, keep the active provider list intact rather
 * than merging rows whose season cannot be identified safely.
 */
internal fun <Option> episodesForPlaybackQueue(
    options: List<Option>,
    orderedSeasons: List<Int>,
    episodesByOption: Map<Option, List<Episode>>,
    currentOption: Option?,
    mappingUnavailable: Boolean,
): List<Episode> {
    val currentEpisodes = currentOption?.let { episodesByOption[it] }.orEmpty()
    // With only one variant, an incomplete mapping gives no safe way to place
    // unassigned rows into the cross-season queue, so preserve that provider list.
    // If alternate variants exist, still build a mapped queue from their verified
    // season rows rather than dropping real seasons merely because the active dub
    // also contains an unassigned entry.
    if (orderedSeasons.size <= 1 || (mappingUnavailable && options.size <= 1)) return currentEpisodes

    // Even when the active variant has unassigned rows, explicitly numbered rows
    // from all variants can be sequenced safely. Unknown rows are deliberately not
    // injected into a guessed season; if there is no safe mapped queue, retain the
    // active provider's own list as a conservative fallback.
    val mappedQueue = orderedSeasons.flatMap { season ->
        val option = preferredOptionForSeason(
            options = options,
            season = season,
            episodesByOption = episodesByOption,
            singleSeason = false,
            currentOption = currentOption,
        ) ?: return@flatMap emptyList()
        orderEpisodesWithinSeason(
            episodesByOption[option].orEmpty().filter { it.season == season },
        )
    }
    return mappedQueue.ifEmpty { currentEpisodes }
}


/**
 * Reconcile the selected season with the audio variant the user explicitly chose.
 * The global season rail is a union across variants, but the episode list must never
 * keep a season that the active variant cannot actually play. A catalog-verified
 * empty season and a verified upcoming season are explicit no-episode exceptions.
 */
internal fun reconcileSeasonForVariant(
    currentSeason: Int?,
    orderedSeasons: List<Int>,
    variantEpisodes: List<Episode>,
    nextAiringSeason: Int?,
    nextAiringUnixTimeSeconds: Long?,
    comingSoon: Boolean,
    nowUnixSeconds: Long,
    verifiedEmptySeasons: Set<Int> = emptySet(),
): Int? {
    // A single unassigned row must not clear a season that has explicitly mapped
    // episodes in this variant. Unassigned rows are simply excluded from that
    // season's episode list; they are never attributed to an arbitrary season.
    fun hasEpisodes(season: Int): Boolean = variantEpisodes.any { episode ->
        episode.season == season || (orderedSeasons.size == 1 && episode.season == null)
    }
    fun isUpcoming(season: Int): Boolean = isSeasonUpcoming(
        season = season,
        episodeTimesMillis = variantEpisodes.filter { it.season == season ||
            (orderedSeasons.size == 1 && it.season == null) }.map { it.date },
        nextAiringSeason = nextAiringSeason,
        nextAiringUnixTimeSeconds = nextAiringUnixTimeSeconds,
        comingSoon = comingSoon,
        singleSeason = orderedSeasons.size == 1,
        nowUnixSeconds = nowUnixSeconds,
    )

    if (currentSeason != null && currentSeason in orderedSeasons &&
        (hasEpisodes(currentSeason) || currentSeason in verifiedEmptySeasons || isUpcoming(currentSeason))) {
        return currentSeason
    }

    return orderedSeasons.firstOrNull { hasEpisodes(it) }
        ?: orderedSeasons.firstOrNull { it in verifiedEmptySeasons }
        ?: orderedSeasons.firstOrNull { isUpcoming(it) }
}

/**
 * True only when the source explicitly declares an upcoming season and its airing
 * timestamp is still in the future. A larger season key alone is not evidence.
 */
internal fun isSeasonExplicitlyUpcoming(
    season: Int,
    nextAiringSeason: Int?,
    nextAiringUnixTimeSeconds: Long?,
    nowUnixSeconds: Long,
): Boolean = season == nextAiringSeason &&
    nextAiringUnixTimeSeconds != null && nextAiringUnixTimeSeconds > nowUnixSeconds

/**
 * Treat a season as upcoming only when the provider supplies reliable evidence:
 * a future timestamp for every listed episode, an explicit future next-airing
 * record for an otherwise empty season, or a single-season work marked upcoming
 * when its provider has not supplied episode rows yet.
 * Missing dates are deliberately not treated as future dates.
 */
internal fun isSeasonUpcoming(
    season: Int,
    episodeTimesMillis: List<Long?>,
    nextAiringSeason: Int?,
    nextAiringUnixTimeSeconds: Long?,
    comingSoon: Boolean,
    singleSeason: Boolean,
    nowUnixSeconds: Long,
): Boolean {
    val nowMillis = nowUnixSeconds * 1000L
    // A show-level comingSoon flag is not enough to override an existing episode
    // list whose dates are missing. Only use it for a metadata-only single season;
    // otherwise we risk labeling available seasons as upcoming.
    if (comingSoon && singleSeason && episodeTimesMillis.isEmpty()) return true

    val allListedEpisodesAreFuture = episodeTimesMillis.isNotEmpty() &&
        episodeTimesMillis.all { timeMillis ->
            timeMillis != null && timeMillis > nowMillis
        }
    if (allListedEpisodesAreFuture) return true

    return episodeTimesMillis.isEmpty() && isSeasonExplicitlyUpcoming(
        season = season,
        nextAiringSeason = nextAiringSeason,
        nextAiringUnixTimeSeconds = nextAiringUnixTimeSeconds,
        nowUnixSeconds = nowUnixSeconds,
    )
}

/**
 * Finds the most recent season with positive airing evidence. When a provider
 * omits dates for every episode, the last season with episode rows is a useful
 * UI fallback; once any dates are supplied, an unknown date is never treated as
 * proof that the season has aired.
 */
internal fun newestAiredSeason(
    seasons: List<Int>,
    episodesBySeason: Map<Int, List<Episode>>,
    nowMillis: Long,
): Int? {
    val allEpisodes = episodesBySeason.values.flatten()
    val providerHasAnyDates = allEpisodes.any { it.date != null }
    val withAiredEpisode = seasons.filter { season ->
        episodesBySeason[season].orEmpty().any { episode ->
            episode.date?.let { it <= nowMillis } == true
        }
    }
    return withAiredEpisode.lastOrNull()
        ?: if (!providerHasAnyDates) seasons.lastOrNull { !episodesBySeason[it].isNullOrEmpty() }
        else null
}


/**
 * The number shown to users is the provider's display number when supplied,
 * otherwise the season's source key. Names must not hide the season number.
 */
internal fun seasonNumberForDisplay(
    season: Int,
    seasonNames: List<SeasonData>,
    allSeasons: List<Int> = seasonNames.map { it.season } + season,
): Int = seasonDisplayNumberMap(allSeasons + season, seasonNames)[season] ?: season

/**
 * Many CloudStream scrapers publish each season/part/cour on its own page and leave
 * `seasonNames` empty while tagging episodes as `null` or `1`. Without inspecting the
 * page's own explicit title markers, Season 2, Season 3, or Cour 2 pages display
 * themselves as "Season 1". Derive a single synthetic [SeasonData] only when the
 * provider declared no season names and the page exposes at most one season key.
 */
internal fun effectiveSeasonNamesForPage(
    pageTitle: String,
    orderedSeasonKeys: List<Int>,
    declaredSeasonNames: List<SeasonData>,
): List<SeasonData> {
    if (declaredSeasonNames.isNotEmpty() || orderedSeasonKeys.size > 1) {
        return declaredSeasonNames
    }
    val parsed = parseTitleParts(pageTitle)
    if (parsed.seasonNumber == null && parsed.partNumber == null && parsed.courNumber == null) {
        return declaredSeasonNames
    }
    val internalKey = orderedSeasonKeys.singleOrNull() ?: 1
    val displaySeason = parsed.seasonNumber ?: 1
    val splitSuffix = listOfNotNull(
        parsed.courNumber?.let { "Cour $it" },
        parsed.partNumber?.let { "Part $it" },
    ).joinToString(" · ").takeIf { it.isNotBlank() }
    return listOf(
        SeasonData(
            season = internalKey,
            name = splitSuffix,
            displaySeason = displaySeason,
        )
    )
}

/**
 * Avoid labels such as "Season 3 · Season 3 Part 2" when providers include the
 * display number inside SeasonData.name. Preserve useful suffixes (Part/Cour/name)
 * but never let a textual season number replace the canonical display number.
 */
internal fun seasonNameForDisplay(name: String?): String? {
    val label = name?.trim()?.takeIf(String::isNotBlank) ?: return null
    if (parseTitleParts(label).seasonNumber == null) return label

    val numberToken = "(?:[0-9٠-٩۰-۹]{1,3}(?:st|nd|rd|th)?|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|thirteenth|fourteenth|fifteenth|sixteenth|seventeenth|eighteenth|nineteenth|twentieth|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|i{1,3}|iv|v|vi{0,3}|ix|x|xi{0,3}|xiv|xv|الاول|الأول|الاولى|الأولى|الثاني|الثانية|الثالث|الثالثة|الرابع|الخامس|السادس|السابع|الثامن|التاسع|العاشر|الاخير|الأخير)"
    val prefix = Regex(
        "(?iu)^\\s*(?:(?:season|series|s|الموسم|موسم)\\s*$numberToken|$numberToken\\s*(?:season|series|الموسم|موسم))\\s*(?:[:：·–—-]\\s*)?"
    )
    return label.replaceFirst(prefix, "").trim().takeIf(String::isNotBlank)
}


/**
 * Canonical season-card metadata extracted once from the provider season rows.
 * This preserves Part/Cour ordering when the unified timeline sorts the season
 * entries together with films and related releases.
 */
internal data class SeasonTimelineMetadata(
    val displayName: String?,
    val partOrder: Int,
    val courOrder: Int?,
    val partGroupKey: String?,
    /** One-based disambiguator for unverified duplicate provider season rows. */
    val sourceGroupNumber: Int? = null,
    /** More than one incompatible Part/Cour label was attached to this same internal key. */
    val multipleSplitLabels: Boolean = false,
)

internal fun seasonTimelineMetadata(
    season: Int,
    seasonNames: List<SeasonData>,
    allSeasons: List<Int> = seasonNames.map { it.season } + season,
): SeasonTimelineMetadata {
    val matchingRows = seasonNames.asSequence().filter { it.season == season }.toList()
    val markerRows = matchingRows.mapNotNull { row ->
        val parsed = row.name?.let(::parseTitleParts) ?: return@mapNotNull null
        if (parsed.partNumber == null && parsed.courNumber == null) null else row to parsed
    }
    val markerSignatures = markerRows.map { it.second.courNumber to it.second.partNumber }.distinct()
    val multipleSplitLabels = markerSignatures.size > 1
    val preferredMarker = markerRows.singleOrNull()?.second
    val fallbackName = matchingRows.firstOrNull { row ->
        row.name?.let(::parseTitleParts)?.let {
            it.partNumber == null && it.courNumber == null && it.seasonNumber == null
        } == true
    }?.name
    val chosenName = when {
        multipleSplitLabels -> fallbackName
        preferredMarker != null -> markerRows.single().first.name
        else -> matchingRows.firstNotNullOfOrNull { it.name?.takeIf(String::isNotBlank) }
    }
    val parsed = if (multipleSplitLabels) null else preferredMarker ?: chosenName?.let(::parseTitleParts)
    val distinctKeys = allSeasons.distinct()
    val displayMap = seasonDisplayNumberMap(distinctKeys + season, seasonNames)
    val displayNumber = displayMap[season] ?: season
    val collidingKeys = distinctKeys.filter { (displayMap[it] ?: it) == displayNumber }
    fun explicitSplitSignature(key: Int): Pair<Int?, Int?>? {
        val signatures = seasonNames.asSequence()
            .filter { it.season == key }
            .mapNotNull { it.name?.let(::parseTitleParts) }
            .map { it.courNumber to it.partNumber }
            .filter { it.first != null || it.second != null }
            .distinct()
            .toList()
        return signatures.singleOrNull()
    }
    val signatures = collidingKeys.map(::explicitSplitSignature)
    val isVerifiedSplit = collidingKeys.size > 1 &&
        signatures.all { it != null } && signatures.distinct().size == collidingKeys.size
    val sourceGroupNumber = if (collidingKeys.size > 1 && !isVerifiedSplit) {
        collidingKeys.sorted().indexOf(season).takeIf { it >= 0 }?.plus(1)
    } else null
    return SeasonTimelineMetadata(
        displayName = seasonNameForDisplay(chosenName),
        partOrder = parsed?.partNumber ?: 0,
        courOrder = parsed?.courNumber,
        partGroupKey = parsed?.partGroupKey,
        sourceGroupNumber = sourceGroupNumber,
        multipleSplitLabels = multipleSplitLabels,
    )
}


/** Relation to the currently selected season. Only adjacent entries receive navigation labels. */
internal enum class SeasonNavigationRelation { PREVIOUS, CURRENT, NEXT, OTHER }

internal fun seasonNavigationRelation(
    season: Int,
    orderedSeasons: List<Int>,
    selectedSeason: Int?,
): SeasonNavigationRelation {
    val currentIndex = orderedSeasons.indexOf(selectedSeason)
    if (currentIndex < 0) return SeasonNavigationRelation.OTHER
    return when (season) {
        selectedSeason -> SeasonNavigationRelation.CURRENT
        orderedSeasons.getOrNull(currentIndex - 1) -> SeasonNavigationRelation.PREVIOUS
        orderedSeasons.getOrNull(currentIndex + 1) -> SeasonNavigationRelation.NEXT
        else -> SeasonNavigationRelation.OTHER
    }
}

/**
 * A season is labeled previous only when we have evidence it aired and a newer
 * season has aired. If the provider has no dates at all, display order is the
 * only available fallback; unknown dates are not evidence once dates exist.
 */
internal fun isSeasonPreviouslyAired(
    season: Int,
    orderedSeasons: List<Int>,
    episodesBySeason: Map<Int, List<Episode>>,
    nowMillis: Long,
): Boolean {
    val newest = newestAiredSeason(orderedSeasons, episodesBySeason, nowMillis) ?: return false
    if (season == newest) return false
    val seasonEpisodes = episodesBySeason[season].orEmpty()
    if (seasonEpisodes.isEmpty()) return false
    val allEpisodes = episodesBySeason.values.flatten()
    val providerHasAnyDates = allEpisodes.any { it.date != null }
    val thisSeasonHasAiredEpisode = seasonEpisodes.any { episode ->
        episode.date?.let { it <= nowMillis } == true
    }
    return if (providerHasAnyDates) {
        thisSeasonHasAiredEpisode && orderedSeasons.indexOf(season) < orderedSeasons.indexOf(newest)
    } else {
        orderedSeasons.indexOf(season) < orderedSeasons.indexOf(newest)
    }
}

/**
 * The season rail represents the work, not just the currently selected audio
 * variant. Keep the union of provider-declared season keys; availability and
 * navigability are verified against the union of actual episode rows below. The
 * selected variant is chosen only when a user opens a season.
 */
@Suppress("UNUSED_PARAMETER")
internal fun seasonsForVariant(
    allSeasons: List<Int>,
    selectedVariantEpisodes: List<Episode>,
    allVariantEpisodes: List<Episode>,
    variantCount: Int,
): List<Int> = allSeasons.filter { it >= 0 }.distinct()


/**
 * Result of resolving seasons that can safely be opened across provider variants.
 * A provider-declared season is navigable when the source explicitly lists it,
 * it contains real episode rows, has a stable catalog identity, or carries explicit
 * future-airing evidence. Incomplete
 * multi-season episode mapping is reported separately; it must not suppress seasons
 * that can be proven from any audio variant.
 */
internal data class NavigableSeasonResolution(
    val seasons: List<Int>,
    val mappingUnavailable: Boolean,
)

internal fun resolveNavigableSeasons(
    allSeasons: List<Int>,
    selectedVariantEpisodes: List<Episode>,
    allVariantEpisodes: List<Episode>,
    variantCount: Int,
    nextAiringSeason: Int?,
    nextAiringUnixTimeSeconds: Long?,
    comingSoon: Boolean,
    nowUnixSeconds: Long,
    verifiedEmptySeasons: Set<Int> = emptySet(),
): NavigableSeasonResolution {
    val mappingUnavailable = allSeasons.size > 1 &&
        selectedVariantEpisodes.isNotEmpty() && selectedVariantEpisodes.any { isUnassignedSeason(it.season) }

    // Never let one malformed/seasonless row in the selected dub erase the union
    // of seasons declared by the work and backed by episodes in another dub/sub.
    // Mapping quality is a warning about the active variant, not a global statement
    // that the work has no navigable seasons.
    // Season 0 is the specials bucket; negative values are never navigable.
    val candidates = seasonsForVariant(
        allSeasons = allSeasons,
        selectedVariantEpisodes = selectedVariantEpisodes,
        allVariantEpisodes = allVariantEpisodes,
        variantCount = variantCount,
    )
    // A season may exist only in the other dub/sub variant. Verify against the
    // union, then DetailsScreen switches to the matching variant when it is opened.
    val episodesBySeason = groupEpisodesByDisplaySeason(allVariantEpisodes, candidates)
    val navigable = candidates.filter { season -> season >= 0 }.filter { season ->
        val episodes = episodesBySeason[season].orEmpty()
        season in verifiedEmptySeasons || episodes.isNotEmpty() || isSeasonUpcoming(
            season = season,
            episodeTimesMillis = episodes.map { it.date },
            nextAiringSeason = nextAiringSeason,
            nextAiringUnixTimeSeconds = nextAiringUnixTimeSeconds,
            comingSoon = comingSoon,
            singleSeason = candidates.size == 1,
            nowUnixSeconds = nowUnixSeconds,
        )
    }
    return NavigableSeasonResolution(navigable, mappingUnavailable = mappingUnavailable)
}
