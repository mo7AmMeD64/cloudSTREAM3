package com.kodastream.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kodastream.app.R
import com.kodastream.app.ui.components.PosterCard
import com.kodastream.app.ui.sources.SourceViewModel
import com.lagradost.cloudstream3.SearchResponse
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Complete, source-scoped catalogue opened from the Home "All" row.
 * It shares HomeViewModel paging so pages continue from the exact provider cursors
 * already used by the Home shelf, without introducing a second paging engine.
 */
@Composable
fun SourceCatalogScreen(
    viewModel: HomeViewModel,
    sourceViewModel: SourceViewModel,
    onBack: () -> Unit,
    onOpenItem: (SearchResponse) -> Unit,
) {
    val selectedSource by viewModel.selected.collectAsState()
    val rows by viewModel.rows.collectAsState()
    val extraItems by viewModel.catalogItems.collectAsState()
    val loading by viewModel.catalogLoading.collectAsState()
    val hasMore by viewModel.catalogHasMore.collectAsState()
    val failed by viewModel.catalogFailed.collectAsState()
    val homeSource by sourceViewModel.home.collectAsState()

    // The Home destination may not be composed when Android restores this
    // nested route. Resolve its source here so the catalogue can recover safely.
    LaunchedEffect(homeSource) { viewModel.setSource(homeSource) }

    val catalogEntries = remember(rows, extraItems, selectedSource) {
        (rows.flatMap { it.items } + extraItems)
            .distinctBy { it.apiName to it.url }
    }
    val gridState = rememberLazyGridState()
    val pagingState by rememberUpdatedState(Triple(hasMore, loading, failed))

    LaunchedEffect(selectedSource) {
        gridState.scrollToItem(0)
    }

    LaunchedEffect(gridState, selectedSource) {
        snapshotFlow {
            val info = gridState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            val total = info.totalItemsCount
            val (canLoad, isLoading, hasFailed) = pagingState
            Triple(last to total, canLoad, isLoading to hasFailed)
        }.distinctUntilChanged().collect { (range, canLoad, state) ->
            val (last, total) = range
            val (isLoading, hasFailed) = state
            val isNearEnd = total > 0 && last >= total - 7
            if (isNearEnd && canLoad && !isLoading && !hasFailed) viewModel.loadMoreCatalog()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(top = 4.dp, bottom = 4.dp, start = 8.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilledTonalIconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.back),
                )
            }
            Text(
                text = stringResource(R.string.home_catalog_title, selectedSource ?: stringResource(R.string.home_catalog_all)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            )
            Text(
                text = catalogEntries.size.toString(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize().navigationBarsPadding(),
        ) {
            items(
                items = catalogEntries,
                key = { it.apiName to it.url },
                contentType = { "source-catalog-poster" },
            ) { item ->
                PosterCard(
                    item = item,
                    onClick = { onOpenItem(item) },
                    modifier = Modifier.fillMaxWidth(),
                    cardWidth = null,
                )
            }

            item(key = "catalog_footer", span = { GridItemSpan(maxLineSpan) }) {
                when {
                    loading -> Box(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                        contentAlignment = Alignment.Center,
                    ) { LoadingIndicator(Modifier.size(30.dp)) }

                    failed && hasMore -> TextButton(
                        onClick = { viewModel.loadMoreCatalog(retry = true) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(R.string.retry)) }

                    catalogEntries.isEmpty() -> Text(
                        text = stringResource(R.string.home_catalog_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    )

                    !hasMore -> Text(
                        text = stringResource(R.string.no_more_items),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    )
                }
            }
        }
    }
}
