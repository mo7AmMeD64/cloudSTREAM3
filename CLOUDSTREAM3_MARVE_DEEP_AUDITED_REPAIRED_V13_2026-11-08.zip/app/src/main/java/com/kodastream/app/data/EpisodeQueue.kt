package com.kodastream.app.data

import com.lagradost.cloudstream3.AnimeLoadResponse
import com.lagradost.cloudstream3.DubStatus
import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.EpisodeResponse
import com.lagradost.cloudstream3.LoadResponse
import com.lagradost.cloudstream3.TvSeriesLoadResponse
import com.kodastream.app.ui.details.orderSeasonsForDisplay
import com.kodastream.app.ui.details.orderEpisodesWithinSeason

/** One episode in the player's playback queue, flattened across seasons. */
data class QueueEpisode(
    val season: Int?,
    val number: Int?,
    val name: String?,
    /** The provider data string, or a local file URI when downloaded. */
    val data: String,
    val posterUrl: String? = null,
    /** Position in the flat ordered list. */
    val index: Int = 0,
    /** User-facing season number shown in the player overlay, never a queue position. */
    val seasonIndex: Int? = null,
)

/**
 * Everything the player needs to walk through a series: the flat episode
 * list, seasons ascending, so "next" at the end of a season crosses into the
 * following one and "previous" at the first crosses back.
 *
 * Built once on the details page and handed to the player with the playback
 * args; when playback starts from Downloads or History instead, the player
 * rebuilds it from the details page (or, offline, from the downloaded
 * records of the same title).
 */
data class EpisodeQueue(
    val apiName: String,
    val url: String,
    val title: String,
    val posterUrl: String? = null,
    val posterHeaders: Map<String, String>? = null,
    val type: String = "series",
    /** Distinct seasons in play order; -1 stands for episodes with no season. */
    val seasons: List<Int> = emptyList(),
    val episodes: List<QueueEpisode> = emptyList(),
    /** True when the list was rebuilt from downloads while offline. */
    val offlineOnly: Boolean = false,
)

/** Stable season ordering shared by playback queues and its unit tests. */
internal fun orderQueueSeasonKeys(seasonKeys: List<Int?>, seasonOrder: List<Int>): List<Int?> {
    val distinct = seasonKeys.distinct()
    if (seasonOrder.isEmpty()) return distinct
    val rank = seasonOrder.withIndex().associate { it.value to it.index }
    return distinct.sortedWith(
        compareBy<Int?> { season -> season?.let { rank[it] } ?: Int.MAX_VALUE }
            .thenBy { season -> season ?: Int.MAX_VALUE }
    )
}

/**
 * Resolve the queue's current row by its stable episode coordinates first.
 * Providers sometimes reuse one playback-data token for more than one episode;
 * choosing the first matching URL would then jump to the wrong episode on open.
 */
internal fun findPlaybackQueueIndex(
    episodes: List<QueueEpisode>,
    data: String,
    season: Int?,
    episode: Int?,
): Int {
    if (season != null && episode != null) {
        val exactCoordinateAndData = episodes.indexOfFirst { row ->
            row.season == season && row.number == episode && row.data == data
        }
        if (exactCoordinateAndData >= 0) return exactCoordinateAndData

        val exactCoordinate = episodes.indexOfFirst { row ->
            row.season == season && row.number == episode
        }
        if (exactCoordinate >= 0) return exactCoordinate
    }
    return episodes.indexOfFirst { it.data == data }
}

/**
 * Stable offline queue ordering. Newly downloaded rows carry the exact display
 * positions used by Details; older persisted records retain the previous numeric
 * season/episode fallback until they are downloaded again.
 */
internal fun orderDownloadedRecords(records: List<DownloadStore.Download>): List<DownloadStore.Download> {
    val allHaveDisplayOrder = records.all { it.seasonDisplayOrder != null }
    return if (allHaveDisplayOrder) {
        val allHaveEpisodeDisplayOrder = records.all { it.episodeDisplayOrder != null }
        records.sortedWith(
            compareBy<DownloadStore.Download> { it.seasonDisplayOrder ?: Int.MAX_VALUE }
                .thenBy {
                    if (allHaveEpisodeDisplayOrder) it.episodeDisplayOrder ?: Int.MAX_VALUE
                    else it.episode ?: Int.MAX_VALUE
                }
                .thenBy { it.createdAt },
        )
    } else {
        records.sortedWith(
            compareBy<DownloadStore.Download> { it.season ?: -1 }
                .thenBy { it.episode ?: 0 }
                .thenBy { it.createdAt },
        )
    }
}

object EpisodeQueues {

    /** Groups the provider's flat list by season, keeping each season's order. */
    fun build(
        apiName: String,
        url: String,
        title: String,
        posterUrl: String?,
        posterHeaders: Map<String, String>?,
        type: String,
        episodes: List<Episode>,
        fallbackSeason: Int? = null,
        /** Optional season ordering from the details UI's source display metadata. */
        seasonOrder: List<Int> = emptyList(),
        /** Maps provider season keys to the user-facing season numbers. */
        seasonDisplayNumbers: Map<Int, Int> = emptyMap(),
        /** True when the source exposes multiple seasons but cannot assign every episode. */
        seasonMappingUnavailable: Boolean = false,
    ): EpisodeQueue? {
        if (episodes.isEmpty()) return null
        val taggedSeasons = episodes.mapNotNull { it.season }.distinct()
        val hasMultipleSeasons = seasonOrder.distinct().size > 1 || taggedSeasons.size > 1
        val hasUnmappedEpisodes = fallbackSeason == null && episodes.any { it.season == null }
        val mappingUnavailable = seasonMappingUnavailable || (hasMultipleSeasons && hasUnmappedEpisodes)
        val grouped = ArrayList<Pair<Int?, MutableList<Episode>>>()
        if (mappingUnavailable) {
            // Do not split a queue into guessed seasons when even one episode has
            // no season key. Keep the provider's complete list/order as one queue.
            grouped += null to episodes.toMutableList()
        } else {
            for (episode in episodes) {
                val season = episode.season ?: fallbackSeason
                val bucket = grouped.firstOrNull { it.first == season }?.second
                if (bucket != null) bucket.add(episode) else grouped.add(season to mutableListOf(episode))
            }
        }
        // Match the details screen's season order and conservative within-season
        // episode sort so next/previous cannot disagree with the visible list.
        val orderedSeasonKeys = orderQueueSeasonKeys(grouped.map { it.first }, seasonOrder)
        val orderedGroups = orderedSeasonKeys.mapNotNull { season ->
            grouped.firstOrNull { it.first == season }
        }
        val seasonKeys = ArrayList<Int>()
        val flat = ArrayList<QueueEpisode>()
        orderedGroups.forEach { (season, eps) ->
            seasonKeys.add(season ?: -1)
            val orderedEpisodes = if (mappingUnavailable) eps else orderEpisodesWithinSeason(eps)
            orderedEpisodes.forEach { ep ->
                flat.add(
                    QueueEpisode(
                        season = season,
                        // Do not invent an episode number from list position. Unknown
                        // coordinates remain playable but must not create watched markers.
                        number = ep.episode,
                        name = ep.name?.takeIf { it.isNotBlank() },
                        data = ep.data,
                        posterUrl = ep.posterUrl,
                        index = flat.size,
                        // This value is consumed by the player overlay as a season label.
                        // It must never be the episode's index within that season.
                        seasonIndex = season?.let { seasonDisplayNumbers[it] ?: it }?.takeIf { it >= 0 },
                    ),
                )
            }
        }
        return EpisodeQueue(
            apiName = apiName,
            url = url,
            title = title,
            posterUrl = posterUrl,
            posterHeaders = posterHeaders,
            type = type,
            seasons = seasonKeys,
            episodes = flat,
        )
    }

    /** Rebuilds the queue from a freshly loaded details page. */
    fun fromResponse(response: LoadResponse): EpisodeQueue? {
        if (response.type == com.lagradost.cloudstream3.TvType.Movie ||
            response.type == com.lagradost.cloudstream3.TvType.AnimeMovie
        ) {
            return null
        }
        val episodesByDub = when (response) {
            is AnimeLoadResponse -> response.episodes.filterValues { it.isNotEmpty() }
            is TvSeriesLoadResponse ->
                if (response.episodes.isEmpty()) emptyMap() else mapOf(DubStatus.None to response.episodes)
            else -> return null
        }
        val rawSeasonNames = (response as? EpisodeResponse)?.seasonNames.orEmpty()
        val rawEpisodeSeasons = episodesByDub.values.flatten().mapNotNull { it.season }
        val rawSeasons = (rawEpisodeSeasons + rawSeasonNames.map { it.season }).distinct().let { list ->
            if (list.isEmpty() && episodesByDub.values.any { it.isNotEmpty() }) listOf(1) else list
        }
        val effectiveSeasonNames = com.kodastream.app.ui.details.effectiveSeasonNamesForPage(
            pageTitle = response.name,
            orderedSeasonKeys = rawSeasons,
            declaredSeasonNames = rawSeasonNames,
        )
        // Same ordering and same dub choice as the details page, so the player's
        // next/previous never disagrees with the season rail.
        val allSeasons = orderSeasonsForDisplay(
            rawEpisodeSeasons + effectiveSeasonNames.map { it.season },
            effectiveSeasonNames,
        )
        val chosenDub = com.kodastream.app.ui.details.preferredSeasonMappedOption(
            episodesByDub.keys.toList(), allSeasons, episodesByDub,
        )
        val selectedEpisodes = episodesByDub[chosenDub]?.takeIf { it.isNotEmpty() }
            ?: episodesByDub.values.firstOrNull { it.isNotEmpty() } ?: return null
        val mappingUnavailable = allSeasons.size > 1 && selectedEpisodes.any { it.season == null }
        val episodes = com.kodastream.app.ui.details.episodesForPlaybackQueue(
            options = episodesByDub.keys.toList(),
            orderedSeasons = allSeasons,
            episodesByOption = episodesByDub,
            currentOption = chosenDub,
            mappingUnavailable = mappingUnavailable,
        ).ifEmpty { selectedEpisodes }
        val seasonOrder = allSeasons
        return build(
            apiName = response.apiName,
            url = response.url,
            title = response.name,
            posterUrl = response.posterUrl,
            posterHeaders = response.posterHeaders,
            type = when (response) {
                is AnimeLoadResponse -> "anime"
                is TvSeriesLoadResponse -> "series"
                else -> "movie"
            },
            episodes = episodes,
            fallbackSeason = seasonOrder.singleOrNull()?.takeIf { !mappingUnavailable },
            seasonOrder = seasonOrder,
            seasonDisplayNumbers = com.kodastream.app.ui.details.seasonDisplayNumberMap(
                seasonOrder,
                effectiveSeasonNames,
            ),
            seasonMappingUnavailable = mappingUnavailable,
        )
    }

    /** The offline fallback: whatever episodes of this title are downloaded. */
    fun fromDownloads(
        apiName: String,
        url: String,
        title: String,
        posterUrl: String?,
        posterHeaders: Map<String, String>?,
        type: String,
        downloads: List<DownloadStore.Download>,
    ): EpisodeQueue? {
        val records = orderDownloadedRecords(
            downloads.filter {
                it.apiName == apiName && it.url == url &&
                    it.state == DownloadStore.STATE_DONE && it.fileUri != null &&
                    it.episode != null
            },
        )
        if (records.isEmpty()) return null
        val episodes = records.mapIndexed { index, record ->
            QueueEpisode(
                season = record.season ?: -1,
                number = checkNotNull(record.episode) { "Downloaded queue records require an episode number" },
                name = record.episodeTitle,
                // The offline queue must play the saved file, not the provider's
                // original stream data URL. Keep the URI aligned with PlayerArgs.data.
                data = record.fileUri.orEmpty(),
                posterUrl = posterUrl,
                index = index,
                // Only show an actual saved display label. A legacy provider season
                // key may be an opaque ID (for example 50), not a user-facing number.
                seasonIndex = record.seasonDisplayNumber,
            )
        }
        return EpisodeQueue(
            apiName = apiName,
            url = url,
            title = title,
            posterUrl = posterUrl,
            posterHeaders = posterHeaders,
            type = type,
            seasons = episodes.map { it.season ?: -1 }.distinct(),
            episodes = episodes,
            offlineOnly = true,
        )
    }
}
