package com.kodastream.app.data

import android.content.Context
import com.lagradost.cloudstream3.utils.DataStore.getKey
import com.lagradost.cloudstream3.utils.DataStore.setKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicLong

/**
 * What the user has watched, per episode and per movie - a separate store
 * from History, which keeps only one entry per title. Presence of a key
 * means watched; the timestamp keeps when.
 *
 * Keys follow "provider|details url|season|episode" (movies use -1/-1), so a
 * series can track every episode individually while History tracks the title.
 */
object WatchedStore {
    data class WatchedEntry(
        val key: String,
        val watchedAt: Long = 0L,
    )

    private const val STORE_KEY = "watched_items"

    private val _keys = MutableStateFlow<Set<String>?>(null)
    val keys: StateFlow<Set<String>?> = _keys.asStateFlow()

    /** Keeps original watched-at values in memory while the key set is observed. */
    private val _entries = MutableStateFlow<Map<String, WatchedEntry>?>(null)

    @Volatile
    private var loaded = false

    /** The watched keys. Loads from disk on the first call, then serves from memory. */
    @Synchronized
    fun current(context: Context): Set<String> {
        loadLocked(context)
        return _keys.value.orEmpty()
    }

    fun keyOf(apiName: String, url: String, season: Int?, episode: Int?): String =
        "$apiName|$url|${season ?: -1}|${episode ?: -1}"

    fun isWatched(context: Context, key: String): Boolean = current(context).contains(key)

    @Synchronized
    fun setAll(context: Context, keys: List<String>, watched: Boolean) {
        loadLocked(context)
        val existingTimestamps = _entries.value.orEmpty().mapValues { (_, entry) -> entry.watchedAt }
        val updatedTimestamps = updateWatchedTimestamps(
            existing = existingTimestamps,
            changedKeys = keys,
            watched = watched,
            now = System.currentTimeMillis(),
        )
        val updatedEntries = updatedTimestamps.mapValues { (key, timestamp) ->
            WatchedEntry(key = key, watchedAt = timestamp)
        }
        publish(context, updatedEntries)
    }

    /**
     * Marks one movie or episode as watched without confusing episode-level
     * state with completion of the whole title. History is a single entry per
     * title, so only a movie action (null season AND null episode) can mark the
     * entire History entry complete. Episode actions affect the per-episode
     * store and never erase progress for a different episode.
     */
    @Synchronized
    fun setWatched(
        context: Context,
        apiName: String,
        url: String,
        season: Int?,
        episode: Int?,
        resumeKey: String?,
        watched: Boolean,
    ) {
        setAll(context, listOf(keyOf(apiName, url, season, episode)), watched)
        val historyKey = "$apiName|$url"
        val isMovieItem = isMovieWatchItem(season, episode)

        if (isMovieItem) {
            HistoryStore.setCompleted(context, historyKey, watched)
            if (!watched) {
                HistoryStore.resetProgress(context, historyKey)
                resumeKey?.let { AppPrefs.setPosition(context, it, 0L) }
            }
            return
        }

        // A single watched episode is not proof that a series/anime is finished.
        if (watched) {
            HistoryStore.setCompleted(context, historyKey, false)
            return
        }

        HistoryStore.setCompleted(context, historyKey, false)
        val currentEntry = HistoryStore.current(context).firstOrNull { it.key == historyKey }
        // Do not clear the title-level resume point when unmarking an older
        // episode while another episode is currently in progress.
        if (currentEntry != null && resumeKey != null && currentEntry.resumeKey == resumeKey) {
            HistoryStore.resetProgress(context, historyKey)
        }
        resumeKey?.let { AppPrefs.setPosition(context, it, 0L) }
    }

    /** Must be called while holding this object's monitor. */
    private fun loadLocked(context: Context) {
        if (loaded) return
        val entries = context.getKey<List<WatchedEntry>>(STORE_KEY).orEmpty()
            .asSequence()
            .filter { it.key.isNotBlank() }
            .associateBy { it.key }
            .mapValues { (_, entry) -> entry }
        _entries.value = entries
        _keys.value = entries.keys.toSet()
        loaded = true
    }

    private fun publish(context: Context, entries: Map<String, WatchedEntry>) {
        _entries.value = entries
        _keys.value = entries.keys.toSet()
        // Persist an immutable snapshot, not a live map view.
        val snapshot = entries.values.toList()
        val revision = persistRevision.incrementAndGet()
        scope.launch {
            persistMutex.withLock {
                if (revision == persistRevision.get()) context.setKey(STORE_KEY, snapshot)
            }
        }
    }
}

/** Serialization stays off the main thread, the same as HistoryStore. */
private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
private val persistMutex = Mutex()
private val persistRevision = AtomicLong(0L)
