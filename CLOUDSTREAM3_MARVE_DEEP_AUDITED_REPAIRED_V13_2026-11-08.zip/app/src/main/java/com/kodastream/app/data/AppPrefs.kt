package com.kodastream.app.data

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.edit
import androidx.core.os.LocaleListCompat
import androidx.preference.PreferenceManager
import com.kodastream.app.R
import com.lagradost.cloudstream3.ui.settings.Globals.EMULATOR
import com.lagradost.cloudstream3.ui.settings.Globals.TV
import com.lagradost.cloudstream3.ui.settings.Globals.isLayout
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Small app settings that are not part of the theme. */
object AppPrefs {
    private const val PREFS = "kodastream_prefs"
    private const val KEY_PROVIDER = "selected_provider"
    private const val KEY_AUTO_UPDATE = "auto_update_extensions"
    private const val KEY_NAV_POSITION = "nav_position"
    private const val KEY_HOME_HERO_STYLE = "home_hero_style"
    private const val KEY_HOME_CATALOG_MODE = "home_catalog_mode"
    private const val KEY_WATCH_STATISTICS_ENABLED = "watch_statistics_enabled"
    private const val KEY_FIXED_NAVIGATION = "fixed_navigation_no_expansion"
    private const val KEY_NAV_DRAG_SWITCH_ENABLED = "nav_drag_switch_enabled"
    private const val KEY_NAV_BAR_STYLE = "nav_bar_style"
    private const val KEY_PLAYER_PROGRESS_STYLE = "player_progress_style"
    private const val KEY_PLAYER_SHOW_SOURCE = "player_show_source_control"
    private const val KEY_PLAYER_SHOW_LOCK = "player_show_lock_control"
    private const val KEY_PLAYER_SHOW_ROTATE = "player_show_rotate_control"
    private const val KEY_PLAYER_SHOW_RESIZE = "player_show_resize_control"
    private const val KEY_PLAYER_SHOW_SUBTITLE_OFFSET = "player_show_subtitle_offset_control"
    const val PLAYER_SHOW_SEEK_BUTTONS_KEY = "player_show_seek_buttons"
    private const val KEY_PLAYER_SHOW_SEEK_BUTTONS = PLAYER_SHOW_SEEK_BUTTONS_KEY
    private const val KEY_PLAYER_COMPACT_CONTROLS = "player_compact_controls"
    private const val KEY_PLAYER_GESTURE_MODE = "player_gesture_mode"
    private const val KEY_PLAYER_SHOW_TRACKS = "player_show_tracks_control"
    private const val KEY_SPEED = "playback_speed"
    private const val KEY_PAUSE_HISTORY = "pause_history"
    private const val KEY_DL_TREE = "download_tree_uri"
    private const val KEY_DL_WIFI = "download_wifi_only"
    private const val KEY_DL_MAX = "download_max_concurrent"
    private const val KEY_DL_SERVER = "download_last_server"
    private const val KEY_DL_FOLDERS_DONE = "download_folders_migrated"
    private const val KEY_EXTERNAL_MANAGER = "external_download_manager"
    private const val KEY_KEEP_SCREEN_ON = "keep_screen_on"
    private const val KEY_POSTER_SIZE = "poster_size_step"
    private const val KEY_SETUP_DONE = "setup_done"
    private const val KEY_APP_LANGUAGE = "app_language"
    private const val KEY_UPDATE_CHECK = "update_last_check"
    private const val KEY_UPDATE_SKIPPED = "update_skipped_version"
    private const val KEY_UPDATE_VERSION = "update_version"
    private const val KEY_UPDATE_URL = "update_url"
    private const val KEY_UPDATE_NOTES = "update_notes"
    private const val KEY_UPDATE_ETAG = "update_etag"
    private const val POSITION_PREFIX = "pos_"
    private const val DURATION_PREFIX = "dur_"

    const val NAV_SIDE = "side"
    const val NAV_BOTTOM = "bottom"
    const val NAV_BAR_CLOUD = "cloud"
    const val NAV_BAR_BUBBLE = "bubble"
    const val PLAYER_GESTURE_CLASSIC = "classic"
    const val PLAYER_GESTURE_MARVE = "marve"
    const val LANGUAGE_SYSTEM = "system"

    private val _navPosition = MutableStateFlow<String?>(null)
    private val _fixedNavigation = MutableStateFlow<Boolean?>(null)
    private val _navDragSwitchEnabled = MutableStateFlow<Boolean?>(null)
    private val _navBarStyle = MutableStateFlow<String?>(null)
    private val _watchStatisticsEnabled = MutableStateFlow<Boolean?>(null)

    /** The bar position, as a flow so the shell can switch layouts the moment it changes. */
    val navPosition: StateFlow<String?> = _navPosition.asStateFlow()

    /** Live geometry setting; changing it updates the navigation shell immediately. */
    val fixedNavigationFlow: StateFlow<Boolean?> = _fixedNavigation.asStateFlow()

    /** Bottom navigation presentation: the original CloudStream pill or the custom finger-following bubble. */
    val navBarStyle: StateFlow<String?> = _navBarStyle.asStateFlow()

    /** Where the navigation bar sits. Side (left) is the default. */
    fun navPosition(context: Context): String =
        _navPosition.value ?: run {
            val stored = prefs(context).getString(KEY_NAV_POSITION, null)
            val safeValue = stored.takeIf { it == NAV_SIDE || it == NAV_BOTTOM } ?: NAV_SIDE
            _navPosition.value = safeValue
            if (stored != safeValue) prefs(context).edit { putString(KEY_NAV_POSITION, safeValue) }
            safeValue
        }

    fun setNavPosition(context: Context, value: String) {
        val safeValue = value.takeIf { it == NAV_SIDE || it == NAV_BOTTOM } ?: NAV_SIDE
        _navPosition.value = safeValue
        prefs(context).edit { putString(KEY_NAV_POSITION, safeValue) }
    }

    /** Enable drag-based switching between top-level navigation sections. */
    val navDragSwitchEnabled: StateFlow<Boolean?> = _navDragSwitchEnabled.asStateFlow()

    fun navBarStyle(context: Context): String =
        _navBarStyle.value
            ?: prefs(context).getString(KEY_NAV_BAR_STYLE, null)
                ?.takeIf { it == NAV_BAR_CLOUD || it == NAV_BAR_BUBBLE }
                ?.also { _navBarStyle.value = it }
            ?: NAV_BAR_CLOUD

    fun setNavBarStyle(context: Context, value: String) {
        val safeValue = value.takeIf { it == NAV_BAR_CLOUD || it == NAV_BAR_BUBBLE } ?: NAV_BAR_CLOUD
        _navBarStyle.value = safeValue
        prefs(context).edit { putString(KEY_NAV_BAR_STYLE, safeValue) }
    }

    fun navDragSwitchEnabled(context: Context): Boolean =
        _navDragSwitchEnabled.value
            ?: prefs(context).getBoolean(KEY_NAV_DRAG_SWITCH_ENABLED, true)
                .also { _navDragSwitchEnabled.value = it }

    fun setNavDragSwitchEnabled(context: Context, enabled: Boolean) {
        _navDragSwitchEnabled.value = enabled
        prefs(context).edit { putBoolean(KEY_NAV_DRAG_SWITCH_ENABLED, enabled) }
    }

    /** "carousel", "cinematic" or "off"; unknown values are resolved by the caller. */
    fun homeHeroStyle(context: Context): String =
        prefs(context).getString(KEY_HOME_HERO_STYLE, null) ?: "carousel"

    fun setHomeHeroStyle(context: Context, value: String) {
        prefs(context).edit { putString(KEY_HOME_HERO_STYLE, value) }
    }

    /** The player's chosen speed, remembered between episodes. */
    fun playbackSpeed(context: Context): Float = prefs(context).getFloat(KEY_SPEED, 1f)

    fun setPlaybackSpeed(context: Context, value: Float) {
        prefs(context).edit { putFloat(KEY_SPEED, value) }
    }

    /**
     * Hold-to-speed-up lives in the port's default preferences, the file its
     * gesture helper reads. [ensureHoldToSpeedUp] seeds the default once, so a
     * later "off" choice is not overwritten.
     */
    fun holdToSpeedUp(context: Context): Boolean =
        playerPrefs(context).getBoolean(context.getString(R.string.speedup_key), true)

    fun setHoldToSpeedUp(context: Context, value: Boolean) {
        playerPrefs(context).edit { putBoolean(context.getString(R.string.speedup_key), value) }
    }

    fun ensureHoldToSpeedUp(context: Context) {
        val prefs = playerPrefs(context)
        val key = context.getString(R.string.speedup_key)
        if (!prefs.contains(key)) prefs.edit { putBoolean(key, true) }
    }

    private fun playerPrefs(context: Context) =
        PreferenceManager.getDefaultSharedPreferences(context)

    /** Layout for the final source-only "All" shelf: exactly one shelf or a 3-column grid. */
    fun homeCatalogMode(context: Context): String =
        prefs(context).getString(KEY_HOME_CATALOG_MODE, "grid")
            ?.takeIf { it == "grid" || it == "shelf" } ?: "grid"

    fun setHomeCatalogMode(context: Context, value: String) {
        prefs(context).edit { putString(KEY_HOME_CATALOG_MODE, if (value == "shelf") "shelf" else "grid") }
    }

    /** Fixed geometry keeps navigation items from expanding when the active section changes. */
    fun fixedNavigation(context: Context): Boolean =
        _fixedNavigation.value
            ?: prefs(context).getBoolean(KEY_FIXED_NAVIGATION, true).also { _fixedNavigation.value = it }

    fun setFixedNavigation(context: Context, value: Boolean) {
        _fixedNavigation.value = value
        prefs(context).edit { putBoolean(KEY_FIXED_NAVIGATION, value) }
    }

    /** Live switch so the player stops its watch-time observer immediately when statistics are disabled. */
    val watchStatisticsEnabledFlow: StateFlow<Boolean?> = _watchStatisticsEnabled.asStateFlow()

    fun watchStatisticsEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_WATCH_STATISTICS_ENABLED, true)
            .also { _watchStatisticsEnabled.value = it }

    fun setWatchStatisticsEnabled(context: Context, value: Boolean) {
        _watchStatisticsEnabled.value = value
        prefs(context).edit { putBoolean(KEY_WATCH_STATISTICS_ENABLED, value) }
    }

    /**
     * Top-level interaction profile. The detailed switches below remain stored
     * independently, so changing profile never destroys the user's preferences.
     * MARVE is the default to preserve the current player behaviour.
     */
    fun playerGestureMode(context: Context): String =
        prefs(context).getString(KEY_PLAYER_GESTURE_MODE, PLAYER_GESTURE_MARVE)
            ?.takeIf { it == PLAYER_GESTURE_CLASSIC || it == PLAYER_GESTURE_MARVE }
            ?: PLAYER_GESTURE_MARVE

    fun setPlayerGestureMode(context: Context, value: String) {
        val safeValue = value.takeIf { it == PLAYER_GESTURE_CLASSIC || it == PLAYER_GESTURE_MARVE }
            ?: PLAYER_GESTURE_MARVE
        prefs(context).edit { putString(KEY_PLAYER_GESTURE_MODE, safeValue) }
    }

    // Player gesture settings share the exact default preference file consumed by PlayerGestureHelper.
    fun playerVerticalSwipeEnabled(context: Context): Boolean =
        playerPrefs(context).getBoolean(context.getString(R.string.swipe_vertical_enabled_key), false)
    fun setPlayerVerticalSwipeEnabled(context: Context, value: Boolean) {
        playerPrefs(context).edit { putBoolean(context.getString(R.string.swipe_vertical_enabled_key), value) }
    }

    /** Allows the MARVE vertical brightness gesture to extend above the system 100% level. */
    fun playerExtraBrightnessEnabled(context: Context): Boolean =
        playerPrefs(context).getBoolean(context.getString(R.string.extra_brightness_key), false)
    fun setPlayerExtraBrightnessEnabled(context: Context, value: Boolean) {
        playerPrefs(context).edit { putBoolean(context.getString(R.string.extra_brightness_key), value) }
    }

    fun playerHorizontalSwipeEnabled(context: Context): Boolean =
        playerPrefs(context).getBoolean(context.getString(R.string.swipe_enabled_key), true)
    fun setPlayerHorizontalSwipeEnabled(context: Context, value: Boolean) {
        playerPrefs(context).edit { putBoolean(context.getString(R.string.swipe_enabled_key), value) }
    }

    fun playerDoubleTapEnabled(context: Context): Boolean =
        playerPrefs(context).getBoolean(context.getString(R.string.double_tap_enabled_key), !isLayout(TV or EMULATOR))
    fun setPlayerDoubleTapEnabled(context: Context, value: Boolean) {
        playerPrefs(context).edit { putBoolean(context.getString(R.string.double_tap_enabled_key), value) }
    }

    fun playerDoubleTapPauseEnabled(context: Context): Boolean =
        playerPrefs(context).getBoolean(context.getString(R.string.double_tap_pause_enabled_key), false)
    fun setPlayerDoubleTapPauseEnabled(context: Context, value: Boolean) {
        playerPrefs(context).edit { putBoolean(context.getString(R.string.double_tap_pause_enabled_key), value) }
    }

    fun playerSeekSeconds(context: Context): Int =
        normalizePlayerSeekSeconds(playerPrefs(context).getInt(context.getString(R.string.double_tap_seek_time_key), 10))
    fun setPlayerSeekSeconds(context: Context, seconds: Int) {
        playerPrefs(context).edit { putInt(context.getString(R.string.double_tap_seek_time_key), normalizePlayerSeekSeconds(seconds)) }
    }

    fun playerProgressStyle(context: Context): String =
        playerPrefs(context).getString(KEY_PLAYER_PROGRESS_STYLE, "standard")
            ?.takeIf { it in setOf("slim", "standard", "bold") } ?: "standard"
    fun setPlayerProgressStyle(context: Context, value: String) {
        playerPrefs(context).edit { putString(KEY_PLAYER_PROGRESS_STYLE, value.takeIf { it in setOf("slim", "standard", "bold") } ?: "standard") }
    }

    fun playerShowSourceControl(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_SOURCE, true)
    fun setPlayerShowSourceControl(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_SOURCE, value) } }
    fun playerShowLockControl(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_LOCK, true)
    fun setPlayerShowLockControl(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_LOCK, value) } }
    fun playerShowRotateControl(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_ROTATE, true)
    fun setPlayerShowRotateControl(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_ROTATE, value) } }
    fun playerShowResizeControl(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_RESIZE, true)
    fun setPlayerShowResizeControl(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_RESIZE, value) } }
    fun playerShowSubtitleOffsetControl(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_SUBTITLE_OFFSET, true)
    fun setPlayerShowSubtitleOffsetControl(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_SUBTITLE_OFFSET, value) } }
    fun playerShowTracksControl(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_TRACKS, true)
    fun setPlayerShowTracksControl(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_TRACKS, value) } }
    fun playerShowSeekButtons(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_SHOW_SEEK_BUTTONS, true)
    fun setPlayerShowSeekButtons(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_SHOW_SEEK_BUTTONS, value) } }
    fun playerCompactControls(context: Context): Boolean = playerPrefs(context).getBoolean(KEY_PLAYER_COMPACT_CONTROLS, true)
    fun setPlayerCompactControls(context: Context, value: Boolean) { playerPrefs(context).edit { putBoolean(KEY_PLAYER_COMPACT_CONTROLS, value) } }

    /** True when nothing new should be written to the watch history. Existing entries stay. */
    fun pauseHistory(context: Context): Boolean = prefs(context).getBoolean(KEY_PAUSE_HISTORY, false)

    fun setPauseHistory(context: Context, value: Boolean) {
        prefs(context).edit { putBoolean(KEY_PAUSE_HISTORY, value) }
    }

    // ---- Downloads ----

    /** The SAF tree the user picked, or null for the app's default folder. */
    fun downloadTreeUri(context: Context): String? = prefs(context).getString(KEY_DL_TREE, null)

    fun setDownloadTreeUri(context: Context, uri: String?) {
        prefs(context).edit { if (uri == null) remove(KEY_DL_TREE) else putString(KEY_DL_TREE, uri) }
    }

    fun downloadWifiOnly(context: Context): Boolean = prefs(context).getBoolean(KEY_DL_WIFI, false)

    fun setDownloadWifiOnly(context: Context, value: Boolean) {
        prefs(context).edit { putBoolean(KEY_DL_WIFI, value) }
    }

    fun downloadMaxConcurrent(context: Context): Int = prefs(context).getInt(KEY_DL_MAX, 2).coerceIn(1, 3)

    fun setDownloadMaxConcurrent(context: Context, value: Int) {
        prefs(context).edit { putInt(KEY_DL_MAX, value.coerceIn(1, 3)) }
    }

    /** True once the one-time move into per-title folders has run. */
    fun downloadsFolderMigrated(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DL_FOLDERS_DONE, false)

    fun setDownloadsFolderMigrated(context: Context, value: Boolean) {
        prefs(context).edit { putBoolean(KEY_DL_FOLDERS_DONE, value) }
    }

    /** Keep the screen awake while the player plays. On by default. */
    fun keepScreenOn(context: Context): Boolean = prefs(context).getBoolean(KEY_KEEP_SCREEN_ON, true)

    fun setKeepScreenOn(context: Context, value: Boolean) {
        prefs(context).edit { putBoolean(KEY_KEEP_SCREEN_ON, value) }
    }

    /** The server name last picked in the download card, preselected next time. */
    fun lastDownloadServer(context: Context): String? = prefs(context).getString(KEY_DL_SERVER, null)

    fun setLastDownloadServer(context: Context, value: String) {
        prefs(context).edit { putString(KEY_DL_SERVER, value) }
    }

    /** The poster size step shared by History and the Library grids. */
    fun posterSizeStep(context: Context): Int =
        posterStepOrFallback(prefs(context).getInt(KEY_POSTER_SIZE, POSTER_SIZE_DEFAULT_STEP))

    fun setPosterSizeStep(context: Context, step: Int) {
        prefs(context).edit { putInt(KEY_POSTER_SIZE, posterStepOrFallback(step)) }
    }

    /** Package name of the external download manager used last, if any. */
    fun externalDownloadManager(context: Context): String? =
        prefs(context).getString(KEY_EXTERNAL_MANAGER, null)

    fun setExternalDownloadManager(context: Context, packageName: String?) {
        prefs(context).edit { putString(KEY_EXTERNAL_MANAGER, packageName) }
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun selectedProvider(context: Context): String? = prefs(context).getString(KEY_PROVIDER, null)

    fun setSelectedProvider(context: Context, name: String?) {
        prefs(context).edit { if (name == null) remove(KEY_PROVIDER) else putString(KEY_PROVIDER, name) }
    }

    fun autoUpdate(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_UPDATE, true)

    fun setAutoUpdate(context: Context, value: Boolean) {
        prefs(context).edit { putBoolean(KEY_AUTO_UPDATE, value) }
    }

    /** Where playback stopped, in milliseconds. 0 when unknown. */
    fun position(context: Context, key: String): Long =
        readProgressValue(context, POSITION_PREFIX, key)

    fun setPosition(context: Context, key: String, positionMs: Long) {
        writeProgressValue(context, POSITION_PREFIX, key, positionMs)
    }

    /** The last known length of one episode, in milliseconds. 0 when unknown. */
    fun duration(context: Context, key: String): Long =
        readProgressValue(context, DURATION_PREFIX, key)

    fun setDuration(context: Context, key: String, durationMs: Long) {
        writeProgressValue(context, DURATION_PREFIX, key, durationMs)
    }

    /**
     * The SHA-256 identity avoids Java String.hashCode collisions between media.
     * A one-time migration reads the old hash key, moves its value to the new
     * key and removes the legacy key so it cannot be attributed to another title.
     */
    private fun readProgressValue(context: Context, prefix: String, mediaIdentity: String): Long {
        val store = prefs(context)
        val stableKey = progressPreferenceKey(prefix, mediaIdentity)
        val legacyKey = prefix + mediaIdentity.hashCode()
        if (store.contains(stableKey)) {
            val stableValue = runCatching { store.getLong(stableKey, 0L) }.getOrNull()
            if (stableValue != null) {
                // A leftover hash key is ambiguous and must never be reassigned to
                // another identity that happens to share the old 32-bit hash.
                if (store.contains(legacyKey)) store.edit { remove(legacyKey) }
                return stableValue.coerceAtLeast(0L)
            }
            // A value stored with the wrong primitive type is corrupted; remove
            // it rather than letting SharedPreferences throw on every playback.
            store.edit { remove(stableKey) }
        }

        if (!store.contains(legacyKey)) return 0L

        val legacyValue = runCatching { store.getLong(legacyKey, 0L) }.getOrNull()
        if (legacyValue == null) {
            store.edit { remove(legacyKey) }
            return 0L
        }
        store.edit {
            putLong(stableKey, legacyValue.coerceAtLeast(0L))
            remove(legacyKey)
        }
        return legacyValue.coerceAtLeast(0L)
    }

    private fun writeProgressValue(context: Context, prefix: String, mediaIdentity: String, value: Long) {
        val store = prefs(context)
        val stableKey = progressPreferenceKey(prefix, mediaIdentity)
        val legacyKey = prefix + mediaIdentity.hashCode()
        store.edit {
            putLong(stableKey, value.coerceAtLeast(0L))
            remove(legacyKey)
        }
    }

    // ---- First-run setup ----

    fun setupDone(context: Context): Boolean = prefs(context).getBoolean(KEY_SETUP_DONE, false)

    fun setSetupDone(context: Context, value: Boolean) {
        prefs(context).edit { putBoolean(KEY_SETUP_DONE, value) }
    }

    /** "system" or a BCP 47 language tag such as "en" / "ar". */
    fun appLanguage(context: Context): String =
        prefs(context).getString(KEY_APP_LANGUAGE, null) ?: LANGUAGE_SYSTEM

    fun setAppLanguage(context: Context, tag: String) {
        prefs(context).edit { putString(KEY_APP_LANGUAGE, tag) }
    }

    /** Applies the saved language; called from Application before any activity exists. */
    fun applyAppLanguage(context: Context) {
        val locales = appLanguage(context).takeIf { it != LANGUAGE_SYSTEM }
            ?.let { LocaleListCompat.forLanguageTags(it) }
            ?: LocaleListCompat.getEmptyLocaleList()
        if (AppCompatDelegate.getApplicationLocales() != locales) {
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }

    // ---- App updates ----

    /** When the GitHub release check last completed, in epoch millis. */
    fun lastUpdateCheck(context: Context): Long = prefs(context).getLong(KEY_UPDATE_CHECK, 0L)

    fun setLastUpdateCheck(context: Context, timeMs: Long) {
        prefs(context).edit { putLong(KEY_UPDATE_CHECK, timeMs) }
    }

    /** The version the user chose to stop being reminded about. */
    fun skippedUpdateVersion(context: Context): String? =
        prefs(context).getString(KEY_UPDATE_SKIPPED, null)

    fun setSkippedUpdateVersion(context: Context, version: String?) {
        prefs(context).edit {
            if (version == null) remove(KEY_UPDATE_SKIPPED) else putString(KEY_UPDATE_SKIPPED, version)
        }
    }

    /** The last official release found, offered again without a network call. */
    fun storedUpdate(context: Context): AppUpdate? {
        val prefs = prefs(context)
        val version = prefs.getString(KEY_UPDATE_VERSION, null) ?: return null
        val url = prefs.getString(KEY_UPDATE_URL, null) ?: return null
        return AppUpdate(version, prefs.getString(KEY_UPDATE_NOTES, null), url)
    }

    fun setStoredUpdate(context: Context, update: AppUpdate?) {
        prefs(context).edit {
            if (update == null) {
                remove(KEY_UPDATE_VERSION)
                remove(KEY_UPDATE_URL)
                remove(KEY_UPDATE_NOTES)
            } else {
                putString(KEY_UPDATE_VERSION, update.version)
                putString(KEY_UPDATE_URL, update.url)
                putString(KEY_UPDATE_NOTES, update.notes)
            }
        }
    }

    /** The GitHub ETag of the last successful release response. */
    fun updateEtag(context: Context): String? = prefs(context).getString(KEY_UPDATE_ETAG, null)

    fun setUpdateEtag(context: Context, etag: String?) {
        prefs(context).edit {
            if (etag == null) remove(KEY_UPDATE_ETAG) else putString(KEY_UPDATE_ETAG, etag)
        }
    }
}
