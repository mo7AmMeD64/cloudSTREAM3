package com.kodastream.app.data

/** Returns a finite download fraction in [0, 1], or -1 when the total is unknown. */
internal fun normalizedDownloadProgress(completed: Long, total: Long): Float {
    if (total <= 0L) return -1f
    return (completed.toDouble() / total.toDouble())
        .coerceIn(0.0, 1.0)
        .toFloat()
}
