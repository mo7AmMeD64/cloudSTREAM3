package com.kodastream.app.downloads

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.kodastream.app.R
import com.kodastream.app.data.AppPrefs
import com.kodastream.app.data.DownloadLocations
import com.kodastream.app.data.parseDownloadContentRange
import com.kodastream.app.data.isSupportedDownloadHttpStatus
import com.kodastream.app.data.DownloadStore
import com.kodastream.app.data.downloadPosterFileName
import com.kodastream.app.engine.Engine
import com.lagradost.cloudstream3.USER_AGENT
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.ensureActive
import okhttp3.Call
import okhttp3.Headers.Companion.toHeaders
import okhttp3.Response
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.time.Duration
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * The download engine: a small dataSync foreground service that keeps
 * running while the app is closed. Concurrency, Wi-Fi gating, pause/resume
 * (HTTP Range for direct files, segment index for HLS), retry with backoff,
 * AES-128 HLS support and progress notifications all live here. State is
 * persisted through [DownloadStore] after every step, so anything can be
 * interrupted - network drop, app kill, reboot - and continued later.
 */
class DownloadService : Service() {

    companion object {
        private const val CHANNEL_ID = "downloads"
        private const val NOTIFICATION_ID = 10

        const val ACTION_START = "com.kodastream.app.downloads.START"
        const val ACTION_PAUSE = "com.kodastream.app.downloads.PAUSE"
        const val ACTION_RESUME = "com.kodastream.app.downloads.RESUME"
        const val ACTION_CANCEL = "com.kodastream.app.downloads.CANCEL"
        const val ACTION_RETRY = "com.kodastream.app.downloads.RETRY"
        const val ACTION_PAUSE_ALL = "com.kodastream.app.downloads.PAUSE_ALL"
        const val ACTION_CANCEL_ALL = "com.kodastream.app.downloads.CANCEL_ALL"
        const val ACTION_DELETE_DOWNLOADS = "com.kodastream.app.downloads.DELETE_DOWNLOADS"
        const val ACTION_DELETE_ALL = "com.kodastream.app.downloads.DELETE_ALL"
        const val EXTRA_ID = "id"
        const val EXTRA_IDS = "ids"

        /** Kicks the service: starts anything queued and re-adopts interrupted work. */
        fun ensure(context: Context) = send(context, ACTION_START, null)
        fun pause(context: Context, id: String) = send(context, ACTION_PAUSE, id)
        fun resume(context: Context, id: String) = send(context, ACTION_RESUME, id)
        fun cancel(context: Context, id: String) = send(context, ACTION_CANCEL, id)
        /** Removes one or more records only after every associated writer has stopped. */
        fun delete(context: Context, ids: Collection<String>) {
            if (ids.isEmpty()) return
            val intent = Intent(context, DownloadService::class.java)
                .setAction(ACTION_DELETE_DOWNLOADS)
                .putStringArrayListExtra(EXTRA_IDS, ArrayList(ids.distinct()))
            start(context, intent)
        }
        /** Removes all download records (including completed files) safely via the service. */
        fun deleteAll(context: Context) = send(context, ACTION_DELETE_ALL, null)
        fun retry(context: Context, id: String) = send(context, ACTION_RETRY, id)

        private fun send(context: Context, action: String, id: String?) {
            val intent = Intent(context, DownloadService::class.java).setAction(action)
            if (id != null) intent.putExtra(EXTRA_ID, id)
            start(context, intent)
        }

        private fun start(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }

    /**
     * Keeps every blocking OkHttp call attached to its download coroutine.
     * Cancelling a Job alone does not interrupt Call.execute()/body.read();
     * Call.cancel() is required to close the active socket promptly.
     */
    private class ActiveDownloadTask(val id: String) {
        @Volatile var job: Job? = null
        @Volatile var wifiStopRequested: Boolean = false
        val calls: MutableSet<Call> = ConcurrentHashMap.newKeySet()
        val outputUris: MutableSet<String> = ConcurrentHashMap.newKeySet()
        val folderUris: MutableSet<String> = ConcurrentHashMap.newKeySet()

        fun cancel() {
            job?.cancel(CancellationException("Download stopped by user"))
            calls.toList().forEach { call -> runCatching { call.cancel() } }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = ConcurrentHashMap<String, ActiveDownloadTask>()
    private val pumpLock = Any()
    private val pendingOperations = AtomicInteger(0)
    @Volatile private var timedOut = false
    private lateinit var notifications: NotificationManager
    private var connectivityManager: ConnectivityManager? = null
    private var connectivityCallback: ConnectivityManager.NetworkCallback? = null

    /**
     * The same client the player would play this link through: the engine's
     * base client plus the provider's own URL-signing interceptor. A bare
     * client gets 403s on providers that sign their video requests.
     */
    private fun clientFor(record: DownloadStore.Download): OkHttpClient {
        val api = Engine.provider(record.apiName)
        val link = ExtractorLink(
            source = record.apiName,
            name = record.linkName,
            url = record.linkUrl,
            referer = record.headers["referer"] ?: "",
            quality = record.quality,
            headers = record.headers,
            type = if (record.isHls) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO,
        )
        return app.baseClient.newBuilder()
            .apply {
                api?.getVideoInterceptor(link)?.let { addInterceptor(it) }
                connectTimeout(Duration.ofSeconds(30))
                readTimeout(Duration.ofSeconds(60))
            }
            .build()
    }

    /** Providers sometimes hand out header maps okhttp refuses; clean them. */
    private fun safeHeaders(headers: Map<String, String>): Map<String, String> =
        headers
            .filterKeys { it.isNotBlank() && !it.contains(':') }
            .mapValues { (_, value) -> value.replace(Regex("[\\r\\n]"), "") }

    override fun onCreate() {
        super.onCreate()
        notifications = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.download_notification_channel),
            NotificationManager.IMPORTANCE_LOW,
        )
        notifications.createNotificationChannel(channel)
        registerConnectivityCallback()
    }

    /** Re-evaluates queued work whenever the default network or its capabilities change. */
    private fun registerConnectivityCallback() {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = scheduleNetworkPump()
            override fun onLost(network: Network) = scheduleNetworkPump()
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) =
                scheduleNetworkPump()
        }
        try {
            manager.registerDefaultNetworkCallback(callback)
            connectivityManager = manager
            connectivityCallback = callback
        } catch (_: Exception) {
            // The normal pump still works when Android/vendor restrictions prevent callback registration.
        }
    }

    private fun scheduleNetworkPump() {
        scope.launch { pump() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Every entry point must promote the service to foreground fast.
        promote()
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_PAUSE -> id?.let(::pauseDownload)

            ACTION_RESUME -> {
                id?.let {
                    DownloadStore.update(this, it) { d ->
                        d.copy(state = DownloadStore.STATE_QUEUED, error = null)
                    }
                }
                pump()
            }

            ACTION_CANCEL -> id?.let(::cancelDownload)
            ACTION_DELETE_DOWNLOADS -> intent?.getStringArrayListExtra(EXTRA_IDS)?.let { ids ->
                removeDownloads(ids.toSet())
            }
            ACTION_DELETE_ALL -> deleteAllDownloads()

            ACTION_RETRY -> {
                id?.let {
                    DownloadStore.update(this, it) { d ->
                        d.copy(state = DownloadStore.STATE_QUEUED, error = null)
                    }
                }
                pump()
            }

            ACTION_PAUSE_ALL -> pauseAllDownloads()
            ACTION_CANCEL_ALL -> cancelAllDownloads()

            // START and a sticky restart both fall through to the pump, which
            // re-adopts records left "downloading" by a killed service.
            else -> pump()
        }
        return START_STICKY
    }

    /**
     * Android 15+ limits dataSync foreground services to six hours per 24-hour
     * period for apps targeting API 35+. Stop promptly when the system invokes
     * this callback, but persist active work as queued so it can resume later.
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        synchronized(pumpLock) {
            timedOut = true
            val tasks = active.values.toList()
            // Change the persisted state before closing sockets. A worker that
            // wakes during cancellation will then fail checkAlive() as expected.
            tasks.forEach { task ->
                DownloadStore.update(this, task.id) { download ->
                    if (download.state == DownloadStore.STATE_DOWNLOADING) {
                        download.copy(state = DownloadStore.STATE_QUEUED, error = null)
                    } else download
                }
            }
            tasks.forEach(ActiveDownloadTask::cancel)
        }
        // Do not wait for blocking network workers here: Android allows only a
        // few seconds after this callback before it raises a fatal exception.
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        // A service teardown must close sockets too; cancelling the parent scope
        // alone does not interrupt a blocking OkHttp Call.execute()/body.read().
        connectivityCallback?.let { callback ->
            runCatching { connectivityManager?.unregisterNetworkCallback(callback) }
        }
        connectivityCallback = null
        connectivityManager = null
        active.values.toList().forEach(ActiveDownloadTask::cancel)
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun promote() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /** Starts queued work up to the concurrency limit, then stops when idle. */
    private fun pump(): Unit = synchronized(pumpLock) {
        // Worker finally blocks and network callbacks can race with onTimeout.
        // Once timed out, no queued work may be launched again by this instance.
        if (timedOut) return@synchronized

        // A service restart adopts records stuck mid-download. An in-memory
        // task remains the owner until its finally block has completed.
        DownloadStore.current(this)
            .filter { it.state == DownloadStore.STATE_DOWNLOADING && !active.containsKey(it.id) }
            .forEach { DownloadStore.update(this, it.id) { d -> d.copy(state = DownloadStore.STATE_QUEUED) } }

        val wifiOnly = AppPrefs.downloadWifiOnly(this)
        val max = AppPrefs.downloadMaxConcurrent(this)
        val onWifi = isOnWifi()

        // Wi-Fi-only is a runtime policy, not merely a start-time check. If the
        // default network changes to cellular while downloads are active, stop
        // their sockets and requeue them; they will resume when Wi-Fi returns.
        if (wifiOnly && !onWifi) {
            val tasksToRequeue = active.values.filter { task ->
                if (task.wifiStopRequested) false else {
                    task.wifiStopRequested = true
                    true
                }
            }
            if (tasksToRequeue.isNotEmpty()) {
                launchPendingOperation(
                    beforeStart = {
                        tasksToRequeue.forEach { task ->
                            DownloadStore.update(this, task.id) { d ->
                                if (d.state == DownloadStore.STATE_QUEUED || d.state == DownloadStore.STATE_DOWNLOADING) {
                                    d.copy(state = DownloadStore.STATE_QUEUED)
                                } else d
                            }
                        }
                    },
                    onStart = { tasksToRequeue.forEach(ActiveDownloadTask::cancel) },
                ) {
                    tasksToRequeue.mapNotNull { it.job }.joinAll()
                    // A worker may have passed its initial DOWNLOADING write just
                    // before cancellation; normalize only that transient state.
                    tasksToRequeue.forEach { task ->
                        DownloadStore.update(this@DownloadService, task.id) { d ->
                            if (d.state == DownloadStore.STATE_DOWNLOADING) d.copy(state = DownloadStore.STATE_QUEUED) else d
                        }
                    }
                    DownloadStore.flush(this@DownloadService)
                }
            }
        }

        DownloadStore.current(this)
            .filter { it.state == DownloadStore.STATE_QUEUED }
            .takeWhile { active.size < max && (!wifiOnly || onWifi) }
            .forEach { download ->
                val task = ActiveDownloadTask(download.id)
                val job = scope.launch(start = CoroutineStart.LAZY) {
                    try {
                        runDownload(download.id, task)
                    } catch (e: CancellationException) {
                        // Pause/cancel is an expected state transition, not a failure.
                        throw e
                    } catch (t: Throwable) {
                        DownloadStore.update(this@DownloadService, download.id) { d ->
                            if (d.state == DownloadStore.STATE_DOWNLOADING) {
                                d.copy(state = DownloadStore.STATE_FAILED, error = t.message)
                            } else d
                        }
                    } finally {
                        active.remove(download.id, task)
                        updateNotification()
                        pump()
                    }
                }
                task.job = job
                if (active.putIfAbsent(download.id, task) == null) {
                    job.start()
                } else {
                    job.cancel()
                }
            }

        updateNotification()
        if (active.isEmpty() && pendingOperations.get() == 0) {
            val anyQueued = DownloadStore.current(this).any { it.state == DownloadStore.STATE_QUEUED }
            if (!anyQueued) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    /** Keeps the foreground service alive while cancellation cleanup is pending. */
    private fun launchPendingOperation(
        beforeStart: () -> Unit = {},
        onStart: () -> Unit = {},
        block: suspend () -> Unit,
    ) {
        // Reserve before changing state/removing records so a worker's finally/pump
        // cannot stop the service in the gap. Then perform the synchronous state
        // transition and close sockets before starting the join/cleanup coroutine.
        pendingOperations.incrementAndGet()
        runCatching(beforeStart)
        runCatching(onStart)
        scope.launch {
            try {
                block()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                // A failed cleanup is reflected by the remaining file/store state;
                // it must not crash the foreground service.
            } finally {
                pendingOperations.decrementAndGet()
                updateNotification()
                pump()
            }
        }
    }

    private fun pauseDownload(id: String) {
        synchronized(pumpLock) {
            val record = DownloadStore.find(this, id) ?: return
            if (record.state != DownloadStore.STATE_QUEUED && record.state != DownloadStore.STATE_DOWNLOADING) return
            val task = active[id]
            if (task == null) {
                // pumpLock prevents a queued worker from being registered between
                // the lookup and this state change.
                DownloadStore.update(this, id) { d ->
                    if (d.state == DownloadStore.STATE_QUEUED || d.state == DownloadStore.STATE_DOWNLOADING) {
                        d.copy(state = DownloadStore.STATE_PAUSED)
                    } else d
                }
                updateNotification()
                pump()
                return
            }
            launchPendingOperation(
                beforeStart = {
                    DownloadStore.update(this, id) { d ->
                        if (d.state == DownloadStore.STATE_QUEUED || d.state == DownloadStore.STATE_DOWNLOADING) {
                            d.copy(state = DownloadStore.STATE_PAUSED)
                        } else d
                    }
                },
                onStart = task::cancel,
            ) {
                task.job?.join()
                // Preserve a quick Resume tap: only normalize a still-running state.
                DownloadStore.update(this@DownloadService, id) { d ->
                    if (d.state == DownloadStore.STATE_DOWNLOADING) d.copy(state = DownloadStore.STATE_PAUSED) else d
                }
                DownloadStore.flush(this@DownloadService)
            }
        }
    }

    private fun pauseAllDownloads() {
        synchronized(pumpLock) {
            val pausableIds = DownloadStore.current(this)
                .filter { it.state == DownloadStore.STATE_QUEUED || it.state == DownloadStore.STATE_DOWNLOADING }
                .mapTo(linkedSetOf()) { it.id }
            if (pausableIds.isEmpty()) {
                updateNotification()
                pump()
                return
            }
            val tasks = pausableIds.mapNotNull { active[it] }
            launchPendingOperation(
                beforeStart = {
                    pausableIds.forEach { id ->
                        DownloadStore.update(this, id) { d ->
                            if (d.state == DownloadStore.STATE_QUEUED || d.state == DownloadStore.STATE_DOWNLOADING) {
                                d.copy(state = DownloadStore.STATE_PAUSED)
                            } else d
                        }
                    }
                },
                onStart = { tasks.forEach(ActiveDownloadTask::cancel) },
            ) {
                tasks.mapNotNull { it.job }.joinAll()
                // A worker may have crossed its initial synchronous state update
                // just before cancellation. Normalize only a still-downloading row;
                // a fast Resume tap (QUEUED) must remain intact.
                pausableIds.forEach { id ->
                    DownloadStore.update(this@DownloadService, id) { d ->
                        if (d.state == DownloadStore.STATE_DOWNLOADING) d.copy(state = DownloadStore.STATE_PAUSED) else d
                    }
                }
                DownloadStore.flush(this@DownloadService)
            }
        }
    }

    private fun cancelDownload(id: String) = removeDownloads(setOf(id))

    private fun cancelAllDownloads() {
        val ids = DownloadStore.current(this)
            .filter { it.state != DownloadStore.STATE_DONE }
            .mapTo(linkedSetOf()) { it.id }
        removeDownloads(ids)
    }

    private fun deleteAllDownloads() {
        val ids = DownloadStore.current(this).mapTo(linkedSetOf()) { it.id }
        removeDownloads(ids)
    }

    /**
     * The one removal path for single cancel, bulk cancel and UI deletion.
     * Records disappear first; active network calls are cancelled synchronously,
     * then writers are joined before any file or now-empty title folder is removed.
     */
    private fun removeDownloads(ids: Set<String>) {
        synchronized(pumpLock) {
            if (ids.isEmpty()) {
                updateNotification()
                pump()
                return
            }
            val records = DownloadStore.current(this).filter { it.id in ids }
            if (records.isEmpty()) {
                updateNotification()
                pump()
                return
            }
            val matchedIds = records.mapTo(linkedSetOf()) { it.id }
            val tasks = matchedIds.mapNotNull { active[it] }
            launchPendingOperation(
                // Reserve pendingOperations *before* removing records. Otherwise a
                // worker could observe the missing record, finish, and stop the service
                // in the tiny gap before the cleanup job is registered.
                beforeStart = { DownloadStore.removeAll(this, matchedIds) },
                onStart = { tasks.forEach(ActiveDownloadTask::cancel) },
            ) {
                tasks.mapNotNull { it.job }.joinAll()
                DownloadStore.flush(this@DownloadService)
                cleanupCancelledFiles(records, tasks)
                DownloadStore.flush(this@DownloadService)
            }
        }
    }

    private fun cleanupCancelledFiles(
        records: List<DownloadStore.Download>,
        tasks: List<ActiveDownloadTask>,
    ) {
        val files = buildSet {
            records.forEach { record ->
                record.fileUri?.let(::add)
                record.subtitleUri?.let(::add)
                record.posterUri?.let(::add)
            }
            tasks.forEach { addAll(it.outputUris) }
        }
        files.forEach { DownloadLocations.delete(this, it) }
        val folders = buildSet {
            records.mapNotNullTo(this) { it.folderUri }
            tasks.forEach { addAll(it.folderUris) }
        }
        folders.forEach { DownloadLocations.deleteFolderIfEmpty(this, it) }
    }

    private suspend fun runDownload(id: String, task: ActiveDownloadTask) {
        val record = DownloadStore.find(this, id) ?: return
        DownloadStore.update(this, id) { it.copy(state = DownloadStore.STATE_DOWNLOADING, error = null) }

        // One folder per title: resolved once (reusing a sibling episode's
        // folder when there is one) and kept on the record from then on.
        DownloadStore.find(this, id)?.let { current ->
            if (current.folderUri == null) {
                DownloadLocations.resolveFolder(this, current)?.let(task.folderUris::add)
            }
        }

        // Every blocking HTTP call is registered on this task, allowing a user
        // pause/cancel action to close the socket before waiting for this worker.
        // Transient failures retry quietly; the user only sees "failed" after
        // several attempts. State changes made meanwhile end the run.
        var attempt = 0
        while (true) {
            try {
                coroutineScope {
                    if (record.isHls) downloadHls(id, task)
                    else downloadDirect(id, task)
                }
                currentCoroutineContext().ensureActive()
                if (record.subUrl != null && DownloadStore.find(this, id)?.subtitleUri == null) {
                    downloadSubtitle(id, task)
                }
                currentCoroutineContext().ensureActive()
                if (record.posterUrl != null && DownloadStore.find(this, id)?.posterUri == null) {
                    downloadPoster(id, task)
                }
                currentCoroutineContext().ensureActive()
                DownloadStore.update(this, id) { d ->
                    if (d.state == DownloadStore.STATE_DOWNLOADING) d.copy(state = DownloadStore.STATE_DONE, error = null) else d
                }
                updateNotification()
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotEnoughSpaceException) {
                DownloadStore.update(this, id) { d ->
                    if (d.state == DownloadStore.STATE_DOWNLOADING) {
                        d.copy(state = DownloadStore.STATE_FAILED, error = getString(R.string.download_error_space))
                    } else d
                }
                updateNotification()
                return
            } catch (t: Throwable) {
                // An OkHttp cancellation can surface as IOException. Convert it
                // back into coroutine cancellation before considering a retry.
                currentCoroutineContext().ensureActive()
                if (DownloadStore.find(this, id)?.state != DownloadStore.STATE_DOWNLOADING) {
                    throw CancellationException("Download no longer active")
                }
                attempt++
                if (attempt >= 5) {
                    DownloadStore.update(this, id) { d ->
                        d.copy(state = DownloadStore.STATE_FAILED, error = t.message ?: t.javaClass.simpleName)
                    }
                    updateNotification()
                    return
                }
                delay(5_000)
                // Re-read: the user may have paused or cancelled meanwhile.
                if (DownloadStore.find(this, id)?.state != DownloadStore.STATE_DOWNLOADING) return
            }
        }
    }

    private class NotEnoughSpaceException : IOException("Not enough free space")

    private fun checkAlive(id: String, task: ActiveDownloadTask) {
        if (task.job?.isActive != true) throw CancellationException("download stopped")
        if (DownloadStore.find(this, id)?.state != DownloadStore.STATE_DOWNLOADING) {
            throw CancellationException("download no longer active")
        }
    }

    /** Holds the Call until its entire response body has been consumed. */
    private fun <T> withTrackedResponse(
        id: String,
        task: ActiveDownloadTask,
        record: DownloadStore.Download,
        request: Request,
        consume: (Response) -> T,
    ): T {
        val call = clientFor(record).newCall(request)
        task.calls.add(call)
        try {
            checkAlive(id, task)
            return call.execute().use(consume)
        } finally {
            task.calls.remove(call)
        }
    }

    /** One file of bytes: streams to the target and resumes with HTTP Range. */
    private fun downloadDirect(id: String, task: ActiveDownloadTask) {
        val record = DownloadStore.find(this, id) ?: return
        checkAlive(id, task)
        // Progress metadata is throttled to avoid writing to DataStore on every
        // buffer. After a fast interruption the file may contain bytes while
        // receivedBytes is still zero; use the actual target length instead.
        // If a provider cannot report a positive length, restart safely rather
        // than append from an unknown offset and risk corrupting the output.
        val existingUri = record.fileUri?.takeIf { DownloadLocations.exists(this, it) }
        val existingLength = existingUri?.let { DownloadLocations.fileLength(this, it) } ?: 0L
        val resume = existingUri != null && existingLength > 0L
        val targetRecord = if (resume) record.copy(fileUri = existingUri) else record
        val uri = DownloadLocations.ensureTarget(this, targetRecord, fresh = !resume)
            ?: throw IOException("Cannot create the target file")
        task.outputUris.add(uri)
        val startOffset = if (resume) DownloadLocations.fileLength(this, uri) else 0L

        val headers = safeHeaders(record.headers)
        val request = Request.Builder()
            .url(record.linkUrl)
            .headers(headers.toHeaders())
            .apply {
                if (headers.keys.none { it.equals("user-agent", ignoreCase = true) }) {
                    header("User-Agent", USER_AGENT)
                }
                if (startOffset > 0) header("Range", "bytes=$startOffset-")
            }
            .build()

        withTrackedResponse(id, task, record, request) { response ->
            // A media-file GET is complete only for a full 200 response or a
            // validated 206 range. Other 2xx codes (notably 204 No Content)
            // must never turn an empty/partial target into a DONE download.
            if (!isSupportedDownloadHttpStatus(response.code)) {
                throw IOException("Unsupported HTTP ${response.code} for file download")
            }
            val contentLength = response.body?.contentLength() ?: -1L
            val partial = response.code == 206
            // A 206 response is only safe to append when its Content-Range agrees
            // with the requested offset, body length and representation length.
            // Without this check a proxy/provider can return a different or
            // truncated range and the partial file may be reported as complete.
            val validatedRange = if (partial) {
                parseDownloadContentRange(
                    header = response.header("Content-Range"),
                    requestedOffset = startOffset,
                    contentLength = contentLength.takeIf { it >= 0L },
                ) ?: throw IOException("Invalid or incomplete Content-Range response")
            } else null
            // Some providers ignore Range and return the entire file with HTTP 200.
            // Appending that body would silently corrupt the video, so restart from
            // byte zero and truncate the partial target in that case.
            val actualStartOffset = validatedRange?.start ?: 0L
            val total = when {
                validatedRange != null -> validatedRange.totalBytes
                contentLength >= 0 -> contentLength
                record.totalBytes > 0 -> record.totalBytes
                else -> 0L
            }

            // Enough room? When the size is unknown, demand a 100MB cushion.
            val free = DownloadLocations.freeBytes(this)
            val remaining = if (total > 0) (total - actualStartOffset).coerceAtLeast(0L) else 100L * 1024 * 1024
            if (free in 0 until remaining) throw NotEnoughSpaceException()

            DownloadStore.update(this, id) { d ->
                d.copy(fileUri = uri, receivedBytes = actualStartOffset, totalBytes = total)
            }

            val input = response.body?.byteStream() ?: throw IOException("Empty body")
            var received = actualStartOffset
            var lastPublish = 0L
            DownloadLocations.openOutput(this, uri, append = actualStartOffset > 0).use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    checkAlive(id, task)
                    val read = input.read(buffer)
                    if (read < 0) break
                    output.write(buffer, 0, read)
                    received += read
                    val now = System.currentTimeMillis()
                    if (now - lastPublish > 900) {
                        lastPublish = now
                        DownloadStore.update(this, id) { d ->
                            d.copy(receivedBytes = received, totalBytes = total)
                        }
                        updateNotification()
                    }
                }
                output.flush()
            }
            if (validatedRange != null && received != validatedRange.totalBytes) {
                throw IOException("Incomplete range body: received $received of ${validatedRange.totalBytes} bytes")
            }
            DownloadStore.update(this, id) { d -> d.copy(receivedBytes = received, totalBytes = total) }
        }
    }

    /** An HLS stream: fetch the selected media playlist and append decrypted segments. */
    private fun downloadHls(id: String, task: ActiveDownloadTask) {
        val record = DownloadStore.find(this, id) ?: return
        checkAlive(id, task)
        val resume = record.hlsSegment > 0
        val uri = DownloadLocations.ensureTarget(this, record, fresh = !resume)
            ?: throw IOException("Cannot create the target file")
        task.outputUris.add(uri)

        val master = fetchText(id, task, record.linkUrl, record)
        // Use the final URL after HTTP redirects as the playlist base. Providers
        // often move manifests to CDN paths where relative segment URLs differ.
        var mediaPlaylistUrl = master.finalUrl
        var text = master.text
        HlsPlaylistParser.selectHighestBandwidthVariant(master.finalUrl, master.text)?.let { variantUrl ->
            // Segment and key paths are relative to the selected media playlist,
            // not to the master playlist that referenced it.
            val media = fetchText(id, task, variantUrl, record)
            mediaPlaylistUrl = media.finalUrl
            text = media.text
        }
        val playlist = HlsPlaylistParser.parseMediaPlaylist(mediaPlaylistUrl, text)
        val segments = playlist.segments

        if (DownloadLocations.freeBytes(this) in 0 until 50L * 1024 * 1024) throw NotEnoughSpaceException()

        DownloadStore.update(this, id) { d -> d.copy(fileUri = uri, hlsTotal = segments.size) }

        var index = if (resume) record.hlsSegment else 0
        DownloadLocations.openOutput(this, uri, append = resume).use { output ->
            while (index < segments.size) {
                checkAlive(id, task)
                val segment = segments[index]
                var bytes = fetchBytes(id, task, segment.url, record)
                segment.key?.let { key ->
                    val keyBytes = fetchBytes(id, task, key.url, record)
                    bytes = HlsPlaylistParser.decryptAes128Segment(
                        encryptedBytes = bytes,
                        keyBytes = keyBytes,
                        explicitIvHex = key.ivHex,
                        mediaSequence = playlist.mediaSequence + index,
                    )
                }
                checkAlive(id, task)
                output.write(bytes)
                index++
                DownloadStore.update(this, id) { d ->
                    d.copy(hlsSegment = index, receivedBytes = d.receivedBytes + bytes.size)
                }
                updateNotification()
            }
            output.flush()
        }
    }

    /** Saves the provider's subtitle beside the video, same folder, same name. */
    private fun downloadSubtitle(id: String, task: ActiveDownloadTask) {
        val record = DownloadStore.find(this, id) ?: return
        try {
            val subUrl = record.subUrl ?: return
            val bytes = fetchBytes(id, task, subUrl, record)
            val ext = subUrl.substringBefore('?').substringAfterLast('.', "").lowercase()
            val safeExt = if (ext in setOf("srt", "ass", "ssa", "vtt", "ttml")) ext else "vtt"
            val mime = when (safeExt) {
                "srt" -> "application/x-subrip"
                "ass", "ssa" -> "text/x-ssa"
                "ttml" -> "application/ttml+xml"
                else -> "text/vtt"
            }
            // "<video base>.<language>.<ext>", next to its video.
            val langSuffix = record.subLang
                ?.replace(Regex("[^A-Za-z0-9]"), "")
                ?.lowercase()
                ?.take(8)
                ?.ifBlank { null }
                ?: "sub"
            val subName = record.fileName.substringBeforeLast('.') + "." + langSuffix + "." + safeExt
            val folder = record.folderUri ?: DownloadLocations.resolveFolder(this, record) ?: return

            checkAlive(id, task)
            val uri: String? = if (folder.startsWith("content://")) {
                // Track the document before opening its stream so cancellation
                // cleanup can remove even a partially written subtitle.
                DownloadLocations.createFileInFolder(this, folder, subName, mime)?.also { created ->
                    task.outputUris.add(created)
                    checkAlive(id, task)
                    DownloadLocations.openOutput(this, created, append = false).use { output ->
                        checkAlive(id, task)
                        output.write(bytes)
                        output.flush()
                    }
                }
            } else {
                val folderPath = Uri.parse(folder).path?.takeIf { it.isNotBlank() }
                    ?: throw IOException("Invalid local subtitle folder URI")
                val dir = File(folderPath)
                if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create subtitle folder")
                val file = File(dir, subName)
                file.delete()
                val created = Uri.fromFile(file).toString()
                task.outputUris.add(created)
                checkAlive(id, task)
                file.outputStream().use { output ->
                    output.write(bytes)
                    output.flush()
                }
                created
            }
            if (uri != null) {
                checkAlive(id, task)
                DownloadStore.update(this, id) { it.copy(subtitleUri = uri) }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            // A missing subtitle never fails the video download.
        }
    }

    private fun downloadPoster(id: String, task: ActiveDownloadTask) {
        val record = DownloadStore.find(this, id) ?: return
        try {
            val bytes = fetchBytes(id, task, record.posterUrl ?: return, record)
            // Thumbnails live in the app's own storage; the user's download
            // folder holds only video files.
            val dir = File(filesDir, "download_posters").apply { mkdirs() }
            val file = File(dir, downloadPosterFileName(record.id))
            val posterUri = Uri.fromFile(file).toString()
            task.outputUris.add(posterUri)
            checkAlive(id, task)
            file.writeBytes(bytes)
            checkAlive(id, task)
            DownloadStore.update(this, id) { it.copy(posterUri = posterUri) }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
        }
    }

    // ---- small helpers ----

    private fun requestFor(url: String, headers: Map<String, String>): Request =
        Request.Builder()
            .url(url)
            .headers(safeHeaders(headers).toHeaders())
            .apply {
                if (headers.keys.none { it.equals("user-agent", ignoreCase = true) }) {
                    header("User-Agent", USER_AGENT)
                }
            }
            .build()

    private data class FetchedText(val text: String, val finalUrl: String)

    private fun fetchText(
        id: String,
        task: ActiveDownloadTask,
        url: String,
        record: DownloadStore.Download,
    ): FetchedText = withTrackedResponse(id, task, record, requestFor(url, record.headers)) { response ->
        if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
        FetchedText(
            text = response.body?.string() ?: throw IOException("Empty body"),
            finalUrl = response.request.url.toString(),
        )
    }

    private fun fetchBytes(
        id: String,
        task: ActiveDownloadTask,
        url: String,
        record: DownloadStore.Download,
    ): ByteArray = withTrackedResponse(id, task, record, requestFor(url, record.headers)) { response ->
        if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
        response.body?.bytes() ?: throw IOException("Empty body")
    }

    private fun isOnWifi(): Boolean {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = manager.activeNetwork ?: return false
        return manager.getNetworkCapabilities(network)?.hasTransport(
            android.net.NetworkCapabilities.TRANSPORT_WIFI,
        ) == true
    }

    private fun actionPending(action: String, titleRes: Int, icon: Int): NotificationCompat.Action =
        NotificationCompat.Action(
            icon,
            getString(titleRes),
            PendingIntent.getService(
                this,
                action.hashCode(),
                Intent(this, DownloadService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )

    private fun buildNotification(): Notification {
        val all = DownloadStore.current(this)
        val running = all.filter { it.state == DownloadStore.STATE_DOWNLOADING }
        val queued = all.count { it.state == DownloadStore.STATE_QUEUED }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentTitle(getString(R.string.download_notification_channel))

        if (running.isEmpty()) {
            builder.setContentText(getString(R.string.download_queued))
        } else {
            val first = running.first()
            val fraction = first.progressFraction
            builder.setContentTitle(first.title)
                .setProgress(100, (fraction.coerceAtLeast(0f) * 100).toInt(), fraction < 0f)
                .setContentText(getString(R.string.download_notification_count, running.size + queued))
        }
        if (running.isNotEmpty() || queued > 0) {
            builder.addAction(
                actionPending(
                    ACTION_PAUSE_ALL,
                    R.string.download_notification_pause_all,
                    android.R.drawable.ic_media_pause,
                ),
            )
            builder.addAction(
                actionPending(
                    ACTION_CANCEL_ALL,
                    R.string.download_notification_cancel_all,
                    android.R.drawable.ic_delete,
                ),
            )
        }
        return builder.build()
    }

    private fun updateNotification() {
        try {
            notifications.notify(NOTIFICATION_ID, buildNotification())
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS denied: the work continues, unseen.
        }
    }
}
