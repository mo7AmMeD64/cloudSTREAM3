package com.kodastream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DownloadRangePolicyTest {
    @Test
    fun acceptsOnlyWholeOrValidatedPartialFileResponses() {
        assertEquals(true, isSupportedDownloadHttpStatus(200))
        assertEquals(true, isSupportedDownloadHttpStatus(206))
        assertEquals(false, isSupportedDownloadHttpStatus(201))
        assertEquals(false, isSupportedDownloadHttpStatus(204))
        assertEquals(false, isSupportedDownloadHttpStatus(226))
    }

    @Test
    fun acceptsACompleteRangeStartingAtTheRequestedOffset() {
        assertEquals(
            DownloadContentRange(start = 100L, endInclusive = 999L, totalBytes = 1_000L),
            parseDownloadContentRange("bytes 100-999/1000", requestedOffset = 100L, contentLength = 900L),
        )
    }

    @Test
    fun acceptsAFullRepresentationReturnedAsPartialFromZero() {
        assertEquals(
            DownloadContentRange(start = 0L, endInclusive = 9L, totalBytes = 10L),
            parseDownloadContentRange("bytes 0-9/10", requestedOffset = 0L, contentLength = 10L),
        )
    }

    @Test
    fun rejectsAResponseStartingAtADifferentOffset() {
        assertNull(parseDownloadContentRange("bytes 99-999/1000", 100L, 901L))
    }

    @Test
    fun rejectsAResponseThatDoesNotReachTheEndOfTheFile() {
        assertNull(parseDownloadContentRange("bytes 100-499/1000", 100L, 400L))
    }

    @Test
    fun rejectsMalformedUnknownTotalAndLengthMismatch() {
        assertNull(parseDownloadContentRange(null, 0L, 10L))
        assertNull(parseDownloadContentRange("bytes 0-9/*", 0L, 10L))
        assertNull(parseDownloadContentRange("bytes 0-9/10", 0L, 9L))
        assertNull(parseDownloadContentRange("items 0-9/10", 0L, 10L))
    }
}
