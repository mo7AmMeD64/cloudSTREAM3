package com.kodastream.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class PlayerSeekPolicyTest {
    @Test
    fun keepsEverySupportedIntervalUnchanged() {
        PLAYER_SEEK_INTERVALS_SECONDS.forEach { value ->
            assertEquals(value, normalizePlayerSeekSeconds(value))
        }
    }

    @Test
    fun mapsLegacyValuesToTheNearestVisibleChoice() {
        assertEquals(5, normalizePlayerSeekSeconds(7))
        assertEquals(10, normalizePlayerSeekSeconds(12))
        assertEquals(15, normalizePlayerSeekSeconds(17))
        assertEquals(20, normalizePlayerSeekSeconds(19))
    }

    @Test
    fun tiesAndOutOfRangeValuesAreResolvedSafely() {
        assertEquals(10, normalizePlayerSeekSeconds(12))
        assertEquals(5, normalizePlayerSeekSeconds(-100))
        assertEquals(20, normalizePlayerSeekSeconds(100))
    }
}
