package com.kodastream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import com.lagradost.cloudstream3.DubStatus
import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.newAnimeLoadResponse
import com.lagradost.cloudstream3.newTvSeriesLoadResponse
import kotlinx.coroutines.runBlocking
import org.junit.Test

class EpisodeQueueOrderTest {
    @Test
    fun playbackQueueFollowsDisplaySeasonOrderNotProviderOrder() {
        assertEquals(
            listOf(50, 10, 99),
            orderQueueSeasonKeys(listOf(99, 50, 10, 50), listOf(50, 10, 99)),
        )
    }

    @Test
    fun episodesWithUnknownSeasonDoNotCollideWithSeasonMinusOne() {
        assertEquals(
            listOf(-1, 1, null),
            orderQueueSeasonKeys(listOf(null, 1, -1), listOf(-1, 1)),
        )
    }

    @Suppress("DEPRECATION_ERROR")
    @Test
    fun playbackQueueSortsEpisodesWithinEachDisplayOrderedSeason() {
        val queue = EpisodeQueues.build(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            episodes = listOf(
                Episode(data = "s2e2", season = 10, episode = 2),
                Episode(data = "s1e2", season = 50, episode = 2),
                Episode(data = "s1e1", season = 50, episode = 1),
                Episode(data = "s2e1", season = 10, episode = 1),
            ),
            seasonOrder = listOf(50, 10),
            seasonDisplayNumbers = mapOf(50 to 1, 10 to 2),
        )
        assertEquals(listOf("s1e1", "s1e2", "s2e1", "s2e2"), queue?.episodes?.map { it.data })
        assertEquals(listOf(1, 1, 2, 2), queue?.episodes?.map { it.seasonIndex })
    }

    @Suppress("DEPRECATION_ERROR")
    @Test
    fun playbackQueuePreservesWholeProviderOrderWhenMultiSeasonMappingIsIncomplete() {
        val queue = EpisodeQueues.build(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            episodes = listOf(
                Episode(data = "season-two", season = 2, episode = 1),
                Episode(data = "unmapped", episode = 2),
                Episode(data = "season-one", season = 1, episode = 1),
            ),
            seasonOrder = emptyList(),
            seasonMappingUnavailable = true,
        )
        assertEquals(listOf("season-two", "unmapped", "season-one"), queue?.episodes?.map { it.data })
        assertEquals(listOf(-1), queue?.seasons)
        assertEquals(listOf(null, null, null), queue?.episodes?.map { it.season })
    }

    @Suppress("DEPRECATION_ERROR")
    @Test
    fun metadataOnlyMultiSeasonMappingKeepsSeasonlessPlaybackSequence() {
        val queue = EpisodeQueues.build(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            episodes = listOf(
                Episode(data = "provider-first", episode = 2),
                Episode(data = "provider-second", episode = 1),
            ),
            seasonMappingUnavailable = true,
        )
        assertEquals(listOf("provider-first", "provider-second"), queue?.episodes?.map { it.data })
    }

    @Suppress("DEPRECATION_ERROR")
    @Test
    fun seasonlessSingleSeasonQueueUsesFallbackSeasonAndEpisodeOrder() {
        val queue = EpisodeQueues.build(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            episodes = listOf(
                Episode(data = "second", episode = 2),
                Episode(data = "first", episode = 1),
            ),
            fallbackSeason = 1,
            seasonOrder = listOf(1),
        )
        assertEquals(listOf("first", "second"), queue?.episodes?.map { it.data })
        assertEquals(listOf(1), queue?.seasons)
    }

    private fun download(
        id: String,
        season: Int,
        episode: Int,
        seasonOrder: Int?,
        episodeOrder: Int?,
        displaySeasonNumber: Int? = null,
    ) = DownloadStore.Download(
        id = id,
        apiName = "source",
        url = "series",
        title = "Series",
        season = season,
        episode = episode,
        linkUrl = "https://example.invalid/$id",
        fileName = "$id.mp4",
        seasonDisplayOrder = seasonOrder,
        episodeDisplayOrder = episodeOrder,
        seasonDisplayNumber = displaySeasonNumber,
    )

    @Test
    fun offlineDownloadsFollowSavedDisplaySeasonAndEpisodeOrder() {
        val sorted = orderDownloadedRecords(
            listOf(
                download("late-s2", season = 10, episode = 1, seasonOrder = 1, episodeOrder = 0, displaySeasonNumber = 2),
                download("s1-e2", season = 50, episode = 2, seasonOrder = 0, episodeOrder = 1, displaySeasonNumber = 1),
                download("s1-e1", season = 50, episode = 1, seasonOrder = 0, episodeOrder = 0, displaySeasonNumber = 1),
            ),
        )
        assertEquals(listOf("s1-e1", "s1-e2", "late-s2"), sorted.map { it.id })
        val queue = EpisodeQueues.fromDownloads(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            downloads = sorted.map { it.copy(state = DownloadStore.STATE_DONE, fileUri = "file://${it.id}.mp4") },
        )
        assertEquals(listOf(1, 1, 2), queue?.episodes?.map { it.seasonIndex })
    }

    @Suppress("DEPRECATION_ERROR")
    @Test
    fun seasonlessQueueDoesNotInventASeasonZeroOverlayLabel() {
        val queue = EpisodeQueues.build(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            episodes = listOf(Episode(data = "unmapped", episode = 1)),
            seasonMappingUnavailable = true,
        )
        assertEquals(listOf(null), queue?.episodes?.map { it.seasonIndex })
    }

    @Test
    fun legacyOfflineDownloadsFallBackToProviderSeasonAndEpisodeKeys() {
        val sorted = orderDownloadedRecords(
            listOf(
                download("s10", season = 10, episode = 1, seasonOrder = null, episodeOrder = null),
                download("s2", season = 2, episode = 1, seasonOrder = null, episodeOrder = null),
            ),
        )
        assertEquals(listOf("s2", "s10"), sorted.map { it.id })
    }


    @Test
    fun legacyOfflineDownloadsDoNotExposeOpaqueProviderSeasonKeysAsDisplayNumbers() {
        val queue = EpisodeQueues.fromDownloads(
            apiName = "source", url = "series", title = "Series",
            posterUrl = null, posterHeaders = null, type = "series",
            downloads = listOf(
                download("opaque", season = 50, episode = 1, seasonOrder = null, episodeOrder = null)
                    .copy(state = DownloadStore.STATE_DONE, fileUri = "file://opaque.mp4"),
            ),
        )
        assertEquals(listOf(null), queue?.episodes?.map { it.seasonIndex })
    }

    @Test
    fun duplicateEpisodeCoordinatesPreferTheMatchingPlaybackDataWhenAvailable() {
        val queueRows = listOf(
            QueueEpisode(season = 1, number = 5, name = "Special", data = "special-url", index = 0),
            QueueEpisode(season = 1, number = 5, name = "Episode", data = "episode-url", index = 1),
        )
        assertEquals(1, findPlaybackQueueIndex(queueRows, "episode-url", season = 1, episode = 5))
    }

    @Test
    fun playbackStartsAtExactSeasonAndEpisodeWhenProviderReusesDataUrl() {
        val queueRows = listOf(
            QueueEpisode(season = 1, number = 1, name = "One", data = "shared-token", index = 0),
            QueueEpisode(season = 2, number = 1, name = "Two", data = "shared-token", index = 1),
        )
        assertEquals(1, findPlaybackQueueIndex(queueRows, "shared-token", season = 2, episode = 1))
        assertEquals(0, findPlaybackQueueIndex(queueRows, "shared-token", season = null, episode = 1))
    }

    @Test
    fun providerOrderIsPreservedWhenNoDisplayOrderWasProvided() {
        assertEquals(
            listOf(8, 2, null),
            orderQueueSeasonKeys(listOf(8, 2, null, 8), emptyList()),
        )
    }

    @Suppress("DEPRECATION_ERROR")
    @Test
    fun fromResponseInfersStandaloneSeasonDisplayNumberAndSkipsAnimeMovies() = runBlocking {
        val api = object : com.lagradost.cloudstream3.MainAPI() {
            override var name = "TestProvider"
        }
        val standaloneSeason2 = api.newTvSeriesLoadResponse(
            name = "Severance الموسم الثاني",
            url = "https://example.com/severance-s2",
            type = TvType.TvSeries,
            episodes = listOf(Episode(data = "ep1", episode = 1), Episode(data = "ep2", episode = 2)),
        )
        val queue = EpisodeQueues.fromResponse(standaloneSeason2)
        assertEquals(listOf(2, 2), queue?.episodes?.map { it.seasonIndex })
        assertEquals(listOf(1, 1), queue?.episodes?.map { it.season })

        val animeMovie = api.newAnimeLoadResponse(
            name = "Jujutsu Kaisen 0",
            url = "https://example.com/jjk-0",
            type = TvType.AnimeMovie,
        ) {
            episodes = mutableMapOf(DubStatus.Subbed to listOf(Episode(data = "movie-stream", episode = 1)))
        }
        assertNull(EpisodeQueues.fromResponse(animeMovie))
    }
}
