package com.kodastream.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerTapPolicyTest {
    @Test
    fun closeTapsOnOppositeSidesOfCenterAreNotADoubleTap() {
        assertFalse(areTapsInSamePlayerZone(490f, 510f, 1000, centerPauseEnabled = false))
    }

    @Test
    fun nearbyTapsInSameSeekZoneCanFormADoubleTap() {
        assertTrue(areTapsInSamePlayerZone(120f, 220f, 1000, centerPauseEnabled = false))
        assertTrue(areTapsInSamePlayerZone(850f, 930f, 1000, centerPauseEnabled = false))
    }

    @Test
    fun centerPauseBandIsAnIndependentZone() {
        assertFalse(areTapsInSamePlayerZone(430f, 490f, 1000, centerPauseEnabled = true))
        assertTrue(areTapsInSamePlayerZone(480f, 520f, 1000, centerPauseEnabled = true))
        assertFalse(areTapsInSamePlayerZone(500f, 580f, 1000, centerPauseEnabled = true))
    }

    @Test
    fun differentSidesRemainIndependentEvenWhenCloseToTheBoundary() {
        assertFalse(areTapsInSamePlayerZone(499f, 501f, 1000, centerPauseEnabled = false))
    }

    @Test
    fun centerPauseOnlyDoesNotTurnSideTapsIntoDoubleTapActions() {
        assertFalse(canRecognizePlayerDoubleTap(false, true, false))
        assertTrue(canRecognizePlayerDoubleTap(false, true, true))
        assertTrue(canRecognizePlayerDoubleTap(true, false, false))
    }

    @Test
    fun centerPauseBandUsesTheConfiguredWidth() {
        assertTrue(isInPlayerCenterPauseZone(500f, 1000, 0.06f))
        assertFalse(isInPlayerCenterPauseZone(430f, 1000, 0.06f))
    }
}
