package com.kodastream.app.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationDragPhysicsTest {
    @Test
    fun mapsLogicalSelectionToPhysicalIndexForBothLayoutDirections() {
        assertEquals(0, NavDragPhysics.physicalIndex(0, 6, isRtl = false))
        assertEquals(5, NavDragPhysics.physicalIndex(0, 6, isRtl = true))
        assertEquals(0, NavDragPhysics.physicalIndex(5, 6, isRtl = true))
        assertEquals(2, NavDragPhysics.physicalIndex(3, 6, isRtl = true))
    }

    @Test
    fun bubblePhysicalAnchorMatchesSelectedTabCenterInBothDirections() {
        val itemCount = 6
        val cellWidth = 64f
        for (isRtl in listOf(false, true)) {
            for (logicalIndex in 0 until itemCount) {
                val physicalIndex = NavDragPhysics.physicalIndex(logicalIndex, itemCount, isRtl)
                val bubbleCenter = cellWidth * physicalIndex + cellWidth / 2f
                val expectedTabCenter = if (isRtl) {
                    cellWidth * (itemCount - logicalIndex) - cellWidth / 2f
                } else {
                    cellWidth * logicalIndex + cellWidth / 2f
                }
                assertEquals(expectedTabCenter, bubbleCenter)
            }
        }
    }

    @Test
    fun clampTrackPositionKeepsPointerInsidePhysicalTrack() {
        assertEquals(0f, NavDragPhysics.clampTrackPosition(-42f, 360f))
        assertEquals(0f, NavDragPhysics.clampTrackPosition(0f, 360f))
        assertEquals(180f, NavDragPhysics.clampTrackPosition(180f, 360f))
        assertEquals(360f, NavDragPhysics.clampTrackPosition(402f, 360f))
        assertEquals(0f, NavDragPhysics.clampTrackPosition(Float.NaN, 360f))
        assertEquals(0f, NavDragPhysics.clampTrackPosition(Float.POSITIVE_INFINITY, 360f))
        assertEquals(0f, NavDragPhysics.clampTrackPosition(120f, Float.NaN))
        assertEquals(0f, NavDragPhysics.clampTrackPosition(120f, 0f))
    }

    @Test
    fun clampedPointerStillSelectsCorrectLogicalTabInRtlAndLtr() {
        val width = 360f
        val count = 6
        val ltr = FloatArray(count) { NavDragPhysics.equalTabCenter(it, count, width, false) }
        val rtl = FloatArray(count) { NavDragPhysics.equalTabCenter(it, count, width, true) }

        assertEquals(0, NavDragPhysics.nearestIndex(NavDragPhysics.clampTrackPosition(-20f, width), ltr))
        assertEquals(5, NavDragPhysics.nearestIndex(NavDragPhysics.clampTrackPosition(380f, width), ltr))
        assertEquals(5, NavDragPhysics.nearestIndex(NavDragPhysics.clampTrackPosition(-20f, width), rtl))
        assertEquals(0, NavDragPhysics.nearestIndex(NavDragPhysics.clampTrackPosition(380f, width), rtl))
    }

    @Test
    fun trackGeometryRemainsBoundedAcrossWidthsTabCountsAndDirections() {
        for (width in 60..480 step 3) {
            for (count in 2..8) {
                for (isRtl in listOf(false, true)) {
                    val trackWidth = width.toFloat()
                    val centers = FloatArray(count) { index ->
                        NavDragPhysics.equalTabCenter(index, count, trackWidth, isRtl)
                    }
                    val capsuleWidth = (trackWidth * 0.2f).coerceAtMost(76f).coerceAtLeast(1f)
                    for (rawX in -width..(width * 2) step 2) {
                        val pointerX = NavDragPhysics.clampTrackPosition(rawX.toFloat(), trackWidth)
                        val selected = NavDragPhysics.nearestIndex(pointerX, centers)
                        assertTrue(selected != null && selected in 0 until count)
                        val capsuleLeft = NavDragPhysics.centeredOffset(pointerX, capsuleWidth, trackWidth)
                        assertTrue(capsuleLeft >= 0f)
                        assertTrue(capsuleLeft + capsuleWidth <= trackWidth + 0.001f)
                    }
                }
            }
        }
    }

    @Test
    fun equalWidthBottomTabsUsePhysicalLocalCentersInLtrAndRtl() {
        val width = 360f
        val count = 6
        assertEquals(30f, NavDragPhysics.equalTabCenter(0, count, width, isRtl = false))
        assertEquals(330f, NavDragPhysics.equalTabCenter(5, count, width, isRtl = false))
        assertEquals(330f, NavDragPhysics.equalTabCenter(0, count, width, isRtl = true))
        assertEquals(30f, NavDragPhysics.equalTabCenter(5, count, width, isRtl = true))
        assertEquals(210f, NavDragPhysics.equalTabCenter(2, count, width, isRtl = true))
    }

    @Test
    fun bottomBubbleDragHitSelectionUsesTrackLocalXForBothLayoutDirections() {
        val count = 6
        val width = 360f
        val rtlCenters = FloatArray(count) { index ->
            NavDragPhysics.equalTabCenter(index, count, width, isRtl = true)
        }
        assertEquals(0, NavDragPhysics.nearestIndex(330f, rtlCenters))
        assertEquals(1, NavDragPhysics.nearestIndex(270f, rtlCenters))
        assertEquals(5, NavDragPhysics.nearestIndex(30f, rtlCenters))

        val ltrCenters = FloatArray(count) { index ->
            NavDragPhysics.equalTabCenter(index, count, width, isRtl = false)
        }
        assertEquals(0, NavDragPhysics.nearestIndex(30f, ltrCenters))
        assertEquals(4, NavDragPhysics.nearestIndex(270f, ltrCenters))
        assertEquals(5, NavDragPhysics.nearestIndex(330f, ltrCenters))
    }

    @Test
    fun bottomBubbleFingerTrackingCoversEveryTabAcrossRtlAndLtrTrack() {
        val count = 6
        val width = 360f
        val cellWidth = width / count

        for (isRtl in listOf(false, true)) {
            val centers = FloatArray(count) { index ->
                NavDragPhysics.equalTabCenter(index, count, width, isRtl)
            }

            // Exercise every point along the track, not only the first and last
            // tabs. The physical X coordinate must always map back to the same
            // logical destination that owns that cell in the current direction.
            for (logicalIndex in 0 until count) {
                val center = centers[logicalIndex]
                assertEquals(logicalIndex, NavDragPhysics.nearestIndex(center, centers))
                val quarterCellTowardLeft = (center - cellWidth * 0.24f)
                    .coerceIn(0f, width)
                val quarterCellTowardRight = (center + cellWidth * 0.24f)
                    .coerceIn(0f, width)
                assertEquals(logicalIndex, NavDragPhysics.nearestIndex(quarterCellTowardLeft, centers))
                assertEquals(logicalIndex, NavDragPhysics.nearestIndex(quarterCellTowardRight, centers))
            }

            val physicalLeftIndex = if (isRtl) count - 1 else 0
            val physicalRightIndex = if (isRtl) 0 else count - 1
            assertEquals(physicalLeftIndex, NavDragPhysics.nearestIndex(0f, centers))
            assertEquals(physicalRightIndex, NavDragPhysics.nearestIndex(width, centers))
        }
    }

    @Test
    fun equalWidthBottomTabCenterRejectsInvalidTrackGeometry() {
        assertTrue(NavDragPhysics.equalTabCenter(0, 0, 360f, isRtl = false).isNaN())
        assertTrue(NavDragPhysics.equalTabCenter(0, 6, Float.NaN, isRtl = false).isNaN())
        assertTrue(NavDragPhysics.equalTabCenter(0, 6, -1f, isRtl = false).isNaN())
        assertTrue(NavDragPhysics.equalTabCenter(0, 6, 0f, isRtl = false).isNaN())
    }

    @Test
    fun nearestIndexUsesPhysicalCentersInLtr() {
        val centers = floatArrayOf(50f, 150f, 250f)
        assertEquals(0, NavDragPhysics.nearestIndex(54f, centers))
        assertEquals(1, NavDragPhysics.nearestIndex(149f, centers))
        assertEquals(2, NavDragPhysics.nearestIndex(247f, centers))
    }

    @Test
    fun nearestIndexPreservesLogicalIndexWhenRtlCentersAreReversed() {
        val rtlCenters = floatArrayOf(250f, 150f, 50f)
        assertEquals(0, NavDragPhysics.nearestIndex(246f, rtlCenters))
        assertEquals(1, NavDragPhysics.nearestIndex(151f, rtlCenters))
        assertEquals(2, NavDragPhysics.nearestIndex(52f, rtlCenters))
    }

    @Test
    fun flickAdvancesInPhysicalDirectionAndMapsBackToLogicalIndexInRtl() {
        val rtlCenters = floatArrayOf(300f, 200f, 100f, 0f)
        assertEquals(
            1,
            NavDragPhysics.releaseTarget(
                releasedAt = 300f,
                axisVelocityPxPerSecond = -900f,
                itemCenters = rtlCenters,
            ),
        )
    }

    @Test
    fun highVelocityCannotSkipMoreThanOneNeighbor() {
        val centers = floatArrayOf(40f, 240f, 440f, 640f, 840f)
        assertEquals(
            1,
            NavDragPhysics.releaseTarget(
                releasedAt = 40f,
                axisVelocityPxPerSecond = 20_000f,
                itemCenters = centers,
            ),
        )
    }

    @Test
    fun releaseProjectionUsesNeighborGapInDirectionOfTravel() {
        // The active pill makes the left gap smaller than the right gap.
        // A rightward flick must be allowed to use the right-hand interval.
        val centers = floatArrayOf(0f, 80f, 260f, 340f)
        assertEquals(
            2,
            NavDragPhysics.releaseTarget(
                releasedAt = 80f,
                axisVelocityPxPerSecond = 1_500f,
                itemCenters = centers,
            ),
        )
        // The mirrored leftward case uses the left neighbor, not the wider gap.
        assertEquals(
            1,
            NavDragPhysics.releaseTarget(
                releasedAt = 260f,
                axisVelocityPxPerSecond = -1_500f,
                itemCenters = centers,
            ),
        )
    }

    @Test
    fun releaseAtEdgeNeverProjectsPastAvailableNeighbor() {
        val centers = floatArrayOf(20f, 100f, 300f)
        assertEquals(
            0,
            NavDragPhysics.releaseTarget(
                releasedAt = 20f,
                axisVelocityPxPerSecond = -20_000f,
                itemCenters = centers,
            ),
        )
        assertEquals(
            2,
            NavDragPhysics.releaseTarget(
                releasedAt = 300f,
                axisVelocityPxPerSecond = 20_000f,
                itemCenters = centers,
            ),
        )
    }

    @Test
    fun sparseTabsOnlyAdvanceWhenVelocityProjectionReachesTheNextCenter() {
        val centers = floatArrayOf(0f, 300f, 600f)
        assertEquals(
            0,
            NavDragPhysics.releaseTarget(
                releasedAt = 0f,
                axisVelocityPxPerSecond = 900f,
                itemCenters = centers,
            ),
        )
    }

    @Test
    fun invalidCentersAndPositionsAreIgnored() {
        val centers = floatArrayOf(Float.NaN, 100f, Float.POSITIVE_INFINITY)
        assertEquals(1, NavDragPhysics.nearestIndex(98f, centers))
        assertNull(NavDragPhysics.nearestIndex(Float.NaN, centers))
        assertNull(NavDragPhysics.nearestIndex(10f, floatArrayOf(Float.NaN, Float.POSITIVE_INFINITY)))
    }

    @Test
    fun nonFiniteVelocityFallsBackToNearestCenter() {
        val centers = floatArrayOf(25f, 125f, 225f)
        assertEquals(
            1,
            NavDragPhysics.releaseTarget(
                releasedAt = 130f,
                axisVelocityPxPerSecond = Float.NaN,
                itemCenters = centers,
            ),
        )
    }

    @Test
    fun pointerCenteredBubbleOffsetTracksEveryPositionAndClampsOnlyAtEdges() {
        assertEquals(0f, NavDragPhysics.centeredOffset(10f, 40f, 200f))
        assertEquals(80f, NavDragPhysics.centeredOffset(100f, 40f, 200f))
        assertEquals(160f, NavDragPhysics.centeredOffset(220f, 40f, 200f))
        assertEquals(0f, NavDragPhysics.centeredOffset(Float.NaN, 40f, 200f))
    }

    @Test
    fun stretchResponseIsContinuousAndDensityIndependent() {
        val mdpi = NavDragPhysics.stretchRatio(900f, 1f)
        val xhdpi = NavDragPhysics.stretchRatio(1_800f, 2f)
        assertEquals(mdpi, xhdpi)
        assertEquals(0f, NavDragPhysics.stretchRatio(0f, 1f))
        assertTrue(NavDragPhysics.stretchRatio(200f, 1f) < mdpi)
        assertTrue(mdpi < NavDragPhysics.stretchRatio(4_000f, 1f))
        assertEquals(0f, NavDragPhysics.stretchRatio(Float.POSITIVE_INFINITY, 1f))
    }
}
