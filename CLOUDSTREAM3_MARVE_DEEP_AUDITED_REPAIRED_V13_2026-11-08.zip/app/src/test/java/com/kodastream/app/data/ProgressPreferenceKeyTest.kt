package com.kodastream.app.data

import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressPreferenceKeyTest {
    @Test
    fun keysDoNotReuseKnownJavaHashCodeCollision() {
        // "FB" and "Ea" have the same String.hashCode() in the JVM.
        assertTrue("FB".hashCode() == "Ea".hashCode())
        assertNotEquals(
            progressPreferenceKey("pos_", "FB"),
            progressPreferenceKey("pos_", "Ea"),
        )
    }

    @Test
    fun playerStoreIdsAreStableAndAvoidKnownHashCodeCollision() {
        assertEquals(playbackEpisodeId("FB"), playbackEpisodeId("FB"))
        assertNotEquals(playbackEpisodeId("FB"), playbackEpisodeId("Ea"))
    }

    @Test
    fun downloadPosterNamesDoNotCollideWhenDownloadIdsHaveSameJavaHash() {
        val first = "provider|https://example.test/Aa|-1|-1"
        val second = "provider|https://example.test/BB|-1|-1"
        assertEquals(first.hashCode(), second.hashCode())
        assertNotEquals(downloadPosterFileName(first), downloadPosterFileName(second))
    }

    @Test
    fun namespacesAndMediaIdentityAreBothPartOfTheKey() {
        assertNotEquals(progressPreferenceKey("pos_", "movie"), progressPreferenceKey("dur_", "movie"))
        assertNotEquals(progressPreferenceKey("pos_", "movie"), progressPreferenceKey("pos_", "episode"))
    }
}
