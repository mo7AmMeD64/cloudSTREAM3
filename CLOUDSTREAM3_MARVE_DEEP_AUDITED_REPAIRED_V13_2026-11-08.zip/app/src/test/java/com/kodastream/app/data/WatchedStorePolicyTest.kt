package com.kodastream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchedStorePolicyTest {
    @Test
    fun onlyCanonicalNullNullKeyRepresentsMovie() {
        assertTrue(isMovieWatchItem(null, null))
        assertFalse(isMovieWatchItem(1, null))
        assertFalse(isMovieWatchItem(null, 1))
        assertFalse(isMovieWatchItem(0, 0))
    }

    @Test
    fun onlyKnownOnDemandTypesContributeToWatchTime() {
        assertTrue(isCountableWatchStatsType("movie"))
        assertTrue(isCountableWatchStatsType("series"))
        assertTrue(isCountableWatchStatsType("anime"))
        assertFalse(isCountableWatchStatsType("live"))
        assertFalse(isCountableWatchStatsType("other"))
    }
    @Test
    fun syntheticFallbackCoordinatesDoNotCreateEpisodeIdentity() {
        assertTrue(hasEpisodeWatchIdentity(hasQueueEpisode = true, historyEpisodeNumber = null))
        assertTrue(hasEpisodeWatchIdentity(hasQueueEpisode = false, historyEpisodeNumber = 0))
        assertFalse(hasEpisodeWatchIdentity(hasQueueEpisode = false, historyEpisodeNumber = null))
        assertFalse(hasEpisodeWatchIdentity(hasQueueEpisode = false, historyEpisodeNumber = -1))
    }

    @Test
    fun moviesCanBeMarkedWithoutEpisodeIdentity() {
        assertTrue(canMarkPlaybackAsWatched("movie", isMoviePlayback = true, hasEpisodeIdentity = false))
    }

    @Test
    fun explicitHistoryEpisodesCanBeMarkedWithoutAQueue() {
        assertTrue(canMarkPlaybackAsWatched("series", isMoviePlayback = false, hasEpisodeIdentity = true))
        assertTrue(canMarkPlaybackAsWatched("anime", isMoviePlayback = false, hasEpisodeIdentity = true))
    }

    @Test
    fun unknownSeriesEpisodeIsNotGuessedFromSyntheticCoordinates() {
        assertFalse(canMarkPlaybackAsWatched("series", isMoviePlayback = false, hasEpisodeIdentity = false))
        assertFalse(canMarkPlaybackAsWatched("anime", isMoviePlayback = false, hasEpisodeIdentity = false))
    }

    @Test
    fun watchedSeriesCountCountsUniqueTitlesNotEpisodeMarkers() {
        val keys = setOf(
            "provider|series-a|1|1",
            "provider|series-a|1|2",
            "provider|series-a|2|3",
            "provider|series-b|-1|0",
            "provider|movie|-1|-1",
        )
        assertEquals(2, watchedSeriesCount(keys))
        assertEquals(4, watchedEpisodeCount(keys))
        assertEquals(1, watchedMovieCount(keys))
    }

    @Test
    fun watchedSeriesCountIgnoresInvalidAndMovieKeys() {
        val invalid = setOf(
            "provider|movie|-1|-1",
            "provider|invalid|x|1",
            "provider|invalid|1|x",
            "|empty-title|1|2",
            "provider|invalid|-1|-1x",
        )
        assertEquals(0, watchedSeriesCount(invalid))
        assertEquals(0, watchedEpisodeCount(invalid))
        assertEquals(1, watchedMovieCount(invalid))
    }

    @Test
    fun liveAndUnsupportedItemsAreNeverMarkedAsWatched() {
        assertFalse(canMarkPlaybackAsWatched("live", isMoviePlayback = false, hasEpisodeIdentity = true))
        assertFalse(canMarkPlaybackAsWatched("other", isMoviePlayback = false, hasEpisodeIdentity = true))
    }

    @Test
    fun episodeZeroIsPreservedForSpecialsInWatchHistory() {
        assertEquals(0, episodeNumberForWatchHistory(0, 1, 2, 3))
        assertEquals(0, episodeNumberForWatchHistory(null, 0, 2, 3))
        assertEquals(0, episodeNumberForWatchHistory(null, null, 0, 3))
    }

    @Test
    fun unknownEpisodeNumbersUseTheFirstKnownFallback() {
        assertEquals(5, episodeNumberForWatchHistory(null, 5, 7, 8))
        assertEquals(7, episodeNumberForWatchHistory(null, null, 7, 8))
        assertEquals(8, episodeNumberForWatchHistory(null, null, null, 8))
        assertEquals(7, episodeNumberForWatchHistory(-1, null, 7, 8))
        assertEquals(8, episodeNumberForWatchHistory(null, -1, null, 8))
    }

    @Test
    fun updatingOneWatchedItemPreservesOtherItemsOriginalTimestamps() {
        val before = mapOf("provider|movie-a|-1|-1" to 100L)
        val after = updateWatchedTimestamps(
            existing = before,
            changedKeys = listOf("provider|movie-b|-1|-1"),
            watched = true,
            now = 250L,
        )
        assertEquals(100L, after["provider|movie-a|-1|-1"])
        assertEquals(250L, after["provider|movie-b|-1|-1"])
    }

    @Test
    fun unwatchingRemovesOnlyRequestedTimestampAndIgnoresBlankKeys() {
        val after = updateWatchedTimestamps(
            existing = mapOf("a" to 10L, "b" to 20L),
            changedKeys = listOf("a", "  "),
            watched = false,
            now = 30L,
        )
        assertEquals(mapOf("b" to 20L), after)
    }

}
