package com.kodastream.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class DownloadProgressTest {
    @Test
    fun unknownOrInvalidTotalsRemainIndeterminate() {
        assertEquals(-1f, normalizedDownloadProgress(10L, 0L))
        assertEquals(-1f, normalizedDownloadProgress(10L, -1L))
    }

    @Test
    fun progressIsClampedToTheDocumentedRange() {
        assertEquals(0f, normalizedDownloadProgress(-10L, 100L))
        assertEquals(0.5f, normalizedDownloadProgress(50L, 100L))
        assertEquals(1f, normalizedDownloadProgress(150L, 100L))
    }
}
