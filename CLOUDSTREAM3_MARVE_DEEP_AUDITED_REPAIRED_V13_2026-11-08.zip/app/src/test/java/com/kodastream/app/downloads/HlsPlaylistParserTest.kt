package com.kodastream.app.downloads

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class HlsPlaylistParserTest {
    @Test
    fun selectsHighestBandwidthVariantAndResolvesItAgainstMasterUrl() {
        val master = """
            #EXTM3U
            #EXT-X-STREAM-INF:BANDWIDTH=350000,RESOLUTION=640x360
            low/index.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=1200000,RESOLUTION=1280x720
            high/index.m3u8
        """.trimIndent()

        assertEquals(
            "https://media.example/show/high/index.m3u8",
            HlsPlaylistParser.selectHighestBandwidthVariant(
                "https://media.example/show/master.m3u8",
                master,
            ),
        )
    }

    @Test
    fun resolvesSegmentsAndKeysAgainstSelectedMediaPlaylist() {
        val media = """
            #EXTM3U
            #EXT-X-MEDIA-SEQUENCE:42
            #EXT-X-KEY:METHOD=AES-128,URI="keys/episode.key",IV=0x2
            #EXTINF:6.0,
            ../segments/0001.ts
        """.trimIndent()

        val parsed = HlsPlaylistParser.parseMediaPlaylist(
            "https://media.example/show/720p/index.m3u8",
            media,
        )

        assertEquals(42L, parsed.mediaSequence)
        assertEquals("https://media.example/show/segments/0001.ts", parsed.segments.single().url)
        assertEquals("https://media.example/show/720p/keys/episode.key", parsed.segments.single().key?.url)
        assertEquals("0".repeat(31) + "2", parsed.segments.single().key?.ivHex)
    }

    @Test
    fun methodNoneClearsThePreviousEncryptionKey() {
        val media = """
            #EXTM3U
            #EXT-X-KEY:METHOD=AES-128,URI="key.bin"
            first.ts
            #EXT-X-KEY:METHOD=NONE
            second.ts
        """.trimIndent()

        val parsed = HlsPlaylistParser.parseMediaPlaylist("https://cdn.example/list.m3u8", media)

        assertEquals("https://cdn.example/key.bin", parsed.segments[0].key?.url)
        assertNull(parsed.segments[1].key)
    }

    @Test
    fun rejectsUnsupportedEncryptionAndKeyFormatsInsteadOfSavingCorruptOutput() {
        assertThrows(IllegalArgumentException::class.java) {
            HlsPlaylistParser.parseMediaPlaylist(
                "https://cdn.example/list.m3u8",
                "#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI=\"key.bin\"\nsegment.ts",
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            HlsPlaylistParser.parseMediaPlaylist(
                "https://cdn.example/list.m3u8",
                "#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,KEYFORMAT=identity-evil,URI=\"key.bin\"\nsegment.ts",
            )
        }
    }

    @Test
    fun rejectsAnEmptyExplicitIv() {
        assertThrows(IllegalArgumentException::class.java) {
            HlsPlaylistParser.parseMediaPlaylist(
                "https://cdn.example/list.m3u8",
                "#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"key.bin\",IV=0x\nsegment.ts",
            )
        }
    }

    @Test
    fun rejectsPlaylistFeaturesThatWouldOtherwiseProduceAnIncompleteFile() {
        assertThrows(IllegalArgumentException::class.java) {
            HlsPlaylistParser.parseMediaPlaylist(
                "https://cdn.example/list.m3u8",
                "#EXTM3U\n#EXT-X-MAP:URI=\"init.mp4\"\nsegment.m4s",
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            HlsPlaylistParser.parseMediaPlaylist(
                "https://cdn.example/list.m3u8",
                "#EXTM3U\n#EXT-X-BYTERANGE:500@0\nsegment.ts",
            )
        }
    }

    @Test
    fun aes128DecryptUsesMediaSequenceAsTheImplicitIv() {
        val key = ByteArray(16) { (it * 3).toByte() }
        val sequence = 0x10203L
        val iv = ByteArray(16).also { buffer ->
            var value = sequence
            for (index in 15 downTo 0) {
                buffer[index] = (value and 0xFF).toByte()
                value = value ushr 8
            }
        }
        val original = "implicit sequence IV".toByteArray()
        val encryptor = Cipher.getInstance("AES/CBC/PKCS5Padding").apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        }
        val encrypted = encryptor.doFinal(original)

        val decrypted = HlsPlaylistParser.decryptAes128Segment(encrypted, key, null, sequence)

        assertArrayEquals(original, decrypted)
    }

    @Test
    fun aes128DecryptUsesPaddedExplicitIvAndRemovesPkcs7Padding() {
        val key = ByteArray(16) { it.toByte() }
        val iv = ByteArray(16) { (it + 1).toByte() }
        val original = "segment payload".toByteArray()
        val encryptor = Cipher.getInstance("AES/CBC/PKCS5Padding").apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        }
        val encrypted = encryptor.doFinal(original)
        val ivHex = iv.joinToString("") { "%02X".format(it) }

        val decrypted = HlsPlaylistParser.decryptAes128Segment(encrypted, key, ivHex, mediaSequence = 0)

        assertArrayEquals(original, decrypted)
    }
}
