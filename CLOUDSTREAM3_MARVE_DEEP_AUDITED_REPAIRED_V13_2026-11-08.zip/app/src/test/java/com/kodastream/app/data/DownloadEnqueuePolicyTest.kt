package com.kodastream.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class DownloadEnqueuePolicyTest {
    @Test
    fun addsWhenBelowLimit() {
        assertEquals(DownloadEnqueueResult.ADDED, decideDownloadEnqueue(499, false, 500))
    }

    @Test
    fun refusesNewRecordAtLimitWithoutEviction() {
        assertEquals(DownloadEnqueueResult.LIMIT_REACHED, decideDownloadEnqueue(500, false, 500))
    }

    @Test
    fun reportsDuplicateEvenWhenListIsFull() {
        assertEquals(DownloadEnqueueResult.ALREADY_PRESENT, decideDownloadEnqueue(500, true, 500))
    }

    @Test
    fun negativeCountIsHandledAsAnEmptyListAndInvalidLimitIsClamped() {
        assertEquals(DownloadEnqueueResult.ADDED, decideDownloadEnqueue(-10, false, 500))
        assertEquals(DownloadEnqueueResult.LIMIT_REACHED, decideDownloadEnqueue(1, false, 0))
    }
}
