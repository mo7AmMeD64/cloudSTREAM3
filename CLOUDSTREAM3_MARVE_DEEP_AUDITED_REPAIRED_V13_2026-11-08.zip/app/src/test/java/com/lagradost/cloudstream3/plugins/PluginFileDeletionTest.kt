package com.lagradost.cloudstream3.plugins

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class PluginFileDeletionTest {
    @Test
    fun deletesAnExistingPluginArtifact() {
        val directory = Files.createTempDirectory("plugin-delete-test-").toFile()
        try {
            val artifact = File(directory, "sample.cs3").apply { writeText("plugin") }
            assertTrue(deletePluginArtifact(artifact))
            assertFalse(artifact.exists())
        } finally {
            directory.deleteRecursively()
        }
    }

    @Test
    fun treatsAnAlreadyMissingArtifactAsDeleted() {
        val directory = Files.createTempDirectory("plugin-delete-test-").toFile()
        try {
            assertTrue(deletePluginArtifact(File(directory, "missing.cs3")))
        } finally {
            directory.deleteRecursively()
        }
    }

    @Test
    fun replacesAnExistingArtifactWithThePreparedFile() {
        val directory = Files.createTempDirectory("plugin-replace-test-").toFile()
        try {
            val target = File(directory, "installed.cs3").apply { writeText("old") }
            val candidate = File(directory, "candidate.tmp").apply { writeText("new") }
            assertTrue(replacePluginArtifact(candidate, target))
            assertTrue(target.readText() == "new")
            assertFalse(candidate.exists())
        } finally {
            directory.deleteRecursively()
        }
    }

    @Test
    fun doesNotReplaceAnArtifactWhenTheCandidateIsMissing() {
        val directory = Files.createTempDirectory("plugin-replace-test-").toFile()
        try {
            val target = File(directory, "installed.cs3").apply { writeText("old") }
            assertFalse(replacePluginArtifact(File(directory, "missing.tmp"), target))
            assertTrue(target.readText() == "old")
        } finally {
            directory.deleteRecursively()
        }
    }

    @Test
    fun reportsFailureWhenThePathIsNotADeletableFile() {
        val directory = Files.createTempDirectory("plugin-delete-test-").toFile()
        try {
            val nonEmptyDirectory = File(directory, "not-a-file").apply {
                mkdir()
                File(this, "child").writeText("keep")
            }
            assertFalse(deletePluginArtifact(nonEmptyDirectory))
            assertTrue(File(nonEmptyDirectory, "child").exists())
        } finally {
            directory.deleteRecursively()
        }
    }
}
