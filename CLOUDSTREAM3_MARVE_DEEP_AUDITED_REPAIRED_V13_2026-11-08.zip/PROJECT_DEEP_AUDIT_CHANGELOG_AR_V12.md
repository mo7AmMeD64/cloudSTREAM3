# سجل التغييرات — V12

**الأساس:** V11  
**الغرض:** إصلاح عدم تتبع فقاعة التنقل السفلي للإصبع وعدم انتقالها بين الأقسام.

## المشكلة NAV-BUBBLE-001

- **التصنيف:** خطأ تكاملي في استقبال إيماءات اللمس / تعارض بين `pointerInput` ومعالجات النقر.
- **الموقع:** `app/src/main/java/com/kodastream/app/ui/AppNav.kt`، تنفيذ `FloatingNavBubble` والكاشف السابق `rememberBottomBubbleDragModifier`.
- **السبب:** كاشف مستقل يستخدم `detectHorizontalDragGestures` في مسار المعالجة المعتاد، بينما كل تبويب داخل المسار عنصر `Surface(onClick)` تفاعلي. يمكن لمعالجات النقر التابعة استهلاك الأحداث قبل أن يمتلك الكاشف الأب السحب.
- **الأعراض المتوافقة:** بقاء المؤشر في خانة الوجهة الحالية (غالبًا Home)، وعدم تحديث `dragPositionPx` و`dragPreviewIndex` عند سحب الإصبع.
- **الإصلاح:** حذف الكاشف المستقل، وإعادة استخدام `rememberNavDragModifier` المشترك الذي يراقب `PointerEventPass.Initial`، ويمتلك الحركة الأفقية فقط بعد تجاوز `touchSlop`.
- **التكامل:** الإحداثيات محلية إلى نفس المسار (`localCoordinates = true`)، لا يوجد hit-test منفصل لكل تبويب (`restrictToItemBounds = false`)، والموضع المرئي يقيد ضمن `trackWidthPx`.
- **المكونات المرتبطة:** `AppPrefs.navDragSwitchEnabled`، عناصر `Surface(onClick)` الستة، `NavDragPhysics`، `graphicsLayer`، `navigateTopLevel`.
- **التحقق:** 20/20 اختبار فيزياء محليًا ناجح؛ 7 فحوص ربط ساكنة ناجحة؛ لا أخطاء parser نحوية ظاهرة.
- **التحقق المتبقي:** Gradle لم يبدأ بسبب DNS؛ لا Android SDK أو جهاز/محاكي؛ اختبار اللمس الفعلي غير منفذ.

## الاختبارات

- أُضيف `bottomBubbleFingerTrackingCoversEveryTabAcrossRtlAndLtrTrack` لاختبار الخانات الست في الاتجاهين وحواف المسار.
- شُغّل `NavigationDragPhysicsTest` على JVM: 20/20 ناجحة عبر Kotlin compiler وهارنس JUnit مصغر.
- محاولة `./gradlew :app:testDebugUnitTest --offline --no-daemon`: فشلت قبل تشغيل Gradle لأن Wrapper احتاج `gradle-9.4.1-bin.zip` وتعذر DNS لـ `services.gradle.org`.
- لا توجد نتيجة بناء Android أو اختبار Compose UI أو اختبار جهاز في هذه الجولة.

## الملفات المتغيرة

- `app/src/main/java/com/kodastream/app/ui/AppNav.kt`
- `app/src/test/java/com/kodastream/app/ui/NavigationDragPhysicsTest.kt`
- `NAVIGATION_BUBBLE_GESTURE_REPAIR_AR_V12.md`
- `FINAL_DEEP_AUDIT_REPORT_AR_V12.md`
- `PROJECT_DEEP_AUDIT_CHANGELOG_AR_V12.md`

لم تُحذف ميزات أو شاشات أو موارد أو اعتماديات، ولم تتغير وجهات التنقل أو إعداداتها.
