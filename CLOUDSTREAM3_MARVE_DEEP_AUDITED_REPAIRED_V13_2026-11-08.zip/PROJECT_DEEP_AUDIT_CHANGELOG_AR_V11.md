# سجل تغييرات التدقيق والإصلاح — V11

**الأساس:** V10  
**الناتج:** V11  
**التاريخ:** 8 نوفمبر 2026

## الإصلاحات

### 1. إكمال حالة بدء الإضافات عند الفشل
- الملف: `app/src/main/java/com/lagradost/cloudstream3/plugins/PluginManager.kt`
- نقل تحديث `startupDone` و`revision` إلى `finally` بشرط دخول عملية التحميل بعد الحصول على القفل.
- منع شاشة الرئيسية/المصادر من البقاء في انتظار غير منتهٍ إذا فشلت تهيئة المحرك بعد بدء التحميل.
- تسجيل خطأ تحميل الإضافة الفردية مع الاحتفاظ بسجلها وملفها لمحاولة الاسترداد.

### 2. التحقق من حالات HTTP لتنزيل الملف المباشر
- الملفات: `DownloadRangePolicy.kt`, `DownloadService.kt`, `DownloadRangePolicyTest.kt`
- قبول HTTP `200` للتنزيل الكامل و`206` فقط مع فحص `Content-Range`.
- رفض الاستجابات الأخرى من نوع `2xx` مثل `204` و`201` و`226` لمسار ملف الفيديو.
- إضافة اختبار سياسة يغطي الحالات المقبولة والمرفوضة.

### 3. إزالة تصادم أسماء صور الملصقات
- الملفات: `ProgressPreferenceKey.kt`, `DownloadService.kt`, `ProgressPreferenceKeyTest.kt`
- استبدال `${record.id.hashCode()}.jpg` باسم يعتمد SHA-256.
- إضافة حالة اختبار لمعرفي تنزيل مختلفين لهما Java hash متساوٍ.

### 4. مقاومة تصادم مفاتيح حلقات التفاصيل
- الملف: `app/src/main/java/com/kodastream/app/ui/details/DetailsScreen.kt`
- استبدال `episode.data.hashCode()` ببصمة SHA-256 ضمن مفتاح Compose مع الموسم ورقم الحلقة.

## الملفات المتغيرة

1. `app/src/main/java/com/lagradost/cloudstream3/plugins/PluginManager.kt`
2. `app/src/main/java/com/kodastream/app/downloads/DownloadService.kt`
3. `app/src/main/java/com/kodastream/app/data/DownloadRangePolicy.kt`
4. `app/src/main/java/com/kodastream/app/data/ProgressPreferenceKey.kt`
5. `app/src/main/java/com/kodastream/app/ui/details/DetailsScreen.kt`
6. `app/src/test/java/com/kodastream/app/data/DownloadRangePolicyTest.kt`
7. `app/src/test/java/com/kodastream/app/data/ProgressPreferenceKeyTest.kt`

## نتائج التحقق

- 53/53 حالة JVM في harness مستقل ناجحة.
- 154/154 ملف XML اجتاز تحليل XML.
- ملف `gradle/libs.versions.toml` اجتاز التحليل.
- لم تظهر أخطاء Kotlin parser من نوع `expecting` في الملفات المعدلة، لكن compiler لا يملك Android classpath؛ لذلك هذا ليس بناءً.
- لم يُشغّل Gradle أو JUnit بسبب فشل DNS عند `services.gradle.org` وغياب Android SDK/ADB.

## ما لم يتغير

- لا تحديثات اعتماديات أو إصدارات.
- لا حذف لملفات أو موارد أو ميزات.
- لم تتغير إعدادات `minSdk`, `targetSdk`, `compileSdk`.
- بقيت V10 محفوظة كنقطة رجوع داخل بيئة العمل، ولم تُعدّل.
