# CloudStream 3 — MARVE Navigation and Player Audit

This source archive retains the original CloudStream navigation bar and adds an optional custom bottom bar with a finger-following bubble.

## Navigation options

- Position: side or bottom.
- Bottom bar style: original CloudStream pill or custom finger-following bubble.
- Drag-to-switch: independently enabled or disabled; ordinary tap navigation remains available.
- Fixed geometry: updates live when toggled.

## Home catalogue

The final **All** section appears after the selected source's shelves. It can be displayed as a horizontal shelf or a vertically scrolling three-column grid, and loads additional source pages while deduplicating items by provider and URL.

## Player and viewing statistics

The player engine and primary layouts are based on MARVE 0.3.17. Settings cover player controls, seek gestures, seek intervals, compact bottom-row icons, progress-bar thickness, subtitle appearance, and optional viewing statistics. Disabling statistics stops elapsed-time accumulation and hides the statistics section while preserving per-title watched markers used by Library and Details.

See:
- `FINAL_DEEP_AUDIT_REPORT_AR_V10.md` — latest follow-up audit, extension install rollback, deletion consistency, test results, and remaining limits.
- `PROJECT_DEEP_AUDIT_CHANGELOG_AR_V10.md` — V10 source changes.
- `NAVIGATION_BUBBLE_AND_STYLE_AUDIT_AR.md` — navigation and season-row review.
- `PLAYER_CATALOG_STATS_DEEP_AUDIT_AR.md` — current deep audit, fixes, verification, and remaining build/device-test limits.
- `PLAYER_CATALOG_STATS_CHANGELOG_AR.md` — concise change list.

**Build caveat:** Gradle 9.4.1 could not be downloaded in the audit environment because DNS resolution for `services.gradle.org` failed. The source checks and pure policy tests passed, but a full Android build, lint, APK run, and physical touch test remain outstanding.

## V12 bottom-bubble gesture repair

V12 replaces the bubble's separate `detectHorizontalDragGestures` handler with the shared navigation drag recognizer. The shared recognizer observes `PointerEventPass.Initial`, before the child tab `Surface(onClick)` handlers, and uses the same local track coordinates as the bubble's graphics layer. This addresses the event-dispatch conflict that could leave the bubble visually locked to the selected tab even while ordinary navigation interactions continued to work.

See:
- `FINAL_DEEP_AUDIT_REPORT_AR_V12.md` — root cause, affected components, repair, test evidence, and remaining device-test limits.
- `PROJECT_DEEP_AUDIT_CHANGELOG_AR_V12.md` — V12 source changes.
- `NAVIGATION_BUBBLE_GESTURE_REPAIR_AR_V12.md` — detailed pointer-event and finger-tracking analysis.

**V12 verification caveat:** the 20 pure navigation-physics tests passed locally, but Gradle could not start because its 9.4.1 distribution could not be downloaded (`UnknownHostException: services.gradle.org`). Compose UI interaction and physical-device touch behavior remain unverified in this environment.
